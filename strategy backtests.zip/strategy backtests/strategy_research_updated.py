#!/usr/bin/env python3
"""
=============================================================================
STRATEGY RESEARCH — find best execution strategy per stock cluster
=============================================================================

Tests 8 distinct intraday execution strategies against your high-conviction
daily signals (prob >= 0.75, trend regimes). Each strategy is tested with
both AGGRESSIVE and MEDIUM stop philosophies.

Then clusters stocks by observable properties (liquidity, volatility, beta)
and identifies which strategy works best per cluster.

THE 8 EXECUTION STRATEGIES:

1. NAIVE           - Buy T+1 open, sell T+5 close (baseline from main backtest)
2. VWAP_FIRST_HOUR - Buy at VWAP of 9:15-10:15, sell T+5 close
3. ORB_BREAKOUT    - Buy when price breaks above first 15-min high (9:30)
4. ORB_PULLBACK    - Wait for ORB breakout, buy on pullback to breakout level
5. GAP_FADE        - If gap > 2%, wait for fade to fill 50% of gap before entry
6. MOMENTUM_CONFIRM- Buy at 10:00 only if 9:45 close > open (trend confirmed)
7. LIMIT_AT_PREVCLOSE - Limit at previous close, up to 60 min for fill
8. VWAP_REVERSION  - Buy when price dips 0.5%+ below VWAP in first 90 min

STOCK CLUSTERING (based on observable properties at signal time):

  Cluster A: HIGH_LIQUIDITY    (turnover > 50 Cr/day)
  Cluster B: MID_LIQUIDITY     (10-50 Cr/day)
  Cluster C: LOW_LIQUIDITY     (2-10 Cr/day, skip if < 2)
  Cluster D: HIGH_VOL          (20-day ATR/price > 3%)
  Cluster E: LOW_VOL           (20-day ATR/price < 2%)
  Cluster F: STRONG_TREND      (ADX > 30)
  Cluster G: WEAK_TREND        (ADX < 20)

  Each stock falls into one liquidity cluster + one vol cluster + one trend cluster.

VALIDATION SLICE APPROACH (to avoid overfitting):
  - Train slice:       first 60% of dates  (model already trained here)
  - Validation slice:  middle 20% (60-80%)  ← PICK STRATEGIES HERE
  - Test (OOS) slice:  last 20%              ← VERIFY HERE

  Strategy selection per cluster is done on validation slice ONLY.
  Then we verify the chosen strategies on the OOS slice.
  If OOS performance matches validation → real edge.
  If OOS << validation → overfit to validation.
=============================================================================
"""

import os
import sys
import json
import time
import warnings
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
from collections import defaultdict

import numpy as np
import pandas as pd
from joblib import load

warnings.filterwarnings("ignore")

# =============================================================================
# CONFIG
# =============================================================================

BASE_DIR = Path(r"C:\Users\karanvsi\Desktop\Kite Connect\v3_2_output_full")
PANEL_PATH = BASE_DIR / "panel_cache.parquet"
FEATURES_PATH = BASE_DIR / "features_train.json"
MODELS_DIR = BASE_DIR / "models"
ROUTER_PATH = MODELS_DIR / "m5_regime_router.joblib"

INTRADAY_DIR = Path(r"C:\Users\karanvsi\Desktop\Pycharm\Cache\intraday_5min")
OUT_DIR = BASE_DIR / "strategy_research_results"
OUT_DIR.mkdir(exist_ok=True)

IST = "Asia/Kolkata"

# Signal filtering
PROB_MIN = 0.75
ALLOWED_REGIMES = ["bull_trend", "bear_trend"]

# Date slicing
TRAIN_FRACTION = 0.60        # not used in this script (just for reference)
VALIDATION_FRACTION = 0.20   # used to pick strategies
OOS_FRACTION = 0.20          # used to verify chosen strategies

# Sample size
MAX_SIGNALS = 1000  # cap for runtime; set None for full

# Cost assumptions
COST_BPS_ROUND_TRIP = 25
SLIPPAGE_BPS_PER_SIDE = 5

# Stops
STOP_PHILOSOPHIES = {
    "AGGRESSIVE": {
        "initial_stop_pct": -3.0,
        "trail_activate_at_pct": 1.5,
        "trail_distance_pct": 1.5,
        "tighten_at_pct": 5.0,
        "tightened_trail_pct": 1.0,
        "take_all_at_pct": 12.0,
    },
    "MEDIUM": {
        "initial_stop_pct": -5.0,
        "trail_activate_at_pct": 2.5,
        "trail_distance_pct": 2.5,
        "tighten_at_pct": 6.0,
        "tightened_trail_pct": 2.0,
        "take_all_at_pct": 15.0,
    },
}

MAX_HOLD_DAYS = 5

# =============================================================================
# DATA LOADING
# =============================================================================

def load_signals_with_clusters() -> pd.DataFrame:
    """Load signals from panel + compute cluster features."""
    print("\n[1/5] Loading panel and generating signals...")
    
    panel = pd.read_parquet(PANEL_PATH)
    panel["timestamp"] = pd.to_datetime(panel["timestamp"])
    if panel["timestamp"].dt.tz is None:
        panel["timestamp"] = panel["timestamp"].dt.tz_localize(IST)
    
    if "stock_regime" not in panel.columns:
        raise SystemExit("FATAL: panel missing stock_regime")
    
    panel = panel.sort_values(["symbol", "timestamp"]).reset_index(drop=True)
    
    # Universe filter
    panel["avg20_vol"] = (
        panel.groupby("symbol")["volume"]
             .transform(lambda s: s.rolling(20, min_periods=1).mean())
    )
    panel = panel[(panel["close"] >= 2.0) & (panel["avg20_vol"] >= 200_000)].reset_index(drop=True)
    
    # Cluster features
    # 1. Turnover (lakh/day)
    panel["turnover_lakh"] = (panel["close"] * panel["avg20_vol"]) / 1e5
    panel["turnover_cr"] = panel["turnover_lakh"] / 100
    
    # 2. ATR-based volatility (use D_atr_pct if available, else compute simple)
    if "D_atr_pct" in panel.columns:
        panel["atr_pct"] = pd.to_numeric(panel["D_atr_pct"], errors="coerce")
    else:
        # Simple proxy: 20-day high-low range as % of close
        panel["hi_lo_pct"] = (panel["high"] - panel["low"]) / panel["close"] * 100
        panel["atr_pct"] = panel.groupby("symbol")["hi_lo_pct"].transform(
            lambda s: s.rolling(20, min_periods=5).mean()
        )
    
    # 3. ADX (use D_adx if available)
    if "D_adx14" in panel.columns:
        panel["adx"] = pd.to_numeric(panel["D_adx14"], errors="coerce")
    elif "D_adx" in panel.columns:
        panel["adx"] = pd.to_numeric(panel["D_adx"], errors="coerce")
    else:
        panel["adx"] = 20  # neutral default
    
    # Generate predictions
    schema = json.loads(FEATURES_PATH.read_text())
    FEATURES = schema["features"]
    IMPUTE = {k: float(v) for k, v in schema["impute"].items()}
    
    router = load(ROUTER_PATH)
    X = panel.reindex(columns=FEATURES).copy()
    for c in FEATURES:
        X[c] = pd.to_numeric(X[c], errors="coerce").fillna(IMPUTE.get(c, 0.0))
    
    print("  Generating predictions...")
    probs = router.predict_proba_by_regime(X, panel["stock_regime"])
    panel["prob"] = probs
    
    # Filter
    signals = panel[
        (panel["prob"] >= PROB_MIN) &
        (panel["stock_regime"].isin(ALLOWED_REGIMES))
    ].copy()
    
    print(f"  Signals: {len(signals):,}")
    
    # Date slicing
    all_dates = panel["timestamp"].dt.normalize().drop_duplicates().sort_values()
    n_dates = len(all_dates)
    train_end = all_dates.iloc[int(n_dates * TRAIN_FRACTION)]
    val_end = all_dates.iloc[int(n_dates * (TRAIN_FRACTION + VALIDATION_FRACTION))]
    
    signals["slice"] = "TRAIN"
    signals.loc[signals["timestamp"] >= train_end, "slice"] = "VALIDATION"
    signals.loc[signals["timestamp"] >= val_end, "slice"] = "OOS"
    
    print(f"  TRAIN signals: {(signals['slice'] == 'TRAIN').sum():,}")
    print(f"  VALIDATION signals: {(signals['slice'] == 'VALIDATION').sum():,}")
    print(f"  OOS signals: {(signals['slice'] == 'OOS').sum():,}")
    
    # Keep only VALIDATION and OOS for this study
    signals = signals[signals["slice"].isin(["VALIDATION", "OOS"])].copy()
    
    # Cluster assignment
    signals = assign_clusters(signals)
    
    return signals[[
        "symbol", "timestamp", "close", "prob", "stock_regime", "slice",
        "turnover_cr", "atr_pct", "adx",
        "cluster_liquidity", "cluster_volatility", "cluster_trend", "cluster_combined",
    ]].rename(columns={"timestamp": "signal_date", "close": "prev_close"})


def assign_clusters(df: pd.DataFrame) -> pd.DataFrame:
    """Assign each signal to liquidity, volatility, and trend clusters."""
    # Liquidity
    df["cluster_liquidity"] = "MID_LIQ"
    df.loc[df["turnover_cr"] >= 50, "cluster_liquidity"] = "HIGH_LIQ"
    df.loc[df["turnover_cr"] < 10, "cluster_liquidity"] = "LOW_LIQ"
    df.loc[df["turnover_cr"] < 2, "cluster_liquidity"] = "MICRO_LIQ"
    
    # Volatility
    df["cluster_volatility"] = "MID_VOL"
    df.loc[df["atr_pct"] > 3.0, "cluster_volatility"] = "HIGH_VOL"
    df.loc[df["atr_pct"] < 2.0, "cluster_volatility"] = "LOW_VOL"
    
    # Trend strength
    df["cluster_trend"] = "MID_TREND"
    df.loc[df["adx"] > 30, "cluster_trend"] = "STRONG_TREND"
    df.loc[df["adx"] < 20, "cluster_trend"] = "WEAK_TREND"
    
    # Combined (for the most granular per-cluster analysis)
    df["cluster_combined"] = (
        df["cluster_liquidity"] + "_" +
        df["cluster_volatility"] + "_" +
        df["cluster_trend"]
    )
    
    return df


def load_intraday_bars(symbol: str, start: pd.Timestamp, end: pd.Timestamp) -> Optional[pd.DataFrame]:
    """Load 5-min bars for a symbol over a date range."""
    file_path = INTRADAY_DIR / f"{symbol}.parquet"
    if not file_path.exists():
        return None
    
    try:
        df = pd.read_parquet(file_path)
    except Exception:
        return None
    
    if len(df) == 0 or "timestamp" not in df.columns:
        return None
    
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    if df["timestamp"].dt.tz is None:
        df["timestamp"] = df["timestamp"].dt.tz_localize(IST)
    else:
        df["timestamp"] = df["timestamp"].dt.tz_convert(IST)
    
    mask = (df["timestamp"] >= start) & (df["timestamp"] <= end)
    df = df[mask].sort_values("timestamp").reset_index(drop=True)
    return df if len(df) > 0 else None


# =============================================================================
# EXECUTION STRATEGIES
# =============================================================================

def get_day_bars(bars: pd.DataFrame, day: pd.Timestamp) -> pd.DataFrame:
    """Get all bars for a specific trading day."""
    return bars[bars["timestamp"].dt.normalize() == day.normalize()].reset_index(drop=True)


def get_next_n_trading_days_bars(bars: pd.DataFrame, after_date: pd.Timestamp, n: int) -> pd.DataFrame:
    """Get bars for next N trading days after `after_date`."""
    bars_after = bars[bars["timestamp"].dt.normalize() > after_date.normalize()]
    if len(bars_after) == 0:
        return pd.DataFrame()
    unique_days = sorted(bars_after["timestamp"].dt.normalize().unique())[:n]
    return bars_after[bars_after["timestamp"].dt.normalize().isin(unique_days)].reset_index(drop=True)


# --- Strategy 1: NAIVE ---
def exec_naive(signal_date: pd.Timestamp, bars: pd.DataFrame) -> Optional[Dict]:
    next_day = bars[bars["timestamp"].dt.normalize() > signal_date.normalize()]
    if len(next_day) == 0:
        return None
    
    entry_day = next_day["timestamp"].dt.normalize().min()
    entry_bars = get_day_bars(next_day, entry_day)
    if len(entry_bars) == 0:
        return None
    
    entry_price = entry_bars.iloc[0]["open"]
    entry_time = entry_bars.iloc[0]["timestamp"]
    
    return {"entry_price": entry_price, "entry_time": entry_time, "entry_strategy": "NAIVE"}


# --- Strategy 2: VWAP_FIRST_HOUR ---
def exec_vwap_first_hour(signal_date: pd.Timestamp, bars: pd.DataFrame) -> Optional[Dict]:
    next_day = bars[bars["timestamp"].dt.normalize() > signal_date.normalize()]
    if len(next_day) == 0:
        return None
    
    entry_day = next_day["timestamp"].dt.normalize().min()
    day_bars = get_day_bars(next_day, entry_day)
    
    # First hour = 9:15 to 10:15 (12 five-min bars)
    first_hour = day_bars.iloc[:12]
    if len(first_hour) < 5:
        return None
    
    typical = (first_hour["high"] + first_hour["low"] + first_hour["close"]) / 3
    pv = (typical * first_hour["volume"]).sum()
    v = first_hour["volume"].sum()
    vwap = pv / max(v, 1)
    
    # Entry at 10:15 (end of first hour)
    entry_time = first_hour.iloc[-1]["timestamp"]
    
    return {"entry_price": vwap, "entry_time": entry_time, "entry_strategy": "VWAP_FIRST_HOUR"}


# --- Strategy 3: ORB_BREAKOUT ---
def exec_orb_breakout(signal_date: pd.Timestamp, bars: pd.DataFrame) -> Optional[Dict]:
    next_day = bars[bars["timestamp"].dt.normalize() > signal_date.normalize()]
    if len(next_day) == 0:
        return None
    
    entry_day = next_day["timestamp"].dt.normalize().min()
    day_bars = get_day_bars(next_day, entry_day)
    
    # First 15 min = 3 five-min bars (9:15-9:30)
    orb = day_bars.iloc[:3]
    if len(orb) < 3:
        return None
    
    orb_high = orb["high"].max()
    
    # Look for breakout from 9:30 onwards (next 24 bars = 2 hours window)
    breakout_window = day_bars.iloc[3:27]
    for _, bar in breakout_window.iterrows():
        if bar["high"] > orb_high:
            return {
                "entry_price": orb_high * 1.001,  # fill at slight premium
                "entry_time": bar["timestamp"],
                "entry_strategy": "ORB_BREAKOUT",
            }
    
    return None  # no breakout, skip


# --- Strategy 4: ORB_PULLBACK ---
def exec_orb_pullback(signal_date: pd.Timestamp, bars: pd.DataFrame) -> Optional[Dict]:
    next_day = bars[bars["timestamp"].dt.normalize() > signal_date.normalize()]
    if len(next_day) == 0:
        return None
    
    entry_day = next_day["timestamp"].dt.normalize().min()
    day_bars = get_day_bars(next_day, entry_day)
    
    orb = day_bars.iloc[:3]
    if len(orb) < 3:
        return None
    
    orb_high = orb["high"].max()
    
    # Need breakout first, then pullback
    saw_breakout = False
    for _, bar in day_bars.iloc[3:].iterrows():
        if not saw_breakout:
            if bar["high"] > orb_high * 1.005:  # breakout with conviction
                saw_breakout = True
            continue
        # After breakout, wait for pullback to ORB_high ± 0.2%
        if bar["low"] <= orb_high * 1.002:
            return {
                "entry_price": orb_high * 1.002,
                "entry_time": bar["timestamp"],
                "entry_strategy": "ORB_PULLBACK",
            }
        # Cutoff: skip if past 14:00 (too late in day)
        if bar["timestamp"].time() >= pd.Timestamp("14:00").time():
            return None
    
    return None


# --- Strategy 5: GAP_FADE ---
def exec_gap_fade(signal_date: pd.Timestamp, bars: pd.DataFrame, prev_close: float) -> Optional[Dict]:
    next_day = bars[bars["timestamp"].dt.normalize() > signal_date.normalize()]
    if len(next_day) == 0:
        return None
    
    entry_day = next_day["timestamp"].dt.normalize().min()
    day_bars = get_day_bars(next_day, entry_day)
    if len(day_bars) == 0:
        return None
    
    open_price = day_bars.iloc[0]["open"]
    gap_pct = (open_price / prev_close - 1) * 100
    
    if gap_pct < 1.0:
        # Small/no gap: just buy at open
        return {"entry_price": open_price, "entry_time": day_bars.iloc[0]["timestamp"], "entry_strategy": "GAP_FADE"}
    
    if gap_pct > 4.0:
        # Too extended, skip
        return None
    
    # Gap up: wait for 50% gap fill before entering
    target_fill = prev_close + (open_price - prev_close) * 0.5
    
    for _, bar in day_bars.iloc[1:30].iterrows():  # first 2.5 hours
        if bar["low"] <= target_fill:
            return {
                "entry_price": target_fill,
                "entry_time": bar["timestamp"],
                "entry_strategy": "GAP_FADE",
            }
    
    return None  # didn't fade, skip


# --- Strategy 6: MOMENTUM_CONFIRM ---
def exec_momentum_confirm(signal_date: pd.Timestamp, bars: pd.DataFrame) -> Optional[Dict]:
    next_day = bars[bars["timestamp"].dt.normalize() > signal_date.normalize()]
    if len(next_day) == 0:
        return None
    
    entry_day = next_day["timestamp"].dt.normalize().min()
    day_bars = get_day_bars(next_day, entry_day)
    
    # Check 30-min behavior (first 6 bars, 9:15 to 9:45)
    first_30 = day_bars.iloc[:6]
    if len(first_30) < 6:
        return None
    
    open_price = first_30.iloc[0]["open"]
    close_30 = first_30.iloc[-1]["close"]
    
    # Must be positive momentum at 30-min mark
    if close_30 <= open_price:
        return None  # no confirmation, skip
    
    # Enter at next bar (9:45 close / 9:50 open)
    if len(day_bars) <= 6:
        return None
    entry_bar = day_bars.iloc[6]
    return {
        "entry_price": entry_bar["open"],
        "entry_time": entry_bar["timestamp"],
        "entry_strategy": "MOMENTUM_CONFIRM",
    }


# --- Strategy 7: LIMIT_AT_PREVCLOSE ---
def exec_limit_at_prevclose(signal_date: pd.Timestamp, bars: pd.DataFrame, prev_close: float) -> Optional[Dict]:
    next_day = bars[bars["timestamp"].dt.normalize() > signal_date.normalize()]
    if len(next_day) == 0:
        return None
    
    entry_day = next_day["timestamp"].dt.normalize().min()
    day_bars = get_day_bars(next_day, entry_day)
    
    # Place limit at prev_close, valid for 60 min (12 bars)
    window = day_bars.iloc[:12]
    target = prev_close
    
    for _, bar in window.iterrows():
        if bar["low"] <= target:
            return {
                "entry_price": target,
                "entry_time": bar["timestamp"],
                "entry_strategy": "LIMIT_AT_PREVCLOSE",
            }
    
    return None  # not filled


# --- Strategy 8: VWAP_REVERSION ---
def exec_vwap_reversion(signal_date: pd.Timestamp, bars: pd.DataFrame) -> Optional[Dict]:
    next_day = bars[bars["timestamp"].dt.normalize() > signal_date.normalize()]
    if len(next_day) == 0:
        return None
    
    entry_day = next_day["timestamp"].dt.normalize().min()
    day_bars = get_day_bars(next_day, entry_day).copy()
    
    if len(day_bars) < 6:
        return None
    
    # Compute running VWAP
    day_bars["typical"] = (day_bars["high"] + day_bars["low"] + day_bars["close"]) / 3
    day_bars["pv"] = day_bars["typical"] * day_bars["volume"]
    day_bars["cum_pv"] = day_bars["pv"].cumsum()
    day_bars["cum_v"] = day_bars["volume"].cumsum().replace(0, 1)
    day_bars["vwap"] = day_bars["cum_pv"] / day_bars["cum_v"]
    
    # Look for dips 0.5%+ below VWAP in first 18 bars (90 min)
    window = day_bars.iloc[1:18]  # skip first bar (vwap not stable)
    for _, bar in window.iterrows():
        if bar["low"] <= bar["vwap"] * 0.995:
            return {
                "entry_price": bar["vwap"] * 0.995,
                "entry_time": bar["timestamp"],
                "entry_strategy": "VWAP_REVERSION",
            }
    
    return None


STRATEGIES = {
    "NAIVE": exec_naive,
    "VWAP_FIRST_HOUR": exec_vwap_first_hour,
    "ORB_BREAKOUT": exec_orb_breakout,
    "ORB_PULLBACK": exec_orb_pullback,
    "GAP_FADE": exec_gap_fade,
    "MOMENTUM_CONFIRM": exec_momentum_confirm,
    "LIMIT_AT_PREVCLOSE": exec_limit_at_prevclose,
    "VWAP_REVERSION": exec_vwap_reversion,
}


# =============================================================================
# EXIT SIMULATION WITH STOPS
# =============================================================================

def simulate_exit(
    entry_price: float,
    entry_time: pd.Timestamp,
    bars: pd.DataFrame,
    stop_cfg: Dict,
    max_hold_days: int = MAX_HOLD_DAYS,
) -> Dict:
    """
    Simulate exit using stop philosophy.
    Returns dict with exit_price, exit_time, exit_reason.
    """
    holding_bars = bars[bars["timestamp"] > entry_time].reset_index(drop=True)
    if len(holding_bars) == 0:
        return {"exit_price": entry_price, "exit_time": entry_time, "exit_reason": "no_bars"}
    
    # Limit to max_hold_days
    unique_days = sorted(holding_bars["timestamp"].dt.normalize().unique())
    if len(unique_days) > max_hold_days:
        cutoff_day = unique_days[max_hold_days - 1]
        holding_bars = holding_bars[holding_bars["timestamp"].dt.normalize() <= cutoff_day].reset_index(drop=True)
    
    if len(holding_bars) == 0:
        return {"exit_price": entry_price, "exit_time": entry_time, "exit_reason": "no_bars"}
    
    current_stop_pct = stop_cfg["initial_stop_pct"]
    high_water = entry_price
    is_trailing = False
    
    for _, bar in holding_bars.iterrows():
        # Update high water mark
        if bar["high"] > high_water:
            high_water = bar["high"]
        
        return_pct = (bar["close"] / entry_price - 1) * 100
        high_pct = (high_water / entry_price - 1) * 100
        
        # Check hard take-profit
        if high_pct >= stop_cfg["take_all_at_pct"]:
            return {
                "exit_price": entry_price * (1 + stop_cfg["take_all_at_pct"] / 100),
                "exit_time": bar["timestamp"],
                "exit_reason": "TAKE_PROFIT",
            }
        
        # Check stop hit (use bar low)
        stop_price = entry_price * (1 + current_stop_pct / 100)
        if bar["low"] <= stop_price:
            return {
                "exit_price": stop_price,
                "exit_time": bar["timestamp"],
                "exit_reason": f"STOP_HIT_{current_stop_pct:+.1f}%",
            }
        
        # Update trailing stop
        if high_pct >= stop_cfg["trail_activate_at_pct"]:
            is_trailing = True
            if high_pct >= stop_cfg["tighten_at_pct"]:
                trail_dist = stop_cfg["tightened_trail_pct"]
            else:
                trail_dist = stop_cfg["trail_distance_pct"]
            new_stop_pct = high_pct - trail_dist
            if new_stop_pct > current_stop_pct:
                current_stop_pct = new_stop_pct
    
    # End of holding period: exit at last close
    last_bar = holding_bars.iloc[-1]
    return {
        "exit_price": last_bar["close"],
        "exit_time": last_bar["timestamp"],
        "exit_reason": "TIME_EXIT",
    }


# =============================================================================
# MAIN SIMULATION LOOP
# =============================================================================

def run_strategy_research():
    print("=" * 80)
    print("STRATEGY RESEARCH: 8 execution strategies x 2 stop philosophies x clusters")
    print("=" * 80)
    
    # Check intraday data exists
    if not INTRADAY_DIR.exists():
        print(f"\nFATAL: Intraday data dir not found: {INTRADAY_DIR}")
        print("Run intraday_cacher.py first to build the 5-min cache.")
        return
    
    intraday_files = list(INTRADAY_DIR.glob("*.parquet"))
    if len(intraday_files) == 0:
        print(f"\nFATAL: No parquet files in {INTRADAY_DIR}")
        print("Run intraday_cacher.py first.")
        return
    print(f"\nIntraday cache: {len(intraday_files)} symbol files")
    
    # Load signals
    signals = load_signals_with_clusters()
    print(f"\n[2/5] Signal distribution by cluster:")
    print(signals["cluster_combined"].value_counts().head(15).to_string())
    
    # Sample
    if MAX_SIGNALS and len(signals) > MAX_SIGNALS:
        signals = signals.sample(n=MAX_SIGNALS, random_state=42).reset_index(drop=True)
        print(f"\n  Sampled to {len(signals):,} signals")
    
    # Simulate every strategy × stop philosophy on every signal
    print(f"\n[3/5] Simulating {len(STRATEGIES)} strategies x {len(STOP_PHILOSOPHIES)} stop philosophies...")
    all_trades = []
    n_skipped = 0
    start_t = time.time()
    
    for i, row in signals.iterrows():
        if i % 50 == 0 and i > 0:
            elapsed = time.time() - start_t
            eta = elapsed / i * (len(signals) - i)
            print(f"  [{i+1}/{len(signals)}] {row['symbol']:<14} ETA {eta:.0f}s")
        
        symbol = row["symbol"]
        signal_date = row["signal_date"]
        prev_close = row["prev_close"]
        
        # Load intraday bars (signal date - 1 to + 10 days)
        bars = load_intraday_bars(
            symbol,
            signal_date - pd.Timedelta(days=1),
            signal_date + pd.Timedelta(days=10),
        )
        if bars is None or len(bars) == 0:
            n_skipped += 1
            continue
        
        # Run each strategy
        for strat_name, strat_fn in STRATEGIES.items():
            # Call with right signature
            try:
                if strat_name in ("GAP_FADE", "LIMIT_AT_PREVCLOSE"):
                    entry = strat_fn(signal_date, bars, prev_close)
                else:
                    entry = strat_fn(signal_date, bars)
            except Exception as e:
                entry = None
            
            if entry is None:
                # Strategy chose to skip
                all_trades.append({
                    "symbol": symbol,
                    "signal_date": signal_date,
                    "probability": row["prob"],
                    "regime": row["stock_regime"],
                    "slice": row["slice"],
                    "cluster_liquidity": row["cluster_liquidity"],
                    "cluster_volatility": row["cluster_volatility"],
                    "cluster_trend": row["cluster_trend"],
                    "cluster_combined": row["cluster_combined"],
                    "strategy": strat_name,
                    "stop_philosophy": "N/A",
                    "entry_time": None,
                    "entry_price": None,
                    "exit_time": None,
                    "exit_price": None,
                    "exit_reason": "SKIPPED_BY_STRATEGY",
                    "gross_ret_pct": 0,
                    "net_ret_pct": 0,
                    "is_win": 0,
                    "days_held": 0,
                })
                continue
            
            # Run both stop philosophies
            for stop_name, stop_cfg in STOP_PHILOSOPHIES.items():
                exit_info = simulate_exit(entry["entry_price"], entry["entry_time"], bars, stop_cfg)
                
                gross_ret = (exit_info["exit_price"] / entry["entry_price"] - 1) * 100
                cost = COST_BPS_ROUND_TRIP / 100 + 2 * SLIPPAGE_BPS_PER_SIDE / 100
                net_ret = gross_ret - cost
                days_held = (exit_info["exit_time"].date() - entry["entry_time"].date()).days
                
                all_trades.append({
                    "symbol": symbol,
                    "signal_date": signal_date,
                    "probability": row["prob"],
                    "regime": row["stock_regime"],
                    "slice": row["slice"],
                    "cluster_liquidity": row["cluster_liquidity"],
                    "cluster_volatility": row["cluster_volatility"],
                    "cluster_trend": row["cluster_trend"],
                    "cluster_combined": row["cluster_combined"],
                    "strategy": strat_name,
                    "stop_philosophy": stop_name,
                    "entry_time": entry["entry_time"],
                    "entry_price": round(entry["entry_price"], 2),
                    "exit_time": exit_info["exit_time"],
                    "exit_price": round(exit_info["exit_price"], 2),
                    "exit_reason": exit_info["exit_reason"],
                    "gross_ret_pct": round(gross_ret, 3),
                    "net_ret_pct": round(net_ret, 3),
                    "is_win": int(net_ret > 0),
                    "days_held": days_held,
                })
    
    print(f"\n  Skipped (no intraday data): {n_skipped}")
    print(f"  Total trade records: {len(all_trades):,}")
    
    if len(all_trades) == 0:
        print("\nNo trades simulated. Check that intraday data matches signal symbols.")
        return
    
    trades_df = pd.DataFrame(all_trades)
    
    # =========================================================================
    # ANALYSIS
    # =========================================================================
    
    print(f"\n[4/5] Computing strategy performance...")
    
    # 1. Overall strategy comparison (validation slice only)
    val = trades_df[(trades_df["slice"] == "VALIDATION") & (trades_df["entry_price"].notna())]
    
    overall_rows = []
    for strat in STRATEGIES:
        for stop in STOP_PHILOSOPHIES:
            sub = val[(val["strategy"] == strat) & (val["stop_philosophy"] == stop)]
            if len(sub) == 0:
                continue
            rets = sub["net_ret_pct"].values
            overall_rows.append({
                "strategy": strat,
                "stop": stop,
                "n_trades": len(sub),
                "fill_rate_pct": round(100 * len(sub) / max((val["strategy"] == strat).sum() / 2, 1), 1),
                "win_rate_pct": round(100 * (rets > 0).mean(), 2),
                "avg_net_pct": round(rets.mean(), 3),
                "median_net_pct": round(np.median(rets), 3),
                "std_pct": round(rets.std(), 3),
                "sharpe_annual": round(rets.mean() / (rets.std() + 1e-9) * np.sqrt(50), 2),
                "worst_pct": round(rets.min(), 2),
                "best_pct": round(rets.max(), 2),
            })
    overall_df = pd.DataFrame(overall_rows).sort_values("sharpe_annual", ascending=False)
    
    # 2. Per-cluster winning strategy (validation slice)
    cluster_rows = []
    for (liq, vol, trend), grp in val.groupby(["cluster_liquidity", "cluster_volatility", "cluster_trend"]):
        for strat in STRATEGIES:
            for stop in STOP_PHILOSOPHIES:
                sub = grp[(grp["strategy"] == strat) & (grp["stop_philosophy"] == stop)]
                if len(sub) < 10:  # min sample for reliability
                    continue
                rets = sub["net_ret_pct"].values
                cluster_rows.append({
                    "cluster_liquidity": liq,
                    "cluster_volatility": vol,
                    "cluster_trend": trend,
                    "strategy": strat,
                    "stop": stop,
                    "n_trades": len(sub),
                    "avg_net_pct": round(rets.mean(), 3),
                    "sharpe": round(rets.mean() / (rets.std() + 1e-9) * np.sqrt(50), 2),
                })
    cluster_df = pd.DataFrame(cluster_rows)
    
    # 3. Best strategy per cluster (highest Sharpe, validation slice)
    if len(cluster_df) > 0:
        idx = cluster_df.groupby(["cluster_liquidity", "cluster_volatility", "cluster_trend"])["sharpe"].idxmax()
        best_per_cluster = cluster_df.loc[idx].reset_index(drop=True)
    else:
        best_per_cluster = pd.DataFrame()
    
    # 4. OOS verification: apply chosen strategies to OOS slice
    oos = trades_df[(trades_df["slice"] == "OOS") & (trades_df["entry_price"].notna())]
    
    oos_verify_rows = []
    if len(best_per_cluster) > 0 and len(oos) > 0:
        for _, row in best_per_cluster.iterrows():
            sub = oos[
                (oos["cluster_liquidity"] == row["cluster_liquidity"]) &
                (oos["cluster_volatility"] == row["cluster_volatility"]) &
                (oos["cluster_trend"] == row["cluster_trend"]) &
                (oos["strategy"] == row["strategy"]) &
                (oos["stop_philosophy"] == row["stop"])
            ]
            if len(sub) < 5:
                continue
            rets = sub["net_ret_pct"].values
            oos_verify_rows.append({
                "cluster_liquidity": row["cluster_liquidity"],
                "cluster_volatility": row["cluster_volatility"],
                "cluster_trend": row["cluster_trend"],
                "chosen_strategy": row["strategy"],
                "chosen_stop": row["stop"],
                "val_avg_net": row["avg_net_pct"],
                "val_sharpe": row["sharpe"],
                "oos_n_trades": len(sub),
                "oos_avg_net": round(rets.mean(), 3),
                "oos_sharpe": round(rets.mean() / (rets.std() + 1e-9) * np.sqrt(50), 2),
                "edge_persistence": "GOOD" if rets.mean() >= row["avg_net_pct"] * 0.5 else "DECAYED",
            })
    oos_verify_df = pd.DataFrame(oos_verify_rows)
    
    # =========================================================================
    # SAVE
    # =========================================================================
    
    print(f"\n[5/5] Saving outputs...")
    
    def strip_tz(df):
        if df is None or len(df) == 0:
            return df
        out = df.copy()
        for c in out.columns:
            try:
                if pd.api.types.is_datetime64_any_dtype(out[c]):
                    if out[c].dt.tz is not None:
                        out[c] = out[c].dt.tz_localize(None)
            except Exception:
                pass
        return out
    
    trades_df.to_csv(OUT_DIR / "all_trades.csv", index=False)
    overall_df.to_csv(OUT_DIR / "overall_validation.csv", index=False)
    cluster_df.to_csv(OUT_DIR / "per_cluster_validation.csv", index=False)
    best_per_cluster.to_csv(OUT_DIR / "best_strategy_per_cluster.csv", index=False)
    oos_verify_df.to_csv(OUT_DIR / "oos_verification.csv", index=False)
    
    excel_path = OUT_DIR / "strategy_research.xlsx"
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        strip_tz(overall_df).to_excel(writer, sheet_name="01 Overall (Validation)", index=False)
        strip_tz(best_per_cluster).to_excel(writer, sheet_name="02 Best Per Cluster", index=False)
        strip_tz(oos_verify_df).to_excel(writer, sheet_name="03 OOS Verification", index=False)
        strip_tz(cluster_df).to_excel(writer, sheet_name="04 All Cluster Results", index=False)
    
    print(f"  CSVs saved: {OUT_DIR}")
    print(f"  Excel: {excel_path}")
    
    # =========================================================================
    # CONSOLE SUMMARY
    # =========================================================================
    
    print("\n" + "=" * 90)
    print("OVERALL STRATEGY RANKING (Validation slice)")
    print("=" * 90)
    print(f"{'Strategy':<22} {'Stop':<8} {'N':>6} {'Win%':>7} {'AvgNet%':>9} {'Sharpe':>8} {'Worst':>7}")
    print("-" * 90)
    for _, row in overall_df.head(15).iterrows():
        print(f"{row['strategy']:<22} {row['stop']:<8} {row['n_trades']:>6} "
              f"{row['win_rate_pct']:>7.1f} {row['avg_net_pct']:>+9.3f} "
              f"{row['sharpe_annual']:>8.2f} {row['worst_pct']:>+7.2f}")
    
    if len(best_per_cluster) > 0:
        print("\n" + "=" * 90)
        print("BEST STRATEGY PER CLUSTER (top 15 by Sharpe)")
        print("=" * 90)
        bpc_sorted = best_per_cluster.sort_values("sharpe", ascending=False)
        print(f"{'Liq':<10} {'Vol':<10} {'Trend':<14} {'Strategy':<20} {'Stop':<8} {'N':>5} {'AvgNet%':>9} {'Sharpe':>8}")
        print("-" * 90)
        for _, row in bpc_sorted.head(15).iterrows():
            print(f"{row['cluster_liquidity']:<10} {row['cluster_volatility']:<10} {row['cluster_trend']:<14} "
                  f"{row['strategy']:<20} {row['stop']:<8} {row['n_trades']:>5} "
                  f"{row['avg_net_pct']:>+9.3f} {row['sharpe']:>8.2f}")
    
    if len(oos_verify_df) > 0:
        print("\n" + "=" * 90)
        print("OOS VERIFICATION (does validation winner hold up on OOS?)")
        print("=" * 90)
        print(f"{'Cluster':<32} {'Strategy':<20} {'Val':>8} {'OOS':>8} {'Verdict':<10}")
        print("-" * 90)
        for _, row in oos_verify_df.iterrows():
            cluster_str = f"{row['cluster_liquidity']}_{row['cluster_volatility']}_{row['cluster_trend']}"
            print(f"{cluster_str:<32} {row['chosen_strategy']:<20} "
                  f"{row['val_avg_net']:>+8.2f} {row['oos_avg_net']:>+8.2f} "
                  f"{row['edge_persistence']:<10}")
    
    print("\n" + "=" * 90)
    print(f"Outputs: {OUT_DIR}")
    print("\nInterpretation guide:")
    print("  1. Overall winner: highest Sharpe in validation")
    print("  2. Per-cluster: which strategy works for which kind of stock")
    print("  3. OOS verification: did the winners actually hold up out-of-sample?")
    print("     - GOOD = OOS performance is at least half of validation")
    print("     - DECAYED = OOS far worse than validation (likely overfitting)")
    print("=" * 90)


if __name__ == "__main__":
    run_strategy_research()
