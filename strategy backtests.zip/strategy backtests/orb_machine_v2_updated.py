#!/usr/bin/env python3
"""
=============================================================================
ORB MACHINE v2 - CORRECTED with bug fixes + smart combo variants
=============================================================================

6 BUGS FIXED FROM v1:
  1. Signal/cache date alignment - signals must be within MAX_SIGNAL_TO_CACHE_GAP_DAYS
     of first available bar. This kills 300+ bogus trades where 2018 signals were
     entering in 2021+ because the 5-min cache window started then.
  
  2. days_held now computed in TRADING days (count of distinct dates between
     entry and exit), not calendar days. Previously showed 19 for "5-day strategy".
  
  3. bar_days uses TRADING-DAY INDEX from entry_day, not calendar offset.
     When cache has gaps, calendar offsets break completely.
  
  4. After-hours bars filtered out. Only bars during 9:15-15:30 IST are valid
     for entry. Previously bars at 12:00-13:00 UTC (after market close) were 
     accepted as legitimate entries.
  
  5. Corporate action outliers capped. Returns > +/-50% in 5 days are
     skipped as data errors. Previously a single 1342.56% trade polluted 
     multiple variant statistics.
  
  6. Dynamic mode bar-in-day index logic corrected. Now uses 
     np.sum(bar_days[:i] == day) instead of broken slice arithmetic.
  
  PLUS: Stop check happens BEFORE target check at every bar (can't fly 
  through stops to hit targets).

NEW IN v2 - FAMILY F (Smart Combos, based on v1 findings):
  F1: T+1 only + close above + no-reversal + 5% target
  F2: T+1 only + range_low stop + 2R target
  F3: T+1 + 15-min range + no-reversal + 5% target
  F4: T+1-T+2 + no-reversal + range_low stop
  F5: T+1 first-30-min breakout only + 5% target
  F6: T+1 only + no-reversal + 3% target (high win rate)
  F7: T+1 + held-EOD + 5% target

ALL 30 VARIANTS:
  A1-A4: Range definition (5/15/30/60-min)
  B1-B4: Watch period (T+1 only, T+1-2, T+1-5 static, T+1-5 dynamic)
  C1-C4: Confirmation (touch, close, 2x close, close+no-reversal)
  D1-D5: Stop placement (range_low, 3%, 5%, 7%, 2x range)
  E1-E6: Exit strategy (t5_close, 3%, 5%, 7%, 2R, rolling)
  F1-F7: Smart combinations

USAGE:
  python orb_machine_v2.py                  # full run (extracts + tests all 30)
  python orb_machine_v2.py --rebuild        # force re-extract
  python orb_machine_v2.py --skip-extract   # use existing extraction
  python orb_machine_v2.py --variant F1     # test single variant
  python orb_machine_v2.py --limit 500      # for quick testing
=============================================================================
"""

import os
import sys
import json
import time
import warnings
from pathlib import Path
from datetime import datetime, timedelta, time as dtime
from typing import Optional, List, Dict, Any, Tuple

import numpy as np
import pandas as pd
from joblib import load

warnings.filterwarnings("ignore")

# =============================================================================
# CONFIG
# =============================================================================

BASE_DIR = Path(r"C:\Users\karanvsi\Desktop\Kite Connect\v3_2_output_full")
PANEL_PATH = BASE_DIR / "panel_cache.parquet"
FEATURES_PATH = BASE_DIR / "features_train.json"
ROUTER_PATH = BASE_DIR / "models" / "m5_regime_router.joblib"

INTRADAY_DIR = Path(r"C:\Users\karanvsi\Desktop\Pycharm\Cache\intraday_5min")

OUT_DIR = BASE_DIR / "orb_machine_results_v2"
OUT_DIR.mkdir(parents=True, exist_ok=True)

EXTRACTED_PATHS_FILE = OUT_DIR / "extracted_paths_v2.parquet"
DIAGNOSTICS_FILE = OUT_DIR / "extraction_diagnostics.csv"

IST = "Asia/Kolkata"

# Signal filtering
SIGNAL_PROB_MIN = 0.75
SIGNAL_REGIMES = ["bull_trend", "bear_trend"]

# Holding period
HOLDING_DAYS = 5
EXTENDED_DAYS = 10  # extra bars for rolling exits

# Cost assumptions
COST_BPS_ROUND_TRIP = 25
SLIPPAGE_BPS_PER_SIDE = 5

# Validation
VALIDATION_FRACTION = 0.30
RECENT_MONTHS = 18
MIN_TRADES_FOR_VARIANT = 30
SHARPE_PERIODS_PER_YEAR = 50

# FIX 1: Signal must be within N days of cache start to be valid
MAX_SIGNAL_TO_CACHE_GAP_DAYS = 3

# FIX 4: Market hours in IST
IST_MARKET_OPEN_HOUR = 9
IST_MARKET_OPEN_MIN = 15
IST_MARKET_CLOSE_HOUR = 15
IST_MARKET_CLOSE_MIN = 30

# FIX 5: Outlier cap (corporate action sanity)
MAX_PLAUSIBLE_RETURN_PCT = 50.0   # 50% in 5 days already extreme
MIN_PLAUSIBLE_RETURN_PCT = -50.0

# Minimum bars per day to consider day valid (75 expected for 5-min in 6.25 hours)
MIN_BARS_PER_DAY = 50


RANGE_DEFINITIONS = {
    "5min":  {"label": "5-min (9:15-9:20)",   "end_time": "09:20", "bars_needed": 1},
    "15min": {"label": "15-min (9:15-9:30)",  "end_time": "09:30", "bars_needed": 3},
    "30min": {"label": "30-min (9:15-9:45)",  "end_time": "09:45", "bars_needed": 6},
    "60min": {"label": "60-min (9:15-10:15)", "end_time": "10:15", "bars_needed": 12},
}


# =============================================================================
# VARIANT PRESETS - 30 variants (23 originals + 7 smart combos)
# =============================================================================

VARIANT_PRESETS = {
    # FAMILY A: Range Definition
    "A1_range_5min": {
        "family": "A: Range Definition", "label": "5-min range",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "A2_range_15min": {
        "family": "A: Range Definition", "label": "15-min range",
        "range_def": "15min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "A3_range_30min": {
        "family": "A: Range Definition", "label": "30-min range",
        "range_def": "30min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "A4_range_60min": {
        "family": "A: Range Definition", "label": "60-min range",
        "range_def": "60min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    
    # FAMILY B: Watch Period
    "B1_watch_t1_only": {
        "family": "B: Watch Period", "label": "T+1 only (intraday)",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "B2_watch_t1_t2": {
        "family": "B: Watch Period", "label": "T+1 to T+2",
        "range_def": "5min", "watch_mode": "window_2d", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "B3_watch_t1_t5_static": {
        "family": "B: Watch Period", "label": "T+1 to T+5 (static T+1 range)",
        "range_def": "5min", "watch_mode": "static_t1_5d", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "B4_watch_t1_t5_dynamic": {
        "family": "B: Watch Period", "label": "T+1 to T+5 (each day own range)",
        "range_def": "5min", "watch_mode": "dynamic_each_day", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    
    # FAMILY C: Breakout Confirmation
    "C1_confirm_touch": {
        "family": "C: Breakout Confirmation", "label": "Touch above range high",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "touch_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "C2_confirm_close": {
        "family": "C: Breakout Confirmation", "label": "Close above (standard)",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "C3_confirm_2x_close": {
        "family": "C: Breakout Confirmation", "label": "2 consecutive closes above",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "two_consecutive",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "C4_confirm_no_reversal": {
        "family": "C: Breakout Confirmation", "label": "Close above + no 30min reversal",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_no_reversal",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    
    # FAMILY D: Stop Placement
    "D1_stop_range_low": {
        "family": "D: Stop Placement", "label": "Stop at range low",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "D2_stop_3pct": {
        "family": "D: Stop Placement", "label": "Stop -3% from entry",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "fixed_3pct", "exit_mode": "t5_close",
    },
    "D3_stop_5pct": {
        "family": "D: Stop Placement", "label": "Stop -5% from entry",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "fixed_5pct", "exit_mode": "t5_close",
    },
    "D4_stop_7pct": {
        "family": "D: Stop Placement", "label": "Stop -7% from entry",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "fixed_7pct", "exit_mode": "t5_close",
    },
    "D5_stop_2x_range": {
        "family": "D: Stop Placement", "label": "Stop = 2x range size below entry",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "two_range_size", "exit_mode": "t5_close",
    },
    
    # FAMILY E: Exit Strategy
    "E1_exit_t5_close": {
        "family": "E: Exit Strategy", "label": "Hold to T+5 close",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "E2_exit_target_3pct": {
        "family": "E: Exit Strategy", "label": "Exit at +3% target or T+5",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "target_3pct",
    },
    "E3_exit_target_5pct": {
        "family": "E: Exit Strategy", "label": "Exit at +5% target or T+5",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "target_5pct",
    },
    "E4_exit_target_7pct": {
        "family": "E: Exit Strategy", "label": "Exit at +7% target or T+5",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "target_7pct",
    },
    "E5_exit_target_2r": {
        "family": "E: Exit Strategy", "label": "Exit at 2R target or T+5",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "target_2r",
    },
    "E6_exit_rolling_5d": {
        "family": "E: Exit Strategy", "label": "Rolling 5-day exit from entry",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "rolling_5d",
    },
    
    # FAMILY F: SMART COMBINATIONS (NEW, based on v1 findings)
    "F1_t1_noreversal_5pct": {
        "family": "F: Smart Combos",
        "label": "T+1 + no-reversal + 5% target",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_no_reversal",
        "stop_mode": "range_low", "exit_mode": "target_5pct",
    },
    "F2_t1_2r_target": {
        "family": "F: Smart Combos",
        "label": "T+1 + range_low stop + 2R target",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "target_2r",
    },
    "F3_t1_15min_noreversal_5pct": {
        "family": "F: Smart Combos",
        "label": "T+1 + 15-min range + no-reversal + 5%",
        "range_def": "15min", "watch_mode": "t1_only", "confirm": "close_no_reversal",
        "stop_mode": "range_low", "exit_mode": "target_5pct",
    },
    "F4_t1t2_noreversal_rangelow": {
        "family": "F: Smart Combos",
        "label": "T+1-T+2 + no-reversal + range_low",
        "range_def": "5min", "watch_mode": "window_2d", "confirm": "close_no_reversal",
        "stop_mode": "range_low", "exit_mode": "t5_close",
    },
    "F5_t1_first30min_5pct": {
        "family": "F: Smart Combos",
        "label": "T+1 first-30-min + 5% target",
        "range_def": "5min", "watch_mode": "t1_first_30min", "confirm": "close_above",
        "stop_mode": "range_low", "exit_mode": "target_5pct",
    },
    "F6_t1_noreversal_3pct": {
        "family": "F: Smart Combos",
        "label": "T+1 + no-reversal + 3% target",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_no_reversal",
        "stop_mode": "range_low", "exit_mode": "target_3pct",
    },
    "F7_t1_heldEOD_5pct": {
        "family": "F: Smart Combos",
        "label": "T+1 + held-EOD + 5% target",
        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_held_eod",
        "stop_mode": "range_low", "exit_mode": "target_5pct",
    },
}


# =============================================================================
# HELPERS
# =============================================================================

def time_to_ts(date: pd.Timestamp, time_str: str) -> pd.Timestamp:
    h, m = map(int, time_str.split(":"))
    return date.replace(hour=h, minute=m, second=0, microsecond=0)


def apply_costs(returns: np.ndarray) -> np.ndarray:
    cost = COST_BPS_ROUND_TRIP / 100
    slip = 2 * SLIPPAGE_BPS_PER_SIDE / 100
    return returns - cost - slip


def compute_metrics(returns: np.ndarray, label: str = "") -> Dict[str, Any]:
    if len(returns) == 0:
        return {"label": label, "n": 0}
    wins = returns > 0
    losses = ~wins
    return {
        "label": label,
        "n": len(returns),
        "win_rate_pct": round(100 * wins.mean(), 2),
        "avg_ret_pct": round(returns.mean(), 3),
        "median_ret_pct": round(np.median(returns), 3),
        "avg_win_pct": round(returns[wins].mean() if wins.any() else 0, 3),
        "avg_loss_pct": round(returns[losses].mean() if losses.any() else 0, 3),
        "std_pct": round(returns.std(), 3),
        "sharpe_per_trade": round(returns.mean() / (returns.std() + 1e-9), 3),
        "sharpe_annual": round(returns.mean() / (returns.std() + 1e-9) * np.sqrt(SHARPE_PERIODS_PER_YEAR), 2),
        "min_ret": round(returns.min(), 2),
        "max_ret": round(returns.max(), 2),
        "p10": round(np.percentile(returns, 10), 2),
        "p90": round(np.percentile(returns, 90), 2),
    }


def filter_market_hours(bars: pd.DataFrame) -> pd.DataFrame:
    """FIX 4: Keep only bars during IST market hours (9:15-15:30)."""
    if len(bars) == 0:
        return bars
    ts = bars["timestamp"]
    if ts.dt.tz is not None:
        ts_ist = ts.dt.tz_convert(IST)
    else:
        ts_ist = ts
    
    hours = ts_ist.dt.hour
    mins = ts_ist.dt.minute
    time_float = hours + mins / 60.0
    market_open_float = IST_MARKET_OPEN_HOUR + IST_MARKET_OPEN_MIN / 60.0
    market_close_float = IST_MARKET_CLOSE_HOUR + IST_MARKET_CLOSE_MIN / 60.0
    
    mask = (time_float >= market_open_float) & (time_float <= market_close_float)
    return bars[mask].reset_index(drop=True)


def daily_bars(bars: pd.DataFrame, date: pd.Timestamp) -> pd.DataFrame:
    return bars[bars["timestamp"].dt.normalize() == date.normalize()]


# =============================================================================
# SIGNAL GENERATION
# =============================================================================

def generate_signals() -> pd.DataFrame:
    print("\n[1/3] Generating high-conviction signals from model...")
    
    panel = pd.read_parquet(PANEL_PATH)
    panel["timestamp"] = pd.to_datetime(panel["timestamp"])
    if panel["timestamp"].dt.tz is None:
        panel["timestamp"] = panel["timestamp"].dt.tz_localize(IST)
    
    if "stock_regime" not in panel.columns:
        raise SystemExit("FATAL: panel missing stock_regime. Run enrich_panel.py first.")
    
    panel = panel.sort_values(["symbol", "timestamp"]).reset_index(drop=True)
    panel["avg20_vol"] = (
        panel.groupby("symbol")["volume"]
             .transform(lambda s: s.rolling(20, min_periods=1).mean())
    )
    panel = panel[(panel["close"] >= 2.0) & (panel["avg20_vol"] >= 200_000)].reset_index(drop=True)
    panel_trend = panel[panel["stock_regime"].isin(SIGNAL_REGIMES)].copy()
    
    schema = json.loads(FEATURES_PATH.read_text())
    FEATURES = schema["features"]
    IMPUTE = {k: float(v) for k, v in schema["impute"].items()}
    
    print(f"  Loading router and scoring {len(panel_trend):,} trend-regime rows...")
    router = load(ROUTER_PATH)
    
    X = panel_trend.reindex(columns=FEATURES).copy()
    for c in FEATURES:
        X[c] = pd.to_numeric(X[c], errors="coerce").fillna(IMPUTE.get(c, 0.0))
    
    if hasattr(router, "predict_proba_by_regime"):
        probs = router.predict_proba_by_regime(X, panel_trend["stock_regime"])
    else:
        raise SystemExit("FATAL: router missing predict_proba_by_regime method")
    
    panel_trend["prob"] = probs
    signals = panel_trend[panel_trend["prob"] >= SIGNAL_PROB_MIN].copy()
    signals = signals[["symbol", "timestamp", "close", "prob", "stock_regime"]].copy()
    signals.columns = ["symbol", "signal_date", "prev_close", "probability", "regime"]
    
    print(f"  High-conviction signals: {len(signals):,}")
    print(f"  Date range: {signals['signal_date'].min().date()} to {signals['signal_date'].max().date()}")
    
    return signals


def load_bars(symbol: str, start_date, end_date) -> Optional[pd.DataFrame]:
    file_path = INTRADAY_DIR / f"{symbol}.parquet"
    if not file_path.exists():
        return None
    try:
        df = pd.read_parquet(file_path)
    except Exception:
        return None
    if len(df) == 0:
        return None
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    if df["timestamp"].dt.tz is None:
        df["timestamp"] = df["timestamp"].dt.tz_localize(IST)
    else:
        df["timestamp"] = df["timestamp"].dt.tz_convert(IST)
    mask = (df["timestamp"] >= start_date) & (df["timestamp"] <= end_date)
    df = df[mask].sort_values("timestamp").reset_index(drop=True)
    
    # FIX 4: Filter to market hours only
    df = filter_market_hours(df)
    
    return df if len(df) > 0 else None


# =============================================================================
# EXTRACTION - CORRECTED
# =============================================================================

def extract_signal_paths(symbol: str, signal_date: pd.Timestamp, probability: float,
                         regime: str, prev_close: float, bars: pd.DataFrame,
                         diagnostics: Dict) -> Optional[Dict]:
    """
    CORRECTED extraction with all 6 bug fixes integrated.
    Returns dict or None if signal should be filtered.
    """
    
    if len(bars) == 0:
        diagnostics["no_bars_at_all"] += 1
        return None
    
    # FIX 1a: Check signal date is within cache range
    cache_start = bars["timestamp"].min().normalize()
    cache_end = bars["timestamp"].max().normalize()
    sig_date_norm = signal_date.normalize()
    
    # Normalize tz for comparison
    if hasattr(cache_start, 'tz') and cache_start.tz is not None:
        cache_start = cache_start.tz_convert(IST).tz_localize(None)
        cache_end = cache_end.tz_convert(IST).tz_localize(None)
    if hasattr(sig_date_norm, 'tz') and sig_date_norm.tz is not None:
        sig_date_norm = sig_date_norm.tz_convert(IST).tz_localize(None)
    
    if sig_date_norm < cache_start - pd.Timedelta(days=MAX_SIGNAL_TO_CACHE_GAP_DAYS):
        diagnostics["signal_before_cache"] += 1
        return None
    
    if sig_date_norm > cache_end:
        diagnostics["signal_after_cache"] += 1
        return None
    
    # FIX 1b: Get bars after signal, verify they're proximate
    bars_after_signal = bars[bars["timestamp"].dt.normalize() > signal_date.normalize()]
    if len(bars_after_signal) == 0:
        diagnostics["no_bars_after_signal"] += 1
        return None
    
    first_bar_date = bars_after_signal["timestamp"].dt.normalize().iloc[0]
    if hasattr(first_bar_date, 'tz') and first_bar_date.tz is not None:
        first_bar_date = first_bar_date.tz_convert(IST).tz_localize(None)
    
    gap_days = (first_bar_date - sig_date_norm).days
    if gap_days > MAX_SIGNAL_TO_CACHE_GAP_DAYS:
        diagnostics["signal_too_far_from_next_bars"] += 1
        return None
    
    # Get unique trading days
    unique_days = sorted(bars_after_signal["timestamp"].dt.normalize().unique())
    if len(unique_days) < HOLDING_DAYS:
        diagnostics["insufficient_holding_days"] += 1
        return None
    
    extended_days = unique_days[:min(EXTENDED_DAYS, len(unique_days))]
    extended_bars = bars[bars["timestamp"].dt.normalize().isin(extended_days)].reset_index(drop=True)
    
    entry_day = extended_days[0]
    entry_day_bars = daily_bars(extended_bars, entry_day)
    
    # FIX 6: Require minimum bars on entry day
    if len(entry_day_bars) < MIN_BARS_PER_DAY:
        diagnostics["insufficient_entry_day_bars"] += 1
        return None
    
    record = {
        "symbol": symbol,
        "signal_date": signal_date,
        "entry_day": entry_day,
        "probability": probability,
        "regime": regime,
        "prev_close": prev_close,
        "n_extended_days": len(extended_days),
    }
    
    # Per-day metrics
    for day_idx, day in enumerate(extended_days[:HOLDING_DAYS], start=1):
        day_bars = daily_bars(extended_bars, day)
        if len(day_bars) > 0:
            record[f"d{day_idx}_open"] = day_bars.iloc[0]["open"]
            record[f"d{day_idx}_high"] = day_bars["high"].max()
            record[f"d{day_idx}_low"] = day_bars["low"].min()
            record[f"d{day_idx}_close"] = day_bars.iloc[-1]["close"]
            record[f"d{day_idx}_date"] = day
            
            for rng_name, rng_def in RANGE_DEFINITIONS.items():
                end_ts = time_to_ts(day, rng_def["end_time"])
                rng_bars = day_bars[day_bars["timestamp"] <= end_ts]
                if len(rng_bars) >= rng_def["bars_needed"]:
                    record[f"d{day_idx}_orh_{rng_name}"] = rng_bars["high"].max()
                    record[f"d{day_idx}_orl_{rng_name}"] = rng_bars["low"].min()
                else:
                    record[f"d{day_idx}_orh_{rng_name}"] = np.nan
                    record[f"d{day_idx}_orl_{rng_name}"] = np.nan
    
    # T+1's ranges (for static modes)
    for rng_name, rng_def in RANGE_DEFINITIONS.items():
        end_ts = time_to_ts(entry_day, rng_def["end_time"])
        rng_bars = entry_day_bars[entry_day_bars["timestamp"] <= end_ts]
        if len(rng_bars) >= rng_def["bars_needed"]:
            record[f"t1_orh_{rng_name}"] = rng_bars["high"].max()
            record[f"t1_orl_{rng_name}"] = rng_bars["low"].min()
        else:
            record[f"t1_orh_{rng_name}"] = np.nan
            record[f"t1_orl_{rng_name}"] = np.nan
    
    hold_bars = extended_bars.sort_values("timestamp").reset_index(drop=True)
    
    # FIX 3: bar_days as TRADING DAY INDEX (0 = entry day, 1 = next trading day)
    # Use day-to-index mapping to handle gaps
    extended_days_sorted = sorted({d.normalize() for d in extended_days})
    day_to_idx = {d: i for i, d in enumerate(extended_days_sorted)}
    
    bar_days_arr = np.array([
        day_to_idx.get(ts.normalize(), -1) for ts in hold_bars["timestamp"]
    ], dtype=int)
    
    record["bar_timestamps"] = hold_bars["timestamp"].astype("int64").tolist()
    record["bar_opens"] = hold_bars["open"].tolist()
    record["bar_highs"] = hold_bars["high"].tolist()
    record["bar_lows"] = hold_bars["low"].tolist()
    record["bar_closes"] = hold_bars["close"].tolist()
    record["bar_days"] = bar_days_arr.tolist()
    
    diagnostics["success"] += 1
    return record


def run_extraction(signals: pd.DataFrame) -> pd.DataFrame:
    print(f"\n[2/3] Extracting intraday paths for {len(signals)} signals...")
    
    diagnostics = {
        "no_bars_at_all": 0,
        "signal_before_cache": 0,
        "signal_after_cache": 0,
        "no_bars_after_signal": 0,
        "signal_too_far_from_next_bars": 0,
        "insufficient_holding_days": 0,
        "insufficient_entry_day_bars": 0,
        "success": 0,
    }
    
    results = []
    n_no_symbol_data = 0
    t_start = time.time()
    
    signals_by_symbol = signals.groupby("symbol")
    
    for sym_idx, (symbol, sym_signals) in enumerate(signals_by_symbol):
        if sym_idx % 50 == 0 and sym_idx > 0:
            elapsed = time.time() - t_start
            rate = sym_idx / elapsed
            eta = (len(signals_by_symbol) - sym_idx) / rate if rate > 0 else 0
            print(f"  [{sym_idx}/{len(signals_by_symbol)}] elapsed={elapsed/60:.1f}m  "
                  f"ETA={eta/60:.1f}m  extracted={diagnostics['success']}")
        
        min_date = sym_signals["signal_date"].min() - pd.Timedelta(days=1)
        max_date = sym_signals["signal_date"].max() + pd.Timedelta(days=20)
        bars = load_bars(symbol, min_date, max_date)
        
        if bars is None or len(bars) == 0:
            n_no_symbol_data += len(sym_signals)
            continue
        
        for _, row in sym_signals.iterrows():
            try:
                rec = extract_signal_paths(
                    symbol=symbol,
                    signal_date=row["signal_date"],
                    probability=row["probability"],
                    regime=row["regime"],
                    prev_close=row["prev_close"],
                    bars=bars,
                    diagnostics=diagnostics,
                )
                if rec is not None:
                    results.append(rec)
            except Exception as e:
                print(f"  ERROR on {symbol} {row['signal_date'].date()}: {e}")
    
    elapsed = time.time() - t_start
    
    print(f"\n  EXTRACTION DIAGNOSTICS:")
    print(f"  ---------------------------------")
    print(f"  Symbols with no data:           {n_no_symbol_data}")
    for k, v in diagnostics.items():
        print(f"  {k:<35} {v}")
    print(f"  ---------------------------------")
    print(f"  Total extracted: {len(results)}")
    print(f"  Time: {elapsed/60:.1f} min")
    
    # Save diagnostics
    diag_rows = [{"reason": k, "count": v} for k, v in diagnostics.items()]
    diag_rows.insert(0, {"reason": "no_symbol_data", "count": n_no_symbol_data})
    pd.DataFrame(diag_rows).to_csv(DIAGNOSTICS_FILE, index=False)
    
    df = pd.DataFrame(results)
    
    # Strip tz
    for c in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[c]):
            try:
                if df[c].dt.tz is not None:
                    df[c] = df[c].dt.tz_localize(None)
            except Exception:
                pass
    
    df.to_parquet(EXTRACTED_PATHS_FILE, index=False)
    print(f"  Saved: {EXTRACTED_PATHS_FILE}")
    
    return df


# =============================================================================
# VARIANT SIMULATOR - CORRECTED
# =============================================================================

def simulate_variant(paths_df: pd.DataFrame, variant: Dict[str, Any]) -> pd.DataFrame:
    """
    CORRECTED simulator. Per-signal logic:
      - Determine watch period (which days to look for breakout)
      - Determine active range (static T+1 or dynamic per-day)
      - Find first breakout bar matching confirm rule
      - Set stop and target prices
      - Walk forward: check STOP first, then target, then time exit
      - Apply outlier cap
    """
    results = []
    
    range_def = variant["range_def"]
    watch_mode = variant["watch_mode"]
    confirm = variant["confirm"]
    stop_mode = variant["stop_mode"]
    exit_mode = variant["exit_mode"]
    
    bars_needed_for_range = RANGE_DEFINITIONS[range_def]["bars_needed"]
    
    for _, sig in paths_df.iterrows():
        if not isinstance(sig.get("bar_timestamps"), (list, np.ndarray)):
            continue
        
        bar_ts = pd.to_datetime(sig["bar_timestamps"], unit="ns")
        bar_opens = np.array(sig["bar_opens"])
        bar_highs = np.array(sig["bar_highs"])
        bar_lows = np.array(sig["bar_lows"])
        bar_closes = np.array(sig["bar_closes"])
        bar_days = np.array(sig["bar_days"])
        
        n_bars = len(bar_ts)
        if n_bars < 20:
            continue
        
        # Determine watch parameters
        if watch_mode == "t1_only" or watch_mode == "t1_first_30min":
            watch_max_day = 1
            use_dynamic_range = False
        elif watch_mode == "window_2d":
            watch_max_day = 2
            use_dynamic_range = False
        elif watch_mode == "static_t1_5d":
            watch_max_day = HOLDING_DAYS
            use_dynamic_range = False
        elif watch_mode == "dynamic_each_day":
            watch_max_day = HOLDING_DAYS
            use_dynamic_range = True
        else:
            continue
        
        # Static range from T+1
        if not use_dynamic_range:
            orh = sig.get(f"t1_orh_{range_def}")
            orl = sig.get(f"t1_orl_{range_def}")
            if pd.isna(orh) or pd.isna(orl) or orh <= orl:
                continue
        
        # Find first breakout
        entry_idx = None
        entry_price = None
        entry_orh = None
        entry_orl = None
        
        for i in range(n_bars):
            day = int(bar_days[i])
            if day < 0 or day >= watch_max_day:
                continue
            
            # F5: limit to first 30 min of T+1
            if watch_mode == "t1_first_30min":
                ts = bar_ts[i]
                if ts.tz is None:
                    ts_ist = ts.tz_localize(IST)
                else:
                    ts_ist = ts.tz_convert(IST)
                # 9:15 + 30 min = 9:45 IST
                if ts_ist.hour > 9 or (ts_ist.hour == 9 and ts_ist.minute > 45):
                    break  # past first 30 min on T+1
            
            # Get active range
            if use_dynamic_range:
                day_label = day + 1
                day_orh = sig.get(f"d{day_label}_orh_{range_def}")
                day_orl = sig.get(f"d{day_label}_orl_{range_def}")
                if pd.isna(day_orh) or pd.isna(day_orl):
                    continue
                
                # FIX 6: count bars on THIS day before this bar
                same_day_bars_before = np.sum(bar_days[:i] == day)
                if same_day_bars_before < bars_needed_for_range:
                    continue
                
                active_orh = day_orh
                active_orl = day_orl
            else:
                # Skip bars within the range definition period on T+1
                if day == 0:
                    same_day_bars_before = np.sum(bar_days[:i] == 0)
                    if same_day_bars_before < bars_needed_for_range:
                        continue
                active_orh = orh
                active_orl = orl
            
            # Check breakout
            triggered = False
            if confirm == "touch_above":
                if bar_highs[i] > active_orh:
                    triggered = True
            elif confirm == "close_above":
                if bar_closes[i] > active_orh:
                    triggered = True
            elif confirm == "two_consecutive":
                if i > 0 and bar_closes[i] > active_orh and bar_closes[i-1] > active_orh:
                    triggered = True
            elif confirm == "close_no_reversal":
                if bar_closes[i] > active_orh:
                    reversal = False
                    for j in range(i+1, min(i+7, n_bars)):
                        if bar_closes[j] < active_orh:
                            reversal = True
                            break
                    if not reversal:
                        triggered = True
            elif confirm == "close_held_eod":
                if bar_closes[i] > active_orh:
                    # Verify same-day EOD close still above
                    same_day_idxs = np.where(bar_days == day)[0]
                    if len(same_day_idxs) > 0:
                        last_bar_of_day = same_day_idxs[-1]
                        if bar_closes[last_bar_of_day] > active_orh:
                            triggered = True
            
            if triggered:
                entry_idx = i
                entry_price = bar_closes[i]
                entry_orh = active_orh
                entry_orl = active_orl
                break
        
        if entry_idx is None or entry_price is None or entry_price <= 0:
            continue
        
        # Determine stop
        if stop_mode == "range_low":
            stop_price = entry_orl
            stop_pct_from_entry = (stop_price / entry_price - 1) * 100
            if stop_price >= entry_price:
                continue
        elif stop_mode == "fixed_3pct":
            stop_pct_from_entry = -3.0
            stop_price = entry_price * 0.97
        elif stop_mode == "fixed_5pct":
            stop_pct_from_entry = -5.0
            stop_price = entry_price * 0.95
        elif stop_mode == "fixed_7pct":
            stop_pct_from_entry = -7.0
            stop_price = entry_price * 0.93
        elif stop_mode == "two_range_size":
            range_size = entry_orh - entry_orl
            stop_price = entry_price - 2 * range_size
            stop_pct_from_entry = (stop_price / entry_price - 1) * 100
            if stop_price >= entry_price:
                continue
        else:
            continue
        
        # Target if applicable
        target_price = None
        if exit_mode == "target_3pct":
            target_price = entry_price * 1.03
        elif exit_mode == "target_5pct":
            target_price = entry_price * 1.05
        elif exit_mode == "target_7pct":
            target_price = entry_price * 1.07
        elif exit_mode == "target_2r":
            range_size = entry_orh - entry_orl
            target_price = entry_price + 2 * range_size
        
        # Exit logic - STOP CHECK BEFORE TARGET (critical fix)
        exit_price = None
        exit_idx = None
        trigger_reason = None
        
        if exit_mode == "t5_close":
            for j in range(entry_idx + 1, n_bars):
                if bar_lows[j] <= stop_price:
                    exit_price = stop_price
                    exit_idx = j
                    trigger_reason = "stop"
                    break
                # T+5 close - check if this is the last bar of T+5 (day index 4)
                if bar_days[j] >= HOLDING_DAYS - 1:
                    if j == n_bars - 1 or bar_days[j+1] > HOLDING_DAYS - 1:
                        exit_price = bar_closes[j]
                        exit_idx = j
                        trigger_reason = "time"
                        break
            if exit_price is None:
                exit_price = bar_closes[-1]
                exit_idx = n_bars - 1
                trigger_reason = "time"
        
        elif exit_mode in ("target_3pct", "target_5pct", "target_7pct", "target_2r"):
            for j in range(entry_idx + 1, n_bars):
                # STOP FIRST
                if bar_lows[j] <= stop_price:
                    exit_price = stop_price
                    exit_idx = j
                    trigger_reason = "stop"
                    break
                # TARGET SECOND
                if bar_highs[j] >= target_price:
                    exit_price = target_price
                    exit_idx = j
                    trigger_reason = "target"
                    break
                # T+5 FALLBACK
                if bar_days[j] >= HOLDING_DAYS - 1:
                    if j == n_bars - 1 or bar_days[j+1] > HOLDING_DAYS - 1:
                        exit_price = bar_closes[j]
                        exit_idx = j
                        trigger_reason = "time"
                        break
            if exit_price is None:
                exit_price = bar_closes[-1]
                exit_idx = n_bars - 1
                trigger_reason = "time"
        
        elif exit_mode == "rolling_5d":
            entry_day_offset = int(bar_days[entry_idx])
            target_exit_day = entry_day_offset + 5
            
            for j in range(entry_idx + 1, n_bars):
                if bar_lows[j] <= stop_price:
                    exit_price = stop_price
                    exit_idx = j
                    trigger_reason = "stop"
                    break
                if bar_days[j] >= target_exit_day:
                    if j == n_bars - 1 or bar_days[j+1] > target_exit_day:
                        exit_price = bar_closes[j]
                        exit_idx = j
                        trigger_reason = "time"
                        break
            if exit_price is None:
                exit_price = bar_closes[-1]
                exit_idx = n_bars - 1
                trigger_reason = "time"
        else:
            continue
        
        # Compute return
        gross_ret = (exit_price / entry_price - 1) * 100
        
        # FIX 5: Outlier cap
        if gross_ret > MAX_PLAUSIBLE_RETURN_PCT or gross_ret < MIN_PLAUSIBLE_RETURN_PCT:
            continue
        
        net_ret = gross_ret - (COST_BPS_ROUND_TRIP / 100) - (2 * SLIPPAGE_BPS_PER_SIDE / 100)
        
        # FIX 2: days_held in trading days
        entry_day_idx = int(bar_days[entry_idx])
        exit_day_idx = int(bar_days[exit_idx])
        days_held = exit_day_idx - entry_day_idx
        entry_day_offset = entry_day_idx + 1  # T+1 = 1
        
        results.append({
            "symbol": sig["symbol"],
            "signal_date": sig["signal_date"],
            "entry_day": sig["entry_day"],
            "probability": sig["probability"],
            "regime": sig["regime"],
            "entry_time": bar_ts[entry_idx],
            "entry_price": round(entry_price, 4),
            "entry_day_offset": entry_day_offset,
            "exit_time": bar_ts[exit_idx],
            "exit_price": round(exit_price, 4),
            "stop_price": round(stop_price, 4),
            "stop_pct": round(stop_pct_from_entry, 2),
            "target_price": round(target_price, 4) if target_price else 0,
            "gross_ret_pct": round(gross_ret, 3),
            "net_ret_pct": round(net_ret, 3),
            "days_held": days_held,
            "trigger_reason": trigger_reason,
        })
    
    return pd.DataFrame(results)


# =============================================================================
# RUNNERS
# =============================================================================

def run_variant(paths_df: pd.DataFrame, variant_id: str, variant: Dict) -> Tuple[Dict, pd.DataFrame]:
    trades = simulate_variant(paths_df, variant)
    n_signals = len(paths_df)
    n_trades = len(trades)
    filter_rate = round(100 * (1 - n_trades / max(n_signals, 1)), 2)
    
    if n_trades < MIN_TRADES_FOR_VARIANT:
        return {
            "variant_id": variant_id,
            "family": variant["family"],
            "label": variant["label"],
            "n_signals": n_signals,
            "n_trades": n_trades,
            "filter_rate_pct": filter_rate,
            "INSUFFICIENT_DATA": True,
        }, trades
    
    net = trades["net_ret_pct"].values
    metrics = compute_metrics(net, label=variant["label"])
    
    stop_hits = (trades["trigger_reason"] == "stop").sum() if "trigger_reason" in trades else 0
    target_hits = (trades["trigger_reason"] == "target").sum() if "trigger_reason" in trades else 0
    time_exits = (trades["trigger_reason"] == "time").sum() if "trigger_reason" in trades else 0
    
    return {
        "variant_id": variant_id,
        "family": variant["family"],
        "label": variant["label"],
        "n_signals": n_signals,
        "n_trades": n_trades,
        "filter_rate_pct": filter_rate,
        "win_rate_pct": metrics["win_rate_pct"],
        "avg_ret_pct": metrics["avg_ret_pct"],
        "median_ret_pct": metrics["median_ret_pct"],
        "avg_win_pct": metrics["avg_win_pct"],
        "avg_loss_pct": metrics["avg_loss_pct"],
        "std_pct": metrics["std_pct"],
        "sharpe_annual": metrics["sharpe_annual"],
        "min_ret": metrics["min_ret"],
        "max_ret": metrics["max_ret"],
        "p10": metrics["p10"],
        "p90": metrics["p90"],
        "stop_hits": stop_hits,
        "target_hits": target_hits,
        "time_exits": time_exits,
        "avg_days_held": round(trades["days_held"].mean(), 2),
        "INSUFFICIENT_DATA": False,
    }, trades


def run_validation_check(paths_df: pd.DataFrame, top_variants: List[Tuple[str, Dict]]) -> pd.DataFrame:
    paths_df = paths_df.copy()
    paths_df["signal_date"] = pd.to_datetime(paths_df["signal_date"])
    paths_df = paths_df.sort_values("signal_date").reset_index(drop=True)
    
    cutoff_idx = int(len(paths_df) * (1 - VALIDATION_FRACTION))
    discovery_df = paths_df.iloc[:cutoff_idx]
    validation_df = paths_df.iloc[cutoff_idx:]
    
    print(f"\n  Discovery: {len(discovery_df)} signals  ({discovery_df['signal_date'].min().date()} to {discovery_df['signal_date'].max().date()})")
    print(f"  Validation: {len(validation_df)} signals  ({validation_df['signal_date'].min().date()} to {validation_df['signal_date'].max().date()})")
    
    rows = []
    for variant_id, variant in top_variants:
        disc_summary, _ = run_variant(discovery_df, variant_id, variant)
        val_summary, _ = run_variant(validation_df, variant_id, variant)
        
        if disc_summary.get("INSUFFICIENT_DATA") or val_summary.get("INSUFFICIENT_DATA"):
            continue
        
        retention = (val_summary["sharpe_annual"] / disc_summary["sharpe_annual"] * 100) \
            if disc_summary["sharpe_annual"] != 0 else 0
        
        rows.append({
            "variant_id": variant_id,
            "label": variant["label"],
            "discovery_n": disc_summary["n_trades"],
            "discovery_avg_ret": disc_summary["avg_ret_pct"],
            "discovery_sharpe": disc_summary["sharpe_annual"],
            "validation_n": val_summary["n_trades"],
            "validation_avg_ret": val_summary["avg_ret_pct"],
            "validation_sharpe": val_summary["sharpe_annual"],
            "sharpe_retention_pct": round(retention, 1),
            "passes_80pct": "YES" if retention >= 80 else "NO",
        })
    
    return pd.DataFrame(rows)


def run_recent_check(paths_df: pd.DataFrame, top_variants: List[Tuple[str, Dict]]) -> pd.DataFrame:
    paths_df = paths_df.copy()
    paths_df["signal_date"] = pd.to_datetime(paths_df["signal_date"])
    cutoff = paths_df["signal_date"].max() - pd.DateOffset(months=RECENT_MONTHS)
    recent = paths_df[paths_df["signal_date"] >= cutoff]
    
    if len(recent) < MIN_TRADES_FOR_VARIANT:
        return pd.DataFrame()
    
    rows = []
    for variant_id, variant in top_variants:
        summary, _ = run_variant(recent, variant_id, variant)
        if not summary.get("INSUFFICIENT_DATA"):
            rows.append(summary)
    
    return pd.DataFrame(rows)


# =============================================================================
# MAIN
# =============================================================================

def main():
    import argparse
    p = argparse.ArgumentParser(description="ORB Machine v2 - CORRECTED")
    p.add_argument("--rebuild", action="store_true", help="Force re-extract")
    p.add_argument("--skip-extract", action="store_true", help="Use existing extraction")
    p.add_argument("--variant", type=str, default=None, help="Run specific variant only")
    p.add_argument("--limit", type=int, default=None, help="Limit signals processed")
    args = p.parse_args()
    
    print("=" * 80)
    print("ORB MACHINE v2 - CORRECTED + 7 NEW SMART COMBO VARIANTS")
    print("=" * 80)
    print("\n6 BUGS FIXED FROM v1:")
    print("  1. Signal/cache date alignment (no more 1230-day gaps)")
    print("  2. Trading-day offsets (not calendar)")
    print("  3. bar_days uses trading-day indices")
    print("  4. Market-hour filtering (9:15-15:30 IST)")
    print("  5. Outlier returns capped at +/-50%")
    print("  6. Dynamic mode bar-in-day index corrected")
    print("  PLUS: Stop checked BEFORE target at every bar")
    print("\nNEW VARIANTS F1-F7 (combine best v1 findings):")
    for vid, v in VARIANT_PRESETS.items():
        if vid.startswith("F"):
            print(f"  {vid}: {v['label']}")
    print()
    
    # Load or extract
    if EXTRACTED_PATHS_FILE.exists() and not args.rebuild:
        print(f"Loading existing extracted paths: {EXTRACTED_PATHS_FILE}")
        paths_df = pd.read_parquet(EXTRACTED_PATHS_FILE)
        print(f"  Loaded {len(paths_df):,} signal paths")
    else:
        print("Extracting (30-90 min depending on signal count)...")
        signals = generate_signals()
        if args.limit:
            signals = signals.head(args.limit)
            print(f"  Limited to {len(signals)} signals")
        paths_df = run_extraction(signals)
    
    if len(paths_df) == 0:
        raise SystemExit("FATAL: No paths extracted")
    
    # Variants
    if args.variant:
        if args.variant not in VARIANT_PRESETS:
            print(f"FATAL: Variant {args.variant} not found.")
            sys.exit(1)
        variants_to_run = [(args.variant, VARIANT_PRESETS[args.variant])]
    else:
        variants_to_run = list(VARIANT_PRESETS.items())
        print(f"\nRunning ALL {len(variants_to_run)} preset variants")
    
    print("\n[3/3] Running variants...")
    print("=" * 80)
    
    all_summaries = []
    all_trades = {}
    
    for i, (vid, variant) in enumerate(variants_to_run):
        t0 = time.time()
        summary, trades = run_variant(paths_df, vid, variant)
        elapsed = time.time() - t0
        
        all_summaries.append(summary)
        all_trades[vid] = trades
        
        if summary.get("INSUFFICIENT_DATA"):
            print(f"  [{i+1}/{len(variants_to_run)}] {vid:<32} INSUFFICIENT ({summary['n_trades']} trades, {elapsed:.1f}s)")
        else:
            print(f"  [{i+1}/{len(variants_to_run)}] {vid:<32} "
                  f"n={summary['n_trades']:>5,}  filter={summary['filter_rate_pct']:>5.1f}%  "
                  f"avg={summary['avg_ret_pct']:>+6.3f}%  Sharpe={summary['sharpe_annual']:>5.2f}  "
                  f"days={summary['avg_days_held']:>4.1f}  ({elapsed:.1f}s)")
    
    summary_df = pd.DataFrame(all_summaries)
    summary_df = summary_df.sort_values("sharpe_annual", ascending=False, na_position="last").reset_index(drop=True)
    
    # Validation
    print("\n" + "=" * 80)
    print("VALIDATION ON HOLDOUT SET")
    print("=" * 80)
    valid = summary_df[~summary_df.get("INSUFFICIENT_DATA", False)]
    top_for_val = [(row["variant_id"], VARIANT_PRESETS.get(row["variant_id"], {})) 
                    for _, row in valid.head(15).iterrows()
                    if row["variant_id"] in VARIANT_PRESETS]
    val_df = run_validation_check(paths_df, top_for_val)
    
    # Recent
    print("\n" + "=" * 80)
    print(f"RECENT PERIOD CHECK (last {RECENT_MONTHS} months)")
    print("=" * 80)
    recent_df = run_recent_check(paths_df, top_for_val)
    
    # Save
    print("\nSaving outputs...")
    summary_df.to_csv(OUT_DIR / "variant_results.csv", index=False)
    if len(val_df) > 0:
        val_df.to_csv(OUT_DIR / "validation_results.csv", index=False)
    if len(recent_df) > 0:
        recent_df.to_csv(OUT_DIR / "recent_period_results.csv", index=False)
    
    # Top 8 trade-level
    for vid in summary_df.head(8)["variant_id"].tolist():
        if vid in all_trades and len(all_trades[vid]) > 0:
            trades_copy = all_trades[vid].copy()
            for c in trades_copy.columns:
                if pd.api.types.is_datetime64_any_dtype(trades_copy[c]):
                    try:
                        if trades_copy[c].dt.tz is not None:
                            trades_copy[c] = trades_copy[c].dt.tz_localize(None)
                    except Exception:
                        pass
            trades_copy.to_csv(OUT_DIR / f"variant_trades_{vid}.csv", index=False)
    
    # Excel
    excel_path = OUT_DIR / "orb_machine_v2.xlsx"
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        summary_df.to_excel(writer, sheet_name="All Variants Ranked", index=False)
        for family in summary_df["family"].dropna().unique():
            fam_df = summary_df[summary_df["family"] == family]
            sheet_name = family[:30]
            fam_df.to_excel(writer, sheet_name=sheet_name, index=False)
        if len(val_df) > 0:
            val_df.to_excel(writer, sheet_name="Validation Check", index=False)
        if len(recent_df) > 0:
            recent_df.to_excel(writer, sheet_name="Recent Period", index=False)
    
    print(f"  Excel: {excel_path}")
    
    # Console summary
    print("\n" + "=" * 110)
    print("TOP 15 VARIANTS (by Sharpe)")
    print("=" * 110)
    print(f"  {'#':<3} {'Variant':<32} {'Family':<25} {'N':>6} {'Filter%':>8} {'AvgRet%':>9} {'Win%':>7} {'Sharpe':>7} {'AvgDays':>8}")
    print("-" * 110)
    
    valid_summary = summary_df[~summary_df.get("INSUFFICIENT_DATA", False)]
    for i, (_, row) in enumerate(valid_summary.head(15).iterrows(), 1):
        fam = row.get("family", "")[:24] if pd.notna(row.get("family")) else ""
        print(f"  {i:<3} {row['variant_id']:<32} {fam:<25} {row['n_trades']:>6,} "
              f"{row['filter_rate_pct']:>7.1f}% {row['avg_ret_pct']:>+9.3f}% "
              f"{row['win_rate_pct']:>6.1f}% {row['sharpe_annual']:>7.2f} {row['avg_days_held']:>8.1f}")
    
    if len(val_df) > 0:
        print("\n" + "=" * 100)
        print("VALIDATION CHECK")
        print("=" * 100)
        print(f"  {'Variant':<32} {'Disc Sharpe':>12} {'Val Sharpe':>11} {'Retention':>10} {'Pass':>5}")
        for _, row in val_df.iterrows():
            print(f"  {row['variant_id']:<32} {row['discovery_sharpe']:>12.2f} "
                  f"{row['validation_sharpe']:>11.2f} {row['sharpe_retention_pct']:>9.1f}% "
                  f"{row['passes_80pct']:>5}")
        
        passers = val_df[val_df["passes_80pct"] == "YES"]
        if len(passers) > 0:
            best = passers.iloc[0]
            print(f"\n  >>> BEST ROBUST VARIANT: {best['variant_id']}")
            print(f"      Discovery Sharpe: {best['discovery_sharpe']:.2f}")
            print(f"      Validation Sharpe: {best['validation_sharpe']:.2f}")
        else:
            print(f"\n  >>> WARNING: No variant passed 80% retention.")
    
    if len(recent_df) > 0:
        print("\n" + "=" * 100)
        print(f"RECENT PERIOD ({RECENT_MONTHS} MONTHS) - Top 10 by Recent Sharpe")
        print("=" * 100)
        recent_sorted = recent_df.sort_values("sharpe_annual", ascending=False)
        print(f"  {'Variant':<32} {'Trades':>8} {'AvgRet%':>9} {'Sharpe':>8}")
        for _, row in recent_sorted.head(10).iterrows():
            print(f"  {row['variant_id']:<32} {row['n_trades']:>8,} "
                  f"{row['avg_ret_pct']:>+9.3f}% {row['sharpe_annual']:>8.2f}")
    
    print("\n" + "=" * 80)
    print(f"Output dir: {OUT_DIR}")
    print(f"Diagnostics: {DIAGNOSTICS_FILE}")
    print(f"Excel: {excel_path}")
    print("=" * 80)


if __name__ == "__main__":
    main()
