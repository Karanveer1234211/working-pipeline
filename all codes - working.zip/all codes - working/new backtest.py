#!/usr/bin/env python3
"""
=============================================================================
TRUE BACKTEST - bucket-wise + regime-wise analysis
=============================================================================

Methodology:
  - Generate predictions for every (date, stock) in panel via regime router
  - Forward return: buy at T+1 open, sell at T+6 close (5-day hold)
  - Uses ret_5d_oc_pct column already in panel (close[t+5] / open[t+1] - 1)
  - Out-of-sample = last 20% of dates (matching cpr_fix.py train/test split)

Reports produced (Excel workbook + individual CSVs):
  1. Headline numbers (overall + per-regime + OOS-only)
  2. Decile bucket analysis (predicted prob → realized returns)
  3. Per-regime bucket analysis
  4. Cost sensitivity sweep (0/10/25/50/75/100 bps round-trip)
  5. Calendar analysis (by year, by month-of-year, by quarter)
  6. Stability analysis (decile transitions, turnover)
  7. Calibration check (predicted prob vs actual win rate)
  8. Top-K equity curves (K = 10, 20, 50)
  9. Probability-weighted vs equal-weighted comparison
 10. Regime-conditional sizing (full size in trends, half in ranges)

CRITICAL CAVEATS:
  - Full-period results contain in-sample leakage. Use OOS section for honest read.
  - Survivorship: panel uses whatever data was available historically. If a stock
    delisted, returns become NaN and are treated as -100% (worst case).
  - Costs are RETAIL Indian market estimates. Adjust for your actual broker.
  - 5-day holding means positions overlap. Backtest assumes daily entry but you
    can't actually trade ~daily; in practice you'd trade weekly.
=============================================================================
"""

import json
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
from joblib import load

warnings.filterwarnings("ignore")

# =============================================================================
# CONFIG
# =============================================================================

BASE_DIR = Path(r"C:\Users\karanvsi\Desktop\Kite Connect\v3_2_output_full")
PANEL_PATH = BASE_DIR / "panel_cache.parquet"
FEATURES_PATH = BASE_DIR / "features_train.json"
MODELS_DIR = BASE_DIR / "models"
ROUTER_PATH = MODELS_DIR / "m5_regime_router.joblib"
FALLBACK_PATH = MODELS_DIR / "m5_ensemble.joblib"

OUT_DIR = BASE_DIR / "backtest_results"
OUT_DIR.mkdir(exist_ok=True)

IST = "Asia/Kolkata"

# Universe filters (match cpr_fix.py)
MIN_CLOSE = 2.0
MIN_AVG20_VOL = 200_000

# Backtest config
RET_COL = "ret_5d_oc_pct"  # T+1 open to T+6 close (matches your spec)
HOLD_DAYS = 5
N_BUCKETS = 10  # deciles

# OOS split: last 20% of dates (matches training)
OOS_FRACTION = 0.20

# Cost sensitivity sweep (basis points, round-trip)
COST_BPS_LIST = [0, 10, 25, 50, 75, 100]

# Top-K selection variants
TOP_K_LIST = [10, 20, 50]

# =============================================================================
# LOAD PANEL & MODELS
# =============================================================================

print("=" * 70)
print("TRUE BACKTEST: bucket-wise + regime-wise")
print("=" * 70)

print("\n[1/6] Loading panel and models...")
panel = pd.read_parquet(PANEL_PATH)
panel["timestamp"] = pd.to_datetime(panel["timestamp"])
if panel["timestamp"].dt.tz is None:
    panel["timestamp"] = panel["timestamp"].dt.tz_localize(IST)
else:
    panel["timestamp"] = panel["timestamp"].dt.tz_convert(IST)
panel = panel.sort_values(["symbol", "timestamp"]).reset_index(drop=True)
print(f"  Panel: {len(panel):,} rows")

# Sanity checks
required_cols = ["symbol", "timestamp", "close", "volume", RET_COL]
for c in required_cols:
    if c not in panel.columns:
        raise SystemExit(f"FATAL: panel missing required column '{c}'")

has_regime = "stock_regime" in panel.columns
print(f"  stock_regime present: {has_regime}")
if not has_regime:
    print("  WARN: no stock_regime column. Per-regime analysis will be skipped.")

# Universe filter
panel["avg20_vol"] = (
    panel.groupby("symbol")["volume"]
         .transform(lambda s: s.rolling(20, min_periods=1).mean())
)
universe_mask = (panel["close"] >= MIN_CLOSE) & (panel["avg20_vol"] >= MIN_AVG20_VOL)
panel = panel[universe_mask].reset_index(drop=True)
print(f"  Panel after universe filter: {len(panel):,} rows")

# Load schema and models
schema = json.loads(FEATURES_PATH.read_text())
FEATURES = schema["features"]
IMPUTE = {k: float(v) for k, v in schema["impute"].items()}
print(f"  Features: {len(FEATURES)}")

if ROUTER_PATH.exists():
    print(f"  Loading regime router")
    router = load(ROUTER_PATH)
    use_regime = True
elif FALLBACK_PATH.exists():
    print(f"  Loading fallback ensemble (no router)")
    router = load(FALLBACK_PATH)
    use_regime = False
else:
    raise SystemExit("FATAL: no model file found")


# =============================================================================
# GENERATE PREDICTIONS
# =============================================================================

print("\n[2/6] Generating predictions for full panel...")
import time
t0 = time.perf_counter()

X = panel.reindex(columns=FEATURES).copy()
for c in FEATURES:
    X[c] = pd.to_numeric(X[c], errors="coerce").fillna(IMPUTE.get(c, 0.0))

# Predict
if use_regime and has_regime:
    # RegimeRouter has predict_proba_by_regime(X, regime_vec)
    print("  Using regime router (per-row routing)")
    if hasattr(router, "predict_proba_by_regime"):
        regime_vec = panel["stock_regime"]
        probs = router.predict_proba_by_regime(X, regime_vec)
    else:
        # Manual routing as fallback
        print("  Falling back to manual regime routing")
        probs = np.full(len(X), np.nan)
        for r in ["bull_trend", "bull_range", "bear_trend", "bear_range"]:
            mask = (panel["stock_regime"].values == r)
            if mask.sum() == 0:
                continue
            model = router.regime_models.get(r) if hasattr(router, "regime_models") else None
            if model is None:
                model = router.fallback if hasattr(router, "fallback") else None
            if model is None:
                continue
            try:
                p = model.predict_proba(X.iloc[mask])[:, 1]
                probs[mask] = p
                print(f"    {r}: {mask.sum():,} rows scored, prob range [{p.min():.3f}, {p.max():.3f}]")
            except Exception as e2:
                print(f"    {r}: scoring failed ({e2})")
        if np.isnan(probs).any():
            nan_mask = np.isnan(probs)
            fallback = router.fallback if hasattr(router, "fallback") else None
            if fallback is not None:
                try:
                    probs[nan_mask] = fallback.predict_proba(X.iloc[nan_mask])[:, 1]
                    print(f"    Filled {nan_mask.sum():,} unrouted rows with fallback")
                except Exception:
                    probs[nan_mask] = 0.5
            else:
                probs[nan_mask] = 0.5
elif use_regime and not has_regime:
    # Router exists but panel missing stock_regime → use fallback only
    print("  Router loaded but panel has no stock_regime; using fallback ensemble")
    if hasattr(router, "fallback") and router.fallback is not None:
        probs = router.fallback.predict_proba(X)[:, 1]
    else:
        raise SystemExit("FATAL: no usable model. Run enrich_panel.py to add stock_regime.")
else:
    print("  Using single model")
    probs = router.predict_proba(X)[:, 1]

panel["prob"] = probs
print(f"  Done in {time.perf_counter()-t0:.1f}s")
print(f"  Probability range: [{probs.min():.4f}, {probs.max():.4f}]")
print(f"  Mean prob: {probs.mean():.4f}")

# =============================================================================
# PREPARE TRADES
# =============================================================================

print("\n[3/6] Preparing trade table...")

# Forward return - already in panel as ret_5d_oc_pct
panel["fwd_ret_pct"] = pd.to_numeric(panel[RET_COL], errors="coerce")

# Trade = row where we have a prediction AND a forward return
trades = panel[panel["fwd_ret_pct"].notna()].copy()
trades = trades.dropna(subset=["prob"])
print(f"  Valid trades: {len(trades):,} (rows with both prob and forward return)")

# Date split for OOS
trades = trades.sort_values("timestamp").reset_index(drop=True)
unique_dates = trades["timestamp"].dt.normalize().drop_duplicates().sort_values()
n_dates = len(unique_dates)
oos_start_idx = int(n_dates * (1 - OOS_FRACTION))
oos_start_date = unique_dates.iloc[oos_start_idx]
print(f"  Total date range: {unique_dates.min().date()} -> {unique_dates.max().date()}")
print(f"  OOS cutoff date: {oos_start_date.date()}  (last {OOS_FRACTION*100:.0f}% of dates)")

trades["is_oos"] = trades["timestamp"] >= oos_start_date
n_oos = trades["is_oos"].sum()
print(f"  OOS trades: {n_oos:,}  ({100*n_oos/len(trades):.1f}%)")

# Win label: positive forward return
trades["is_win"] = (trades["fwd_ret_pct"] > 0).astype(int)

# Assign bucket (decile 1 = highest probability, decile 10 = lowest)
# Bucket per date to be cross-sectionally fair
trades["bucket"] = (
    trades.groupby(trades["timestamp"].dt.normalize())["prob"]
          .transform(lambda s: pd.qcut(s.rank(method="first", ascending=False),
                                       q=N_BUCKETS, labels=False, duplicates="drop") + 1)
)
# bucket 1 = top decile, bucket 10 = bottom decile

# Per-day count for sanity
avg_per_day = trades.groupby(trades["timestamp"].dt.normalize()).size().mean()
print(f"  Avg trades per day: {avg_per_day:.0f}")

# =============================================================================
# REPORTS
# =============================================================================

def compute_stats(sub: pd.DataFrame, label: str = "") -> dict:
    """Compute trade stats for a subset."""
    if len(sub) == 0:
        return {"label": label, "n_trades": 0}
    rets = sub["fwd_ret_pct"].values
    wins = (rets > 0)
    losses = (rets <= 0)
    n_win = wins.sum()
    n_loss = losses.sum()
    win_rate = n_win / len(rets) if len(rets) > 0 else 0
    avg_ret = rets.mean()
    avg_win = rets[wins].mean() if n_win > 0 else 0
    avg_loss = rets[losses].mean() if n_loss > 0 else 0
    sharpe_per_trade = rets.mean() / (rets.std() + 1e-9)
    # Annualize: ~50 weekly cycles, but if trading daily 250 trades/yr per stock holding 5d
    # Use overlapping non-independent so use 50 effective periods/year as rough proxy
    sharpe_annual = sharpe_per_trade * np.sqrt(50)
    return {
        "label": label,
        "n_trades": len(sub),
        "win_rate_pct": round(100 * win_rate, 2),
        "avg_ret_pct": round(avg_ret, 3),
        "avg_win_pct": round(avg_win, 3),
        "avg_loss_pct": round(avg_loss, 3),
        "expectancy_pct": round(avg_ret, 3),  # net same as avg_ret without sizing
        "std_pct": round(rets.std(), 3),
        "sharpe_per_trade": round(sharpe_per_trade, 3),
        "sharpe_annualized": round(sharpe_annual, 2),
        "min_ret": round(rets.min(), 2),
        "max_ret": round(rets.max(), 2),
        "median_ret": round(np.median(rets), 3),
    }


def headline_block(trades_df: pd.DataFrame, suffix: str = ""):
    """Headline section."""
    rows = []
    rows.append(compute_stats(trades_df, f"ALL{suffix}"))
    # Top decile only
    top = trades_df[trades_df["bucket"] == 1]
    rows.append(compute_stats(top, f"TOP_DECILE{suffix}"))
    # Bottom decile only
    bot = trades_df[trades_df["bucket"] == N_BUCKETS]
    rows.append(compute_stats(bot, f"BOTTOM_DECILE{suffix}"))
    # Top quintile
    topq = trades_df[trades_df["bucket"] <= 2]
    rows.append(compute_stats(topq, f"TOP_QUINTILE{suffix}"))
    # Bottom quintile
    botq = trades_df[trades_df["bucket"] >= N_BUCKETS - 1]
    rows.append(compute_stats(botq, f"BOTTOM_QUINTILE{suffix}"))
    # Top-bottom spread
    rows.append({
        "label": f"TOP-BOTTOM SPREAD{suffix}",
        "spread_pct": round(top["fwd_ret_pct"].mean() - bot["fwd_ret_pct"].mean(), 3),
    })
    return rows


print("\n[4/6] Computing reports...")

# --- Report 1: Headline ---
print("  [4.1] Headline numbers")
headline_rows = []
headline_rows.extend(headline_block(trades, " (full period)"))
headline_rows.extend(headline_block(trades[trades["is_oos"]], " (OOS only)"))
headline_df = pd.DataFrame(headline_rows)

# --- Report 2: Bucket analysis (full period) ---
print("  [4.2] Bucket analysis - full period")
bucket_rows_full = []
for b in range(1, N_BUCKETS + 1):
    sub = trades[trades["bucket"] == b]
    stats = compute_stats(sub, f"Decile {b}")
    stats["bucket"] = b
    bucket_rows_full.append(stats)
bucket_full_df = pd.DataFrame(bucket_rows_full)

# --- Report 2b: Bucket analysis (OOS) ---
print("  [4.3] Bucket analysis - OOS only")
bucket_rows_oos = []
trades_oos = trades[trades["is_oos"]]
for b in range(1, N_BUCKETS + 1):
    sub = trades_oos[trades_oos["bucket"] == b]
    stats = compute_stats(sub, f"Decile {b} (OOS)")
    stats["bucket"] = b
    bucket_rows_oos.append(stats)
bucket_oos_df = pd.DataFrame(bucket_rows_oos)

# --- Report 3: Per-regime bucket analysis ---
print("  [4.4] Per-regime bucket analysis")
regime_bucket_rows = []
if has_regime:
    for r in ["bull_trend", "bull_range", "bear_trend", "bear_range"]:
        for b in range(1, N_BUCKETS + 1):
            sub = trades[(trades["stock_regime"] == r) & (trades["bucket"] == b)]
            stats = compute_stats(sub)
            stats["regime"] = r
            stats["bucket"] = b
            stats["label"] = f"{r} Decile {b}"
            regime_bucket_rows.append(stats)
regime_bucket_df = pd.DataFrame(regime_bucket_rows)

# --- Report 4: Cost sensitivity (top-decile only, full period and OOS) ---
print("  [4.5] Cost sensitivity sweep")
cost_rows = []
for bps in COST_BPS_LIST:
    cost_pct = bps / 100  # bps to %
    for scope, df in [("Full", trades), ("OOS", trades[trades["is_oos"]])]:
        top = df[df["bucket"] == 1].copy()
        if len(top) == 0:
            continue
        net_rets = top["fwd_ret_pct"] - cost_pct
        n_win = (net_rets > 0).sum()
        cost_rows.append({
            "scope": scope,
            "bps_round_trip": bps,
            "n_trades": len(top),
            "gross_avg_ret_pct": round(top["fwd_ret_pct"].mean(), 3),
            "net_avg_ret_pct": round(net_rets.mean(), 3),
            "net_win_rate_pct": round(100 * n_win / len(top), 2),
            "net_sharpe_annual": round(net_rets.mean() / (net_rets.std() + 1e-9) * np.sqrt(50), 2),
        })
cost_df = pd.DataFrame(cost_rows)

# --- Report 5: Calendar analysis ---
print("  [4.6] Calendar analysis")
trades["year"] = trades["timestamp"].dt.year
trades["month"] = trades["timestamp"].dt.month
trades["quarter"] = trades["timestamp"].dt.to_period("Q").astype(str)

calendar_rows = []
# By year (top decile only)
for yr in sorted(trades["year"].unique()):
    sub = trades[(trades["year"] == yr) & (trades["bucket"] == 1)]
    stats = compute_stats(sub, f"Year {yr}")
    stats["year"] = yr
    calendar_rows.append(stats)
calendar_year_df = pd.DataFrame(calendar_rows)

# By month-of-year (top decile)
month_rows = []
for m in range(1, 13):
    sub = trades[(trades["month"] == m) & (trades["bucket"] == 1)]
    stats = compute_stats(sub, f"Month {m:02d}")
    stats["month"] = m
    month_rows.append(stats)
month_df = pd.DataFrame(month_rows)

# By quarter
quarter_rows = []
for q in sorted(trades["quarter"].unique()):
    sub = trades[(trades["quarter"] == q) & (trades["bucket"] == 1)]
    stats = compute_stats(sub, f"Quarter {q}")
    stats["quarter"] = q
    quarter_rows.append(stats)
quarter_df = pd.DataFrame(quarter_rows)

# --- Report 6: Stability / decile transitions ---
print("  [4.7] Stability analysis (decile transitions)")
# For each (symbol, t), see what bucket it was in at t and at t-5
trades = trades.sort_values(["symbol", "timestamp"])
trades["bucket_prev_5d"] = trades.groupby("symbol")["bucket"].shift(1)  # rough proxy

# Transition matrix from previous bucket to current bucket (within top decile this round)
transitions = trades.dropna(subset=["bucket_prev_5d"])
trans_matrix = pd.crosstab(transitions["bucket_prev_5d"].astype(int),
                            transitions["bucket"], normalize="index") * 100
trans_matrix = trans_matrix.round(1)

# Turnover for top-K = % of new symbols vs previous day
print("  [4.8] Top-K turnover estimate")
turnover_rows = []
for K in TOP_K_LIST:
    top_k_per_date = (trades
                      .sort_values(["timestamp", "prob"], ascending=[True, False])
                      .groupby(trades["timestamp"].dt.normalize())
                      .head(K))
    dates_in_order = sorted(top_k_per_date["timestamp"].dt.normalize().unique())
    overlaps = []
    for i in range(1, min(len(dates_in_order), 200)):  # sample first 200 transitions
        d1 = dates_in_order[i - 1]
        d2 = dates_in_order[i]
        s1 = set(top_k_per_date[top_k_per_date["timestamp"].dt.normalize() == d1]["symbol"])
        s2 = set(top_k_per_date[top_k_per_date["timestamp"].dt.normalize() == d2]["symbol"])
        if s1:
            overlap = len(s1 & s2) / len(s1)
            overlaps.append(1 - overlap)  # turnover
    avg_turnover = np.mean(overlaps) if overlaps else np.nan
    turnover_rows.append({
        "K": K,
        "avg_daily_turnover_pct": round(100 * avg_turnover, 1) if pd.notna(avg_turnover) else np.nan,
        "sample_transitions": len(overlaps),
    })
turnover_df = pd.DataFrame(turnover_rows)

# --- Report 7: Calibration ---
print("  [4.9] Calibration check")
# Bin by probability, compare predicted prob to actual win rate
trades["prob_bin"] = pd.cut(trades["prob"], bins=np.arange(0, 1.05, 0.05))
calib_rows = []
for bin_label, sub in trades.groupby("prob_bin"):
    if len(sub) < 100:
        continue
    pred_avg = sub["prob"].mean()
    actual_win_rate = sub["is_win"].mean()
    avg_ret = sub["fwd_ret_pct"].mean()
    calib_rows.append({
        "prob_bin": str(bin_label),
        "n_trades": len(sub),
        "predicted_avg_prob": round(pred_avg, 4),
        "actual_win_rate": round(actual_win_rate, 4),
        "calib_gap": round(pred_avg - actual_win_rate, 4),
        "avg_realized_ret_pct": round(avg_ret, 3),
    })
calib_df = pd.DataFrame(calib_rows)

# --- Report 8: Top-K equity curves ---
print("  [4.10] Top-K equity curves")
# For each K, simulate buying top-K each day equally weighted, holding 5 days
equity_curves = {}
for K in TOP_K_LIST:
    top_k_per_date = (trades
                      .sort_values(["timestamp", "prob"], ascending=[True, False])
                      .groupby(trades["timestamp"].dt.normalize())
                      .head(K))
    # Average forward return per day
    daily_ret = (top_k_per_date
                 .groupby(top_k_per_date["timestamp"].dt.normalize())
                 .agg(n=("symbol", "count"), avg_ret_pct=("fwd_ret_pct", "mean"))
                 .reset_index())
    daily_ret.columns = ["date", "n_positions", f"avg_ret_pct_K{K}"]
    # Cumulative return assuming weekly (every 5 trading days) rebalance
    daily_ret[f"cum_ret_K{K}"] = ((1 + daily_ret[f"avg_ret_pct_K{K}"] / 100).cumprod() - 1) * 100
    equity_curves[K] = daily_ret

# Merge equity curves into one frame
ec_merged = equity_curves[TOP_K_LIST[0]][["date"]].copy()
for K in TOP_K_LIST:
    ec_merged = ec_merged.merge(equity_curves[K], on="date", how="outer")
ec_merged = ec_merged.drop_duplicates(subset=["date"]).sort_values("date").reset_index(drop=True)

# --- Report 9: Regime-conditional sizing ---
print("  [4.11] Regime-conditional sizing comparison")
if has_regime:
    # Strategy A: equal weight all top-decile
    a_top = trades[trades["bucket"] == 1].copy()
    a_top["weighted_ret"] = a_top["fwd_ret_pct"]

    # Strategy B: full size in trend regimes, half in range
    b_top = trades[trades["bucket"] == 1].copy()
    b_top["regime_weight"] = b_top["stock_regime"].map({
        "bull_trend": 1.0, "bear_trend": 1.0,
        "bull_range": 0.5, "bear_range": 0.5,
    }).fillna(0.5)
    b_top["weighted_ret"] = b_top["fwd_ret_pct"] * b_top["regime_weight"]

    # Strategy C: only trend regimes (skip ranges)
    c_top = trades[(trades["bucket"] == 1) &
                   (trades["stock_regime"].isin(["bull_trend", "bear_trend"]))].copy()
    c_top["weighted_ret"] = c_top["fwd_ret_pct"]

    sizing_rows = [
        {"strategy": "A: Equal-weight all top decile",
         "n_trades": len(a_top),
         "avg_ret_pct": round(a_top["weighted_ret"].mean(), 3),
         "sharpe_annual": round(a_top["weighted_ret"].mean() / (a_top["weighted_ret"].std()+1e-9) * np.sqrt(50), 2),
         "std_pct": round(a_top["weighted_ret"].std(), 3),
        },
        {"strategy": "B: Full-size trends, half-size ranges",
         "n_trades": len(b_top),
         "avg_ret_pct": round(b_top["weighted_ret"].mean(), 3),
         "sharpe_annual": round(b_top["weighted_ret"].mean() / (b_top["weighted_ret"].std()+1e-9) * np.sqrt(50), 2),
         "std_pct": round(b_top["weighted_ret"].std(), 3),
        },
        {"strategy": "C: Trend regimes only (skip ranges)",
         "n_trades": len(c_top),
         "avg_ret_pct": round(c_top["weighted_ret"].mean(), 3),
         "sharpe_annual": round(c_top["weighted_ret"].mean() / (c_top["weighted_ret"].std()+1e-9) * np.sqrt(50), 2),
         "std_pct": round(c_top["weighted_ret"].std(), 3),
        },
    ]
    sizing_df = pd.DataFrame(sizing_rows)
else:
    sizing_df = pd.DataFrame()

# --- Drawdown of K=20 strategy ---
print("  [4.12] Drawdown computation")
if 20 in equity_curves:
    ec20 = equity_curves[20].copy()
    ec20["cum_value"] = 1 + ec20[f"cum_ret_K20"] / 100
    ec20["running_max"] = ec20["cum_value"].cummax()
    ec20["drawdown_pct"] = (ec20["cum_value"] / ec20["running_max"] - 1) * 100
    max_dd = ec20["drawdown_pct"].min()
    max_dd_date = ec20.loc[ec20["drawdown_pct"].idxmin(), "date"]
    print(f"    Max drawdown (K=20): {max_dd:.2f}% on {pd.to_datetime(max_dd_date).date()}")
else:
    ec20 = pd.DataFrame()

# =============================================================================
# SAVE EVERYTHING
# =============================================================================

print("\n[5/6] Saving outputs...")

# Individual CSVs
csv_paths = {
    "headline.csv": headline_df,
    "bucket_full_period.csv": bucket_full_df,
    "bucket_oos.csv": bucket_oos_df,
    "regime_bucket.csv": regime_bucket_df,
    "cost_sensitivity.csv": cost_df,
    "calendar_year.csv": calendar_year_df,
    "calendar_month.csv": month_df,
    "calendar_quarter.csv": quarter_df,
    "decile_transitions.csv": trans_matrix.reset_index(),
    "turnover.csv": turnover_df,
    "calibration.csv": calib_df,
    "equity_curve.csv": ec_merged,
    "regime_sizing.csv": sizing_df,
}
for fname, df in csv_paths.items():
    if len(df) > 0:
        df.to_csv(OUT_DIR / fname, index=False)
print(f"  Saved {len(csv_paths)} CSVs to {OUT_DIR}")

# Strip timezone from any datetime columns before Excel save (openpyxl can't handle tz)
def _strip_tz(df):
    if df is None or len(df) == 0:
        return df
    out = df.copy()
    for c in out.columns:
        try:
            if pd.api.types.is_datetime64_any_dtype(out[c]):
                if hasattr(out[c].dt, "tz") and out[c].dt.tz is not None:
                    out[c] = out[c].dt.tz_localize(None)
        except Exception:
            pass
    return out

headline_df = _strip_tz(headline_df)
bucket_full_df = _strip_tz(bucket_full_df)
bucket_oos_df = _strip_tz(bucket_oos_df)
regime_bucket_df = _strip_tz(regime_bucket_df)
cost_df = _strip_tz(cost_df)
calendar_year_df = _strip_tz(calendar_year_df)
month_df = _strip_tz(month_df)
quarter_df = _strip_tz(quarter_df)
turnover_df = _strip_tz(turnover_df)
calib_df = _strip_tz(calib_df)
ec_merged = _strip_tz(ec_merged)
sizing_df = _strip_tz(sizing_df)

# Single Excel workbook
excel_path = OUT_DIR / "backtest_full.xlsx"
with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
    headline_df.to_excel(writer, sheet_name="01 Headline", index=False)
    bucket_full_df.to_excel(writer, sheet_name="02 Bucket Full", index=False)
    bucket_oos_df.to_excel(writer, sheet_name="03 Bucket OOS", index=False)
    if len(regime_bucket_df) > 0:
        regime_bucket_df.to_excel(writer, sheet_name="04 Regime x Bucket", index=False)
    cost_df.to_excel(writer, sheet_name="05 Cost Sensitivity", index=False)
    calendar_year_df.to_excel(writer, sheet_name="06 By Year", index=False)
    month_df.to_excel(writer, sheet_name="07 By Month", index=False)
    quarter_df.to_excel(writer, sheet_name="08 By Quarter", index=False)
    trans_matrix.to_excel(writer, sheet_name="09 Decile Transitions")
    turnover_df.to_excel(writer, sheet_name="10 Turnover", index=False)
    calib_df.to_excel(writer, sheet_name="11 Calibration", index=False)
    ec_merged.to_excel(writer, sheet_name="12 Equity Curve", index=False)
    if len(sizing_df) > 0:
        sizing_df.to_excel(writer, sheet_name="13 Regime Sizing", index=False)
print(f"  Saved Excel: {excel_path}")

# =============================================================================
# CONSOLE SUMMARY
# =============================================================================

print("\n[6/6] Summary")
print("=" * 70)

print("\n--- HEADLINE (full period) ---")
hl_full = headline_df[headline_df["label"].str.contains("full period", na=False)]
for _, row in hl_full.iterrows():
    if pd.notna(row.get("n_trades")):
        print(f"  {row['label']:40s} n={row.get('n_trades', 0):,}  "
              f"win={row.get('win_rate_pct', 0):.1f}%  "
              f"avg={row.get('avg_ret_pct', 0):+.3f}%  "
              f"sharpe={row.get('sharpe_annualized', 0):.2f}")
    elif "spread" in str(row.get("label", "")).lower():
        print(f"  {row['label']:40s} spread={row.get('spread_pct', 0):+.3f}%")

print("\n--- HEADLINE (OOS only) ---")
hl_oos = headline_df[headline_df["label"].str.contains("OOS", na=False)]
for _, row in hl_oos.iterrows():
    if pd.notna(row.get("n_trades")):
        print(f"  {row['label']:40s} n={row.get('n_trades', 0):,}  "
              f"win={row.get('win_rate_pct', 0):.1f}%  "
              f"avg={row.get('avg_ret_pct', 0):+.3f}%  "
              f"sharpe={row.get('sharpe_annualized', 0):.2f}")
    elif "spread" in str(row.get("label", "")).lower():
        print(f"  {row['label']:40s} spread={row.get('spread_pct', 0):+.3f}%")

print("\n--- BUCKET MONOTONICITY (full period) ---")
print(f"  {'Decile':<8} {'N trades':>10} {'Win%':>7} {'AvgRet%':>10} {'Sharpe':>8}")
for _, row in bucket_full_df.iterrows():
    print(f"  {row['bucket']:<8} {row['n_trades']:>10,} "
          f"{row['win_rate_pct']:>7.1f} {row['avg_ret_pct']:>+10.3f} {row['sharpe_annualized']:>8.2f}")

print("\n--- COST SENSITIVITY (top decile) ---")
print(f"  {'Scope':<6} {'BPS':>5} {'Gross%':>9} {'Net%':>9} {'Win%':>7} {'Sharpe':>8}")
for _, row in cost_df.iterrows():
    print(f"  {row['scope']:<6} {row['bps_round_trip']:>5} "
          f"{row['gross_avg_ret_pct']:>+9.3f} {row['net_avg_ret_pct']:>+9.3f} "
          f"{row['net_win_rate_pct']:>7.1f} {row['net_sharpe_annual']:>8.2f}")

if has_regime:
    print("\n--- REGIME x TOP DECILE ---")
    print(f"  {'Regime':<15} {'N':>8} {'Win%':>7} {'AvgRet%':>10} {'Sharpe':>8}")
    for r in ["bull_trend", "bull_range", "bear_trend", "bear_range"]:
        sub = regime_bucket_df[(regime_bucket_df["regime"] == r) & (regime_bucket_df["bucket"] == 1)]
        if len(sub) > 0:
            row = sub.iloc[0]
            print(f"  {r:<15} {row['n_trades']:>8,} "
                  f"{row['win_rate_pct']:>7.1f} {row['avg_ret_pct']:>+10.3f} "
                  f"{row['sharpe_annualized']:>8.2f}")

    print("\n--- REGIME SIZING COMPARISON (top decile) ---")
    for _, row in sizing_df.iterrows():
        print(f"  {row['strategy']:<45} n={row['n_trades']:,}  "
              f"avg={row['avg_ret_pct']:+.3f}%  sharpe={row['sharpe_annual']:.2f}")

if 20 in equity_curves:
    print(f"\n--- DRAWDOWN (K=20) ---")
    if len(ec20) > 0:
        final_ret = ec20[f"cum_ret_K20"].iloc[-1]
        print(f"  Final cumulative return: {final_ret:+.2f}%")
        print(f"  Max drawdown:            {max_dd:.2f}%")
        print(f"  Max DD date:             {pd.to_datetime(max_dd_date).date()}")

print("\n--- TURNOVER ---")
for _, row in turnover_df.iterrows():
    print(f"  K={row['K']}: avg daily turnover = {row['avg_daily_turnover_pct']:.1f}%")

print("\n--- CALIBRATION (top probability bins) ---")
print(f"  {'Bin':<20} {'N':>8} {'Predicted':>12} {'Actual Win':>12} {'Gap':>8}")
for _, row in calib_df.tail(5).iterrows():
    print(f"  {row['prob_bin']:<20} {row['n_trades']:>8,} "
          f"{row['predicted_avg_prob']:>12.4f} {row['actual_win_rate']:>12.4f} "
          f"{row['calib_gap']:>+8.4f}")

print("\n" + "=" * 70)
print(f"All outputs: {OUT_DIR}")
print(f"Main report: {excel_path}")
print("=" * 70)
print("\nInterpretation guide:")
print("  - Bucket monotonicity: top decile should consistently beat bottom decile")
print("  - OOS section is the honest read; full period has training leakage")
print("  - Cost sensitivity tells you the cost ceiling for profitability")
print("  - Calibration gap near 0 = trustworthy probabilities for sizing")
print("  - High turnover (>70%) means costs matter more")
print("=" * 70)