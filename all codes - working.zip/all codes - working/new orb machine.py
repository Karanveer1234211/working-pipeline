#!/usr/bin/env python3
"""
=============================================================================
ORB WORKSHOP - Unified ORB Backtester + Portfolio Simulator
=============================================================================

A single tool that combines:
  1. ORB Machine v4 (bug-fixed) - 37 variants across 8 families
  2. Custom universe support - upload your own symbol+date list
  3. Portfolio simulator with realistic Indian costs
  4. MAE/MFE tracking per trade
  5. Equity curve + drawdown analysis
  6. Interactive prompts at runtime

USAGE:
  python orb_workshop.py                  # interactive mode (recommended)
  python orb_workshop.py --batch          # batch mode with defaults
  python orb_workshop.py --rebuild        # force re-extract from 5-min bars

WORKFLOW:
  1. Choose universe (default model signals OR custom upload)
  2. Choose variant (single OR family OR all 30)
  3. Optional: enable portfolio simulator
  4. If yes: set capital, position size, concurrent limit, conflict rule
  5. Run + see results
  6. Outputs go to orb_workshop_results/

CUSTOM UNIVERSE FILE FORMAT:
  CSV with columns: symbol, signal_date
  Optional: probability, regime
  Example:
    symbol,signal_date,probability,regime
    RELIANCE,2024-03-15,0.82,bull_trend
    TCS,2024-03-22,0.78,bull_trend
=============================================================================
"""

import os
import sys
import json
import time
import warnings
import re
from pathlib import Path
from datetime import datetime, timedelta, time as dtime
from typing import Optional, List, Dict, Any, Tuple

import numpy as np
import pandas as pd
from joblib import load

warnings.filterwarnings("ignore")

# =============================================================================
# CONFIG - PATHS
# =============================================================================

BASE_DIR = Path(r"C:\Users\karanvsi\Desktop\Kite Connect\v3_2_output_full")
PANEL_PATH = BASE_DIR / "panel_cache.parquet"
FEATURES_PATH = BASE_DIR / "features_train.json"
ROUTER_PATH = BASE_DIR / "models" / "m5_regime_router.joblib"

INTRADAY_DIR = Path(r"C:\Users\karanvsi\Desktop\Pycharm\Cache\intraday_5min")

OUT_DIR = BASE_DIR / "orb_workshop_results"
OUT_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_PATHS_FILE = OUT_DIR / "default_paths.parquet"
CUSTOM_PATHS_FILE = OUT_DIR / "custom_paths.parquet"
DIAGNOSTICS_FILE = OUT_DIR / "extraction_diagnostics.csv"

IST = "Asia/Kolkata"

used_names = set()

def get_safe_sheet_name(name):
    name = re.sub(r'[:\\/*?\[\]]', '', str(name))[:31]

    base = name
    i = 1

    while name in used_names:
        suffix = f"_{i}"
        name = base[:31 - len(suffix)] + suffix
        i += 1

    used_names.add(name)
    return name


# =============================================================================
# CONFIG - STRATEGY
# =============================================================================

SIGNAL_PROB_MIN = 0.75
SIGNAL_REGIMES = ["bull_trend", "bear_trend"]
HOLDING_DAYS = 5
EXTENDED_DAYS = 10

# Validation
VALIDATION_FRACTION = 0.30
RECENT_MONTHS = 18
MIN_TRADES_FOR_VARIANT = 30
SHARPE_PERIODS_PER_YEAR = 50

# Bug-fix configs
MAX_SIGNAL_TO_CACHE_GAP_DAYS = 3
IST_MARKET_OPEN_HOUR = 9
IST_MARKET_OPEN_MIN = 15
IST_MARKET_CLOSE_HOUR = 15
IST_MARKET_CLOSE_MIN = 30
MAX_PLAUSIBLE_RETURN_PCT = 50.0
MIN_PLAUSIBLE_RETURN_PCT = -50.0
MIN_BARS_PER_DAY = 50

# =============================================================================
# CONFIG - PORTFOLIO SIMULATOR
# =============================================================================

# Default portfolio params (overridable via prompts)
DEFAULT_CAPITAL_PER_TRADE = 300_000
DEFAULT_STARTING_CAPITAL = 6_000_000  # 60L
DEFAULT_MAX_CONCURRENT = 20


# Indian cost modeling (Zerodha delivery equity, 2026 rates)
# Returns dict of cost components in percent (multiply by trade value)
def compute_indian_costs(trade_value: float, is_intraday: bool, side: str) -> Dict[str, float]:
    """
    Returns cost breakdown as absolute INR amounts.
    side: 'buy' or 'sell'
    is_intraday: True if same-day square-off
    """
    # Brokerage: 0.03% or Rs 20, whichever lower
    brokerage = min(trade_value * 0.0003, 20.0)

    # STT
    if is_intraday:
        # 0.025% on sell side only (intraday)
        stt = trade_value * 0.00025 if side == "sell" else 0.0
    else:
        # 0.1% on both buy and sell (delivery)
        stt = trade_value * 0.001

    # Exchange transaction charges (NSE)
    exchange = trade_value * 0.0000345

    # SEBI charges
    sebi = trade_value * 0.000001

    # Stamp duty (buy only)
    stamp = trade_value * 0.00015 if side == "buy" else 0.0

    # GST: 18% on (brokerage + exchange + SEBI)
    gst = (brokerage + exchange + sebi) * 0.18

    total = brokerage + stt + exchange + sebi + stamp + gst
    return {
        "brokerage": brokerage,
        "stt": stt,
        "exchange": exchange,
        "sebi": sebi,
        "stamp": stamp,
        "gst": gst,
        "total": total,
    }


# Slippage assumption (in addition to costs above)
SLIPPAGE_BPS_PER_SIDE = 5  # 5 bps each way = 10 bps round trip

# =============================================================================
# RANGE DEFINITIONS
# =============================================================================

RANGE_DEFINITIONS = {
    "5min": {"label": "5-min (9:15-9:20)", "end_time": "09:20", "bars_needed": 1},
    "15min": {"label": "15-min (9:15-9:30)", "end_time": "09:30", "bars_needed": 3},
    "30min": {"label": "30-min (9:15-9:45)", "end_time": "09:45", "bars_needed": 6},
    "60min": {"label": "60-min (9:15-10:15)", "end_time": "10:15", "bars_needed": 12},
}

# =============================================================================
# VARIANT PRESETS - 30 variants
# =============================================================================

VARIANT_PRESETS = {
    # FAMILY A: Range Definition
    "A1_range_5min": {"family": "A: Range Definition", "label": "5-min range",
                      "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                      "stop_mode": "range_low", "exit_mode": "t5_close"},
    "A2_range_15min": {"family": "A: Range Definition", "label": "15-min range",
                       "range_def": "15min", "watch_mode": "t1_only", "confirm": "close_above",
                       "stop_mode": "range_low", "exit_mode": "t5_close"},
    "A3_range_30min": {"family": "A: Range Definition", "label": "30-min range",
                       "range_def": "30min", "watch_mode": "t1_only", "confirm": "close_above",
                       "stop_mode": "range_low", "exit_mode": "t5_close"},
    "A4_range_60min": {"family": "A: Range Definition", "label": "60-min range",
                       "range_def": "60min", "watch_mode": "t1_only", "confirm": "close_above",
                       "stop_mode": "range_low", "exit_mode": "t5_close"},

    # FAMILY B: Watch Period
    "B1_watch_t1_only": {"family": "B: Watch Period", "label": "T+1 only (intraday)",
                         "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                         "stop_mode": "range_low", "exit_mode": "t5_close"},
    "B2_watch_t1_t2": {"family": "B: Watch Period", "label": "T+1 to T+2",
                       "range_def": "5min", "watch_mode": "window_2d", "confirm": "close_above",
                       "stop_mode": "range_low", "exit_mode": "t5_close"},
    "B3_watch_t1_t5_static": {"family": "B: Watch Period", "label": "T+1 to T+5 (static T+1 range)",
                              "range_def": "5min", "watch_mode": "static_t1_5d", "confirm": "close_above",
                              "stop_mode": "range_low", "exit_mode": "t5_close"},
    "B4_watch_t1_t5_dynamic": {"family": "B: Watch Period", "label": "T+1 to T+5 (each day own range)",
                               "range_def": "5min", "watch_mode": "dynamic_each_day", "confirm": "close_above",
                               "stop_mode": "range_low", "exit_mode": "t5_close"},

    # FAMILY C: Breakout Confirmation
    "C1_confirm_touch": {"family": "C: Breakout Confirmation", "label": "Touch above range high",
                         "range_def": "5min", "watch_mode": "t1_only", "confirm": "touch_above",
                         "stop_mode": "range_low", "exit_mode": "t5_close"},
    "C2_confirm_close": {"family": "C: Breakout Confirmation", "label": "Close above (standard)",
                         "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                         "stop_mode": "range_low", "exit_mode": "t5_close"},
    "C3_confirm_2x_close": {"family": "C: Breakout Confirmation", "label": "2 consecutive closes above",
                            "range_def": "5min", "watch_mode": "t1_only", "confirm": "two_consecutive",
                            "stop_mode": "range_low", "exit_mode": "t5_close"},
    "C4_confirm_no_reversal": {"family": "C: Breakout Confirmation", "label": "Close above + no 30min reversal",
                               "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_no_reversal",
                               "stop_mode": "range_low", "exit_mode": "t5_close"},

    # FAMILY D: Stop Placement
    "D1_stop_range_low": {"family": "D: Stop Placement", "label": "Stop at range low",
                          "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                          "stop_mode": "range_low", "exit_mode": "t5_close"},
    "D2_stop_3pct": {"family": "D: Stop Placement", "label": "Stop -3% from entry",
                     "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                     "stop_mode": "fixed_3pct", "exit_mode": "t5_close"},
    "D3_stop_5pct": {"family": "D: Stop Placement", "label": "Stop -5% from entry",
                     "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                     "stop_mode": "fixed_5pct", "exit_mode": "t5_close"},
    "D4_stop_7pct": {"family": "D: Stop Placement", "label": "Stop -7% from entry",
                     "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                     "stop_mode": "fixed_7pct", "exit_mode": "t5_close"},
    "D5_stop_2x_range": {"family": "D: Stop Placement", "label": "Stop = 2x range size below entry",
                         "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                         "stop_mode": "two_range_size", "exit_mode": "t5_close"},

    # FAMILY E: Exit Strategy
    "E1_exit_t5_close": {"family": "E: Exit Strategy", "label": "Hold to T+5 close",
                         "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                         "stop_mode": "range_low", "exit_mode": "t5_close"},
    "E2_exit_target_3pct": {"family": "E: Exit Strategy", "label": "Exit at +3% target or T+5",
                            "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                            "stop_mode": "range_low", "exit_mode": "target_3pct"},
    "E3_exit_target_5pct": {"family": "E: Exit Strategy", "label": "Exit at +5% target or T+5",
                            "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                            "stop_mode": "range_low", "exit_mode": "target_5pct"},
    "E4_exit_target_7pct": {"family": "E: Exit Strategy", "label": "Exit at +7% target or T+5",
                            "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                            "stop_mode": "range_low", "exit_mode": "target_7pct"},
    "E5_exit_target_2r": {"family": "E: Exit Strategy", "label": "Exit at 2R target or T+5",
                          "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                          "stop_mode": "range_low", "exit_mode": "target_2r"},
    "E6_exit_rolling_5d": {"family": "E: Exit Strategy", "label": "Rolling 5-day exit from entry",
                           "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                           "stop_mode": "range_low", "exit_mode": "rolling_5d"},

    # FAMILY F: SMART COMBINATIONS
    "F1_t1_noreversal_5pct": {"family": "F: Smart Combos",
                              "label": "T+1 + no-reversal + 5% target",
                              "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_no_reversal",
                              "stop_mode": "range_low", "exit_mode": "target_5pct"},
    "F2_t1_2r_target": {"family": "F: Smart Combos",
                        "label": "T+1 + range_low stop + 2R target",
                        "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_above",
                        "stop_mode": "range_low", "exit_mode": "target_2r"},
    "F3_t1_15min_noreversal_5pct": {"family": "F: Smart Combos",
                                    "label": "T+1 + 15-min range + no-reversal + 5%",
                                    "range_def": "15min", "watch_mode": "t1_only", "confirm": "close_no_reversal",
                                    "stop_mode": "range_low", "exit_mode": "target_5pct"},
    "F4_t1t2_noreversal_rangelow": {"family": "F: Smart Combos",
                                    "label": "T+1-T+2 + no-reversal + range_low",
                                    "range_def": "5min", "watch_mode": "window_2d", "confirm": "close_no_reversal",
                                    "stop_mode": "range_low", "exit_mode": "t5_close"},
    "F5_t1_first30min_5pct": {"family": "F: Smart Combos",
                              "label": "T+1 first-30-min + 5% target",
                              "range_def": "5min", "watch_mode": "t1_first_30min", "confirm": "close_above",
                              "stop_mode": "range_low", "exit_mode": "target_5pct"},
    "F6_t1_noreversal_3pct": {"family": "F: Smart Combos",
                              "label": "T+1 + no-reversal + 3% target",
                              "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_no_reversal",
                              "stop_mode": "range_low", "exit_mode": "target_3pct"},
    "F7_t1_heldEOD_5pct": {"family": "F: Smart Combos",
                           "label": "T+1 + held-EOD + 5% target (LOOKAHEAD - reference only)",
                           "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_held_eod",
                           "stop_mode": "range_low", "exit_mode": "target_5pct"},

    # FAMILY G: Refinements (based on findings + bug fixes)
    # G1: F3 + volume confirmation (tradeable, well-rounded)
    "G1_F3_volume_confirmed": {"family": "G: Refinements",
                               "label": "F3 + volume>=1.5x avg (volume-confirmed breakout)",
                               "range_def": "15min", "watch_mode": "t1_only", "confirm": "close_no_reversal_volume",
                               "stop_mode": "range_low", "exit_mode": "target_5pct"},

    # G2: HONEST F7 - enter at 3:25 PM if close > range high (no lookahead)
    "G2_eod_entry_honest": {"family": "G: Refinements",
                            "label": "EOD entry at 3:25 PM if close > range high (HONEST F7)",
                            "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_eod_entry",
                            "stop_mode": "range_low", "exit_mode": "t5_close"},

    # G3: Pullback entry (wait for retest of range high)
    "G3_pullback_entry": {"family": "G: Refinements",
                          "label": "Pullback entry (breakout then retest range high)",
                          "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_pullback",
                          "stop_mode": "range_low", "exit_mode": "target_5pct"},

    # G4: High-conviction only (prob >= 0.85) + F3 rules
    "G4_F3_high_conviction": {"family": "G: Refinements",
                              "label": "F3 rules but only prob >= 0.85",
                              "range_def": "15min", "watch_mode": "t1_only", "confirm": "close_no_reversal",
                              "stop_mode": "range_low", "exit_mode": "target_5pct",
                              "min_probability": 0.85},

    # G5: Bear-trend only + F3 rules
    "G5_F3_bear_only": {"family": "G: Refinements",
                        "label": "F3 rules but only bear_trend regime",
                        "range_def": "15min", "watch_mode": "t1_only", "confirm": "close_no_reversal",
                        "stop_mode": "range_low", "exit_mode": "target_5pct",
                        "regime_filter": "bear_trend"},

    # =========================================================================
    # FAMILY H: USER-REQUESTED VARIANTS (test 15-min check + multi-day watch)
    # =========================================================================
    # H1: 15-min reversal check (faster filter, more trades, lower win rate expected)
    "H1_t1_15min_reversal_5pct": {"family": "H: User Variants",
                                  "label": "T+1 + 15-min reversal check + 5% target",
                                  "range_def": "5min", "watch_mode": "t1_only", "confirm": "close_no_reversal_15min",
                                  "stop_mode": "range_low", "exit_mode": "target_5pct"},

    # H2: Watch T+1's range across all 5 days + no-reversal filter
    # If T+1 breakout doesn't happen, keep watching T+1's range on T+2, T+3, T+4, T+5
    "H2_5day_watch_noreversal": {"family": "H: User Variants",
                                 "label": "5-day watch on T+1 range + no-reversal + 5% target",
                                 "range_def": "5min", "watch_mode": "static_t1_5d", "confirm": "close_no_reversal",
                                 "stop_mode": "range_low", "exit_mode": "target_5pct"},
}


# =============================================================================
# HELPERS
# =============================================================================

def time_to_ts(date: pd.Timestamp, time_str: str) -> pd.Timestamp:
    h, m = map(int, time_str.split(":"))
    return date.replace(hour=h, minute=m, second=0, microsecond=0)


def compute_metrics(returns: np.ndarray, label: str = "") -> Dict[str, Any]:
    if len(returns) == 0:
        return {"label": label, "n": 0}
    wins = returns > 0
    losses = ~wins
    return {
        "label": label,
        "n": len(returns),
        "win_rate_pct": round(100 * wins.mean(), 2),
        "avg_ret_pct": round(returns.mean(), 3),
        "median_ret_pct": round(np.median(returns), 3),
        "avg_win_pct": round(returns[wins].mean() if wins.any() else 0, 3),
        "avg_loss_pct": round(returns[losses].mean() if losses.any() else 0, 3),
        "std_pct": round(returns.std(), 3),
        "sharpe_per_trade": round(returns.mean() / (returns.std() + 1e-9), 3),
        "sharpe_annual": round(returns.mean() / (returns.std() + 1e-9) * np.sqrt(SHARPE_PERIODS_PER_YEAR), 2),
        "min_ret": round(returns.min(), 2),
        "max_ret": round(returns.max(), 2),
        "p10": round(np.percentile(returns, 10), 2),
        "p90": round(np.percentile(returns, 90), 2),
    }


def filter_market_hours(bars: pd.DataFrame) -> pd.DataFrame:
    if len(bars) == 0:
        return bars
    ts = bars["timestamp"]
    if ts.dt.tz is not None:
        ts_ist = ts.dt.tz_convert(IST)
    else:
        ts_ist = ts
    time_float = ts_ist.dt.hour + ts_ist.dt.minute / 60.0
    mo = IST_MARKET_OPEN_HOUR + IST_MARKET_OPEN_MIN / 60.0
    mc = IST_MARKET_CLOSE_HOUR + IST_MARKET_CLOSE_MIN / 60.0
    mask = (time_float >= mo) & (time_float <= mc)
    return bars[mask].reset_index(drop=True)


def daily_bars(bars: pd.DataFrame, date: pd.Timestamp) -> pd.DataFrame:
    return bars[bars["timestamp"].dt.normalize() == date.normalize()]


def load_bars(symbol: str, start_date, end_date) -> Optional[pd.DataFrame]:
    file_path = INTRADAY_DIR / f"{symbol}.parquet"
    if not file_path.exists():
        return None
    try:
        df = pd.read_parquet(file_path)
    except Exception:
        return None
    if len(df) == 0:
        return None
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    if df["timestamp"].dt.tz is None:
        df["timestamp"] = df["timestamp"].dt.tz_localize(IST)
    else:
        df["timestamp"] = df["timestamp"].dt.tz_convert(IST)
    mask = (df["timestamp"] >= start_date) & (df["timestamp"] <= end_date)
    df = df[mask].sort_values("timestamp").reset_index(drop=True)
    df = filter_market_hours(df)
    return df if len(df) > 0 else None


# =============================================================================
# SIGNAL GENERATION (default universe)
# =============================================================================

def generate_default_signals() -> pd.DataFrame:
    print("\n[Signal Generation] Loading panel and scoring...")

    panel = pd.read_parquet(PANEL_PATH)
    panel["timestamp"] = pd.to_datetime(panel["timestamp"])
    if panel["timestamp"].dt.tz is None:
        panel["timestamp"] = panel["timestamp"].dt.tz_localize(IST)

    if "stock_regime" not in panel.columns:
        raise SystemExit("FATAL: panel missing stock_regime")

    panel = panel.sort_values(["symbol", "timestamp"]).reset_index(drop=True)
    panel["avg20_vol"] = panel.groupby("symbol")["volume"].transform(
        lambda s: s.rolling(20, min_periods=1).mean()
    )
    panel = panel[(panel["close"] >= 2.0) & (panel["avg20_vol"] >= 200_000)].reset_index(drop=True)
    panel_trend = panel[panel["stock_regime"].isin(SIGNAL_REGIMES)].copy()

    schema = json.loads(FEATURES_PATH.read_text())
    FEATURES = schema["features"]
    IMPUTE = {k: float(v) for k, v in schema["impute"].items()}

    print(f"  Loading router and scoring {len(panel_trend):,} trend-regime rows...")
    router = load(ROUTER_PATH)

    X = panel_trend.reindex(columns=FEATURES).copy()
    for c in FEATURES:
        X[c] = pd.to_numeric(X[c], errors="coerce").fillna(IMPUTE.get(c, 0.0))

    probs = router.predict_proba_by_regime(X, panel_trend["stock_regime"])
    panel_trend["prob"] = probs
    signals = panel_trend[panel_trend["prob"] >= SIGNAL_PROB_MIN].copy()
    signals = signals[["symbol", "timestamp", "close", "prob", "stock_regime"]].copy()
    signals.columns = ["symbol", "signal_date", "prev_close", "probability", "regime"]

    print(f"  High-conviction signals: {len(signals):,}")
    print(f"  Date range: {signals['signal_date'].min().date()} to {signals['signal_date'].max().date()}")
    return signals


def load_custom_signals(filepath: str) -> pd.DataFrame:
    """Load signals from user-uploaded CSV/Excel file."""
    path = Path(filepath)
    if not path.exists():
        raise SystemExit(f"FATAL: File not found: {filepath}")

    if path.suffix.lower() in (".xlsx", ".xls"):
        df = pd.read_excel(path)
    else:
        df = pd.read_csv(path)

    df.columns = [c.strip().lower() for c in df.columns]

    if "symbol" not in df.columns:
        raise SystemExit("FATAL: Custom file must have 'symbol' column")
    if "signal_date" not in df.columns:
        raise SystemExit("FATAL: Custom file must have 'signal_date' column")

    df["symbol"] = df["symbol"].astype(str).str.strip().str.upper()
    df["signal_date"] = pd.to_datetime(df["signal_date"])
    if df["signal_date"].dt.tz is None:
        df["signal_date"] = df["signal_date"].dt.tz_localize(IST)

    # Add defaults
    if "probability" not in df.columns:
        df["probability"] = 0.75
    if "regime" not in df.columns:
        df["regime"] = "custom"
    if "prev_close" not in df.columns:
        df["prev_close"] = 0.0

    df = df[["symbol", "signal_date", "prev_close", "probability", "regime"]].copy()
    df = df.drop_duplicates(subset=["symbol", "signal_date"]).reset_index(drop=True)

    print(f"  Loaded {len(df):,} custom signals")
    print(f"  Date range: {df['signal_date'].min().date()} to {df['signal_date'].max().date()}")
    print(f"  Unique symbols: {df['symbol'].nunique()}")
    return df


# =============================================================================
# EXTRACTION
# =============================================================================

def extract_signal_paths(symbol, signal_date, probability, regime, prev_close,
                         bars, diagnostics):
    """Bug-fixed extraction with all 6 fixes."""
    if len(bars) == 0:
        diagnostics["no_bars_at_all"] += 1
        return None

    cache_start = bars["timestamp"].min().normalize()
    cache_end = bars["timestamp"].max().normalize()
    sig_date_norm = signal_date.normalize()

    if hasattr(cache_start, 'tz') and cache_start.tz is not None:
        cache_start = cache_start.tz_convert(IST).tz_localize(None)
        cache_end = cache_end.tz_convert(IST).tz_localize(None)
    if hasattr(sig_date_norm, 'tz') and sig_date_norm.tz is not None:
        sig_date_norm = sig_date_norm.tz_convert(IST).tz_localize(None)

    if sig_date_norm < cache_start - pd.Timedelta(days=MAX_SIGNAL_TO_CACHE_GAP_DAYS):
        diagnostics["signal_before_cache"] += 1
        return None
    if sig_date_norm > cache_end:
        diagnostics["signal_after_cache"] += 1
        return None

    bars_after_signal = bars[bars["timestamp"].dt.normalize() > signal_date.normalize()]
    if len(bars_after_signal) == 0:
        diagnostics["no_bars_after_signal"] += 1
        return None

    first_bar_date = bars_after_signal["timestamp"].dt.normalize().iloc[0]
    if hasattr(first_bar_date, 'tz') and first_bar_date.tz is not None:
        first_bar_date = first_bar_date.tz_convert(IST).tz_localize(None)

    gap_days = (first_bar_date - sig_date_norm).days
    if gap_days > MAX_SIGNAL_TO_CACHE_GAP_DAYS:
        diagnostics["signal_too_far_from_next_bars"] += 1
        return None

    unique_days = sorted(bars_after_signal["timestamp"].dt.normalize().unique())
    if len(unique_days) < HOLDING_DAYS:
        diagnostics["insufficient_holding_days"] += 1
        return None

    extended_days = unique_days[:min(EXTENDED_DAYS, len(unique_days))]
    extended_bars = bars[bars["timestamp"].dt.normalize().isin(extended_days)].reset_index(drop=True)

    entry_day = extended_days[0]
    entry_day_bars = daily_bars(extended_bars, entry_day)

    if len(entry_day_bars) < MIN_BARS_PER_DAY:
        diagnostics["insufficient_entry_day_bars"] += 1
        return None

    record = {
        "symbol": symbol, "signal_date": signal_date, "entry_day": entry_day,
        "probability": probability, "regime": regime, "prev_close": prev_close,
        "n_extended_days": len(extended_days),
    }

    for day_idx, day in enumerate(extended_days[:HOLDING_DAYS], start=1):
        day_bars_local = daily_bars(extended_bars, day)
        if len(day_bars_local) > 0:
            record[f"d{day_idx}_open"] = day_bars_local.iloc[0]["open"]
            record[f"d{day_idx}_high"] = day_bars_local["high"].max()
            record[f"d{day_idx}_low"] = day_bars_local["low"].min()
            record[f"d{day_idx}_close"] = day_bars_local.iloc[-1]["close"]
            record[f"d{day_idx}_date"] = day

            for rng_name, rng_def in RANGE_DEFINITIONS.items():
                end_ts = time_to_ts(day, rng_def["end_time"])
                rng_bars = day_bars_local[day_bars_local["timestamp"] <= end_ts]
                if len(rng_bars) >= rng_def["bars_needed"]:
                    record[f"d{day_idx}_orh_{rng_name}"] = rng_bars["high"].max()
                    record[f"d{day_idx}_orl_{rng_name}"] = rng_bars["low"].min()
                else:
                    record[f"d{day_idx}_orh_{rng_name}"] = np.nan
                    record[f"d{day_idx}_orl_{rng_name}"] = np.nan

    for rng_name, rng_def in RANGE_DEFINITIONS.items():
        end_ts = time_to_ts(entry_day, rng_def["end_time"])
        rng_bars = entry_day_bars[entry_day_bars["timestamp"] <= end_ts]
        if len(rng_bars) >= rng_def["bars_needed"]:
            record[f"t1_orh_{rng_name}"] = rng_bars["high"].max()
            record[f"t1_orl_{rng_name}"] = rng_bars["low"].min()
        else:
            record[f"t1_orh_{rng_name}"] = np.nan
            record[f"t1_orl_{rng_name}"] = np.nan

    hold_bars = extended_bars.sort_values("timestamp").reset_index(drop=True)
    extended_days_sorted = sorted({d.normalize() for d in extended_days})
    day_to_idx = {d: i for i, d in enumerate(extended_days_sorted)}
    bar_days_arr = np.array([
        day_to_idx.get(ts.normalize(), -1) for ts in hold_bars["timestamp"]
    ], dtype=int)

    record["bar_timestamps"] = hold_bars["timestamp"].astype("int64").tolist()
    record["bar_opens"] = hold_bars["open"].tolist()
    record["bar_highs"] = hold_bars["high"].tolist()
    record["bar_lows"] = hold_bars["low"].tolist()
    record["bar_closes"] = hold_bars["close"].tolist()
    record["bar_volumes"] = hold_bars["volume"].tolist() if "volume" in hold_bars.columns else [0] * len(hold_bars)
    record["bar_days"] = bar_days_arr.tolist()

    diagnostics["success"] += 1
    return record


def run_extraction(signals: pd.DataFrame, output_path: Path) -> pd.DataFrame:
    print(f"\n[Extraction] Processing {len(signals)} signals...")

    diagnostics = {
        "no_bars_at_all": 0, "signal_before_cache": 0, "signal_after_cache": 0,
        "no_bars_after_signal": 0, "signal_too_far_from_next_bars": 0,
        "insufficient_holding_days": 0, "insufficient_entry_day_bars": 0,
        "success": 0,
    }

    results = []
    n_no_symbol_data = 0
    t_start = time.time()

    signals_by_symbol = signals.groupby("symbol")
    n_symbols = len(signals_by_symbol)

    for sym_idx, (symbol, sym_signals) in enumerate(signals_by_symbol):
        if sym_idx % 50 == 0 and sym_idx > 0:
            elapsed = time.time() - t_start
            rate = sym_idx / elapsed
            eta = (n_symbols - sym_idx) / rate if rate > 0 else 0
            print(f"  [{sym_idx}/{n_symbols}] elapsed={elapsed / 60:.1f}m  "
                  f"ETA={eta / 60:.1f}m  extracted={diagnostics['success']}")

        min_date = sym_signals["signal_date"].min() - pd.Timedelta(days=1)
        max_date = sym_signals["signal_date"].max() + pd.Timedelta(days=20)
        bars = load_bars(symbol, min_date, max_date)

        if bars is None or len(bars) == 0:
            n_no_symbol_data += len(sym_signals)
            continue

        for _, row in sym_signals.iterrows():
            try:
                rec = extract_signal_paths(
                    symbol=symbol, signal_date=row["signal_date"],
                    probability=row["probability"], regime=row["regime"],
                    prev_close=row["prev_close"], bars=bars, diagnostics=diagnostics,
                )
                if rec is not None:
                    results.append(rec)
            except Exception as e:
                print(f"  ERROR on {symbol} {row['signal_date'].date()}: {e}")

    elapsed = time.time() - t_start
    print(f"\n  EXTRACTION DIAGNOSTICS:")
    print(f"  Symbols with no data: {n_no_symbol_data}")
    for k, v in diagnostics.items():
        print(f"  {k:<35} {v}")
    print(f"  Total extracted: {len(results)}  Time: {elapsed / 60:.1f} min")

    diag_rows = [{"reason": "no_symbol_data", "count": n_no_symbol_data}]
    diag_rows += [{"reason": k, "count": v} for k, v in diagnostics.items()]
    pd.DataFrame(diag_rows).to_csv(DIAGNOSTICS_FILE, index=False)

    df = pd.DataFrame(results)
    for c in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[c]):
            try:
                if df[c].dt.tz is not None:
                    df[c] = df[c].dt.tz_localize(None)
            except Exception:
                pass

    df.to_parquet(output_path, index=False)
    print(f"  Saved: {output_path}")
    return df


# =============================================================================
# VARIANT SIMULATOR (with MAE/MFE tracking)
# =============================================================================

def simulate_variant(paths_df: pd.DataFrame, variant: Dict) -> pd.DataFrame:
    """
    Simulate variant. Tracks MAE/MFE for each trade.
    """
    results = []

    range_def = variant["range_def"]
    watch_mode = variant["watch_mode"]
    confirm = variant["confirm"]
    stop_mode = variant["stop_mode"]
    exit_mode = variant["exit_mode"]

    bars_needed_for_range = RANGE_DEFINITIONS[range_def]["bars_needed"]

    min_prob = variant.get("min_probability", 0.0)
    regime_filter = variant.get("regime_filter", None)

    for _, sig in paths_df.iterrows():
        if not isinstance(sig.get("bar_timestamps"), (list, np.ndarray)):
            continue

        # G4/G5: apply min_probability and regime_filter pre-checks
        if sig.get("probability", 0) < min_prob:
            continue
        if regime_filter is not None and sig.get("regime") != regime_filter:
            continue

        bar_ts = pd.to_datetime(sig["bar_timestamps"], unit="ns")
        bar_highs = np.array(sig["bar_highs"])
        bar_lows = np.array(sig["bar_lows"])
        bar_closes = np.array(sig["bar_closes"])
        bar_volumes = np.array(sig.get("bar_volumes", [0] * len(bar_ts)))
        bar_days = np.array(sig["bar_days"])
        n_bars = len(bar_ts)

        if n_bars < 20:
            continue

        # Watch params
        if watch_mode in ("t1_only", "t1_first_30min"):
            watch_max_day = 1
            use_dynamic_range = False
        elif watch_mode == "window_2d":
            watch_max_day = 2
            use_dynamic_range = False
        elif watch_mode == "static_t1_5d":
            watch_max_day = HOLDING_DAYS
            use_dynamic_range = False
        elif watch_mode == "dynamic_each_day":
            watch_max_day = HOLDING_DAYS
            use_dynamic_range = True
        else:
            continue

        if not use_dynamic_range:
            orh = sig.get(f"t1_orh_{range_def}")
            orl = sig.get(f"t1_orl_{range_def}")
            if pd.isna(orh) or pd.isna(orl) or orh <= orl:
                continue

        # Find breakout
        entry_idx = None
        entry_price = None
        entry_orh = None
        entry_orl = None

        for i in range(n_bars):
            day = int(bar_days[i])
            if day < 0 or day >= watch_max_day:
                continue

            if watch_mode == "t1_first_30min":
                ts = bar_ts[i]
                if ts.tz is None:
                    ts_ist = ts.tz_localize(IST)
                else:
                    ts_ist = ts.tz_convert(IST)
                if ts_ist.hour > 9 or (ts_ist.hour == 9 and ts_ist.minute > 45):
                    break

            if use_dynamic_range:
                day_label = day + 1
                day_orh = sig.get(f"d{day_label}_orh_{range_def}")
                day_orl = sig.get(f"d{day_label}_orl_{range_def}")
                if pd.isna(day_orh) or pd.isna(day_orl):
                    continue
                same_day_bars_before = np.sum(bar_days[:i] == day)
                if same_day_bars_before < bars_needed_for_range:
                    continue
                active_orh = day_orh
                active_orl = day_orl
            else:
                if day == 0:
                    same_day_bars_before = np.sum(bar_days[:i] == 0)
                    if same_day_bars_before < bars_needed_for_range:
                        continue
                active_orh = orh
                active_orl = orl

            triggered = False
            if confirm == "touch_above":
                triggered = bar_highs[i] > active_orh
            elif confirm == "close_above":
                triggered = bar_closes[i] > active_orh
            elif confirm == "two_consecutive":
                triggered = i > 0 and bar_closes[i] > active_orh and bar_closes[i - 1] > active_orh
            elif confirm == "close_no_reversal":
                if bar_closes[i] > active_orh:
                    reversal = False
                    for j in range(i + 1, min(i + 7, n_bars)):
                        if bar_closes[j] < active_orh:
                            reversal = True
                            break
                    triggered = not reversal
            elif confirm == "close_no_reversal_15min":
                # H1: 15-min reversal check (3 bars instead of 6)
                if bar_closes[i] > active_orh:
                    reversal = False
                    for j in range(i + 1, min(i + 4, n_bars)):
                        if bar_closes[j] < active_orh:
                            reversal = True
                            break
                    triggered = not reversal
            elif confirm == "close_held_eod":
                if bar_closes[i] > active_orh:
                    same_day_idxs = np.where(bar_days == day)[0]
                    if len(same_day_idxs) > 0:
                        last_bar_of_day = same_day_idxs[-1]
                        triggered = bar_closes[last_bar_of_day] > active_orh
            elif confirm == "close_no_reversal_volume":
                # G1: F3 with volume confirmation
                # Same as no-reversal but breakout bar must have 1.5x avg volume of last 6 bars
                if bar_closes[i] > active_orh:
                    # Reversal check
                    reversal = False
                    for j in range(i + 1, min(i + 7, n_bars)):
                        if bar_closes[j] < active_orh:
                            reversal = True
                            break
                    # Volume check: this bar's volume must be 1.5x avg of last 6 bars (or 2 if early)
                    lookback = max(1, min(i, 6))
                    avg_vol = bar_volumes[max(0, i - lookback):i].mean() if i > 0 else 1
                    high_vol = avg_vol > 0 and bar_volumes[i] >= 1.5 * avg_vol
                    triggered = (not reversal) and high_vol
            elif confirm == "close_eod_entry":
                # G2: HONEST F7 - enter only at 3:25 PM, only if EOD close > range_high
                # We override behavior: only fire on the second-to-last bar of T+1 day
                if day != 0:
                    continue
                # Find the last bar of T+1 (around 15:25)
                same_day_idxs = np.where(bar_days == 0)[0]
                if len(same_day_idxs) == 0:
                    continue
                last_idx_t1 = same_day_idxs[-1]
                second_last_idx = same_day_idxs[-2] if len(same_day_idxs) >= 2 else last_idx_t1
                # Only trigger on the second-to-last bar (~3:25 PM)
                if i != second_last_idx:
                    continue
                # Check that the last bar close (~3:30 close) is above active_orh
                if bar_closes[last_idx_t1] > active_orh:
                    triggered = True
                    # Override entry price to second-to-last close (3:25 PM)
            elif confirm == "close_pullback":
                # G3: Wait for breakout, then wait for pullback to range_high, then enter on hold
                # State machine: detect breakout, then wait for pullback (price touches range_high again),
                # then enter on next bar that holds above range_high.
                if bar_closes[i] > active_orh:
                    # Look forward for pullback
                    pullback_found = False
                    for j in range(i + 1, min(i + 15, n_bars)):  # up to 15 bars (75 min) ahead
                        # Pullback: low touches near range high (within 0.5%)
                        if bar_lows[j] <= active_orh * 1.005 and bar_lows[j] >= active_orh * 0.995:
                            pullback_found = True
                            # Now check next bar holds
                            if j + 1 < n_bars and bar_closes[j + 1] > active_orh:
                                # Enter at j+1's close, not i's close
                                entry_idx = j + 1
                                entry_price = bar_closes[j + 1]
                                entry_orh = active_orh
                                entry_orl = active_orl
                                triggered = False  # Already set above, skip the normal trigger path
                                break
                    # If we found entry, jump out of main loop
                    if entry_idx is not None:
                        break

            if triggered:
                entry_idx = i
                entry_price = bar_closes[i]
                entry_orh = active_orh
                entry_orl = active_orl
                # G2 special: if EOD entry mode, use 3:25 PM price (second-to-last bar of T+1)
                if confirm == "close_eod_entry":
                    same_day_idxs = np.where(bar_days == 0)[0]
                    if len(same_day_idxs) >= 2:
                        entry_idx = same_day_idxs[-2]
                        entry_price = bar_closes[entry_idx]
                break

        if entry_idx is None or entry_price is None or entry_price <= 0:
            continue

        # Stop
        if stop_mode == "range_low":
            stop_price = entry_orl
            stop_pct_from_entry = (stop_price / entry_price - 1) * 100
            if stop_price >= entry_price:
                continue
        elif stop_mode == "fixed_3pct":
            stop_pct_from_entry = -3.0
            stop_price = entry_price * 0.97
        elif stop_mode == "fixed_5pct":
            stop_pct_from_entry = -5.0
            stop_price = entry_price * 0.95
        elif stop_mode == "fixed_7pct":
            stop_pct_from_entry = -7.0
            stop_price = entry_price * 0.93
        elif stop_mode == "two_range_size":
            range_size = entry_orh - entry_orl
            stop_price = entry_price - 2 * range_size
            stop_pct_from_entry = (stop_price / entry_price - 1) * 100
            if stop_price >= entry_price:
                continue
        else:
            continue

        # Target
        target_price = None
        if exit_mode == "target_3pct":
            target_price = entry_price * 1.03
        elif exit_mode == "target_5pct":
            target_price = entry_price * 1.05
        elif exit_mode == "target_7pct":
            target_price = entry_price * 1.07
        elif exit_mode == "target_2r":
            range_size = entry_orh - entry_orl
            target_price = entry_price + 2 * range_size

        # Exit: stop FIRST, then target, then time
        exit_price = None
        exit_idx = None
        trigger_reason = None

        # MAE/MFE tracking during hold
        mae_pct = 0.0  # max adverse excursion (most negative)
        mfe_pct = 0.0  # max favorable excursion (most positive)
        mae_time = None
        mfe_time = None

        if exit_mode == "t5_close":
            for j in range(entry_idx + 1, n_bars):
                # Update MAE/MFE
                low_pct = (bar_lows[j] / entry_price - 1) * 100
                high_pct = (bar_highs[j] / entry_price - 1) * 100
                if low_pct < mae_pct:
                    mae_pct = low_pct
                    mae_time = bar_ts[j]
                if high_pct > mfe_pct:
                    mfe_pct = high_pct
                    mfe_time = bar_ts[j]

                if bar_lows[j] <= stop_price:
                    exit_price = stop_price
                    exit_idx = j
                    trigger_reason = "stop"
                    break
                if bar_days[j] >= HOLDING_DAYS - 1:
                    if j == n_bars - 1 or bar_days[j + 1] > HOLDING_DAYS - 1:
                        exit_price = bar_closes[j]
                        exit_idx = j
                        trigger_reason = "time"
                        break
            if exit_price is None:
                exit_price = bar_closes[-1]
                exit_idx = n_bars - 1
                trigger_reason = "time"

        elif exit_mode in ("target_3pct", "target_5pct", "target_7pct", "target_2r"):
            for j in range(entry_idx + 1, n_bars):
                low_pct = (bar_lows[j] / entry_price - 1) * 100
                high_pct = (bar_highs[j] / entry_price - 1) * 100
                if low_pct < mae_pct:
                    mae_pct = low_pct
                    mae_time = bar_ts[j]
                if high_pct > mfe_pct:
                    mfe_pct = high_pct
                    mfe_time = bar_ts[j]

                if bar_lows[j] <= stop_price:
                    exit_price = stop_price
                    exit_idx = j
                    trigger_reason = "stop"
                    break
                if bar_highs[j] >= target_price:
                    exit_price = target_price
                    exit_idx = j
                    trigger_reason = "target"
                    break
                if bar_days[j] >= HOLDING_DAYS - 1:
                    if j == n_bars - 1 or bar_days[j + 1] > HOLDING_DAYS - 1:
                        exit_price = bar_closes[j]
                        exit_idx = j
                        trigger_reason = "time"
                        break
            if exit_price is None:
                exit_price = bar_closes[-1]
                exit_idx = n_bars - 1
                trigger_reason = "time"

        elif exit_mode == "rolling_5d":
            entry_day_offset = int(bar_days[entry_idx])
            target_exit_day = entry_day_offset + 5

            for j in range(entry_idx + 1, n_bars):
                low_pct = (bar_lows[j] / entry_price - 1) * 100
                high_pct = (bar_highs[j] / entry_price - 1) * 100
                if low_pct < mae_pct:
                    mae_pct = low_pct
                    mae_time = bar_ts[j]
                if high_pct > mfe_pct:
                    mfe_pct = high_pct
                    mfe_time = bar_ts[j]

                if bar_lows[j] <= stop_price:
                    exit_price = stop_price
                    exit_idx = j
                    trigger_reason = "stop"
                    break
                if bar_days[j] >= target_exit_day:
                    if j == n_bars - 1 or bar_days[j + 1] > target_exit_day:
                        exit_price = bar_closes[j]
                        exit_idx = j
                        trigger_reason = "time"
                        break
            if exit_price is None:
                exit_price = bar_closes[-1]
                exit_idx = n_bars - 1
                trigger_reason = "time"
        else:
            continue

        gross_ret = (exit_price / entry_price - 1) * 100

        if gross_ret > MAX_PLAUSIBLE_RETURN_PCT or gross_ret < MIN_PLAUSIBLE_RETURN_PCT:
            continue

        # Simple net return for comparison (without portfolio sim)
        cost_bps = 25 + 2 * SLIPPAGE_BPS_PER_SIDE
        net_ret = gross_ret - cost_bps / 100

        entry_day_idx = int(bar_days[entry_idx])
        exit_day_idx = int(bar_days[exit_idx])
        days_held = exit_day_idx - entry_day_idx
        entry_day_offset = entry_day_idx + 1

        results.append({
            "symbol": sig["symbol"],
            "signal_date": sig["signal_date"],
            "entry_day": sig["entry_day"],
            "probability": sig["probability"],
            "regime": sig["regime"],
            "entry_time": bar_ts[entry_idx],
            "entry_price": round(entry_price, 4),
            "entry_day_offset": entry_day_offset,
            "exit_time": bar_ts[exit_idx],
            "exit_price": round(exit_price, 4),
            "stop_price": round(stop_price, 4),
            "stop_pct": round(stop_pct_from_entry, 2),
            "target_price": round(target_price, 4) if target_price else 0,
            "gross_ret_pct": round(gross_ret, 3),
            "net_ret_pct": round(net_ret, 3),
            "days_held": days_held,
            "trigger_reason": trigger_reason,
            "mae_pct": round(mae_pct, 2),
            "mfe_pct": round(mfe_pct, 2),
            "mae_time": mae_time,
            "mfe_time": mfe_time,
            "mae_to_entry_ratio": round(mae_pct / stop_pct_from_entry, 2) if stop_pct_from_entry != 0 else 0,
            "mfe_realized_ratio": round(gross_ret / mfe_pct, 2) if mfe_pct > 0 else 0,
        })

    return pd.DataFrame(results)


# =============================================================================
# PORTFOLIO SIMULATOR
# =============================================================================

def run_portfolio_simulator(trades_df: pd.DataFrame, config: Dict) -> Dict:
    """
    Walk through trades chronologically with portfolio mechanics.

    config keys:
      starting_capital: INR
      capital_per_trade: INR per trade
      max_concurrent: max simultaneous positions
      conflict_rule: 'top_n_prob' or 'first_come' or 'all_or_skip'
      apply_indian_costs: bool
    """
    if len(trades_df) == 0:
        return {"error": "No trades to simulate"}

    starting_capital = config["starting_capital"]
    capital_per_trade = config["capital_per_trade"]
    max_concurrent = config["max_concurrent"]
    conflict_rule = config.get("conflict_rule", "top_n_prob")
    apply_indian_costs = config.get("apply_indian_costs", True)

    # Prepare trades: ensure tz-naive
    df = trades_df.copy()
    for c in ["entry_time", "exit_time"]:
        if c in df.columns:
            df[c] = pd.to_datetime(df[c])
            if df[c].dt.tz is not None:
                df[c] = df[c].dt.tz_localize(None)

    df = df.sort_values("entry_time").reset_index(drop=True)

    # Build event timeline: each trade has entry event and exit event
    events = []
    for idx, row in df.iterrows():
        events.append({"timestamp": row["entry_time"], "type": "entry", "trade_idx": idx})
        events.append({"timestamp": row["exit_time"], "type": "exit", "trade_idx": idx})
    events_df = pd.DataFrame(events).sort_values(["timestamp", "type"], ascending=[True, False]).reset_index(drop=True)
    # ^^^ sort entries before exits at same timestamp - but actually exits should be processed FIRST
    # to free up capital. Let me flip - exits before entries at same timestamp:
    events_df = pd.DataFrame(events).sort_values(["timestamp"], ascending=[True]).reset_index(drop=True)
    # Among same timestamp, process exits first
    events_df["sort_key"] = events_df["type"].map({"exit": 0, "entry": 1})
    events_df = events_df.sort_values(["timestamp", "sort_key"]).reset_index(drop=True)

    # Portfolio state
    cash = starting_capital
    open_positions = {}  # trade_idx -> position dict
    completed_trades = []
    rejected_trades = []

    # Group entries by timestamp for conflict resolution
    pending_entries_by_ts = {}
    for _, ev in events_df[events_df["type"] == "entry"].iterrows():
        ts = ev["timestamp"]
        if ts not in pending_entries_by_ts:
            pending_entries_by_ts[ts] = []
        pending_entries_by_ts[ts].append(ev["trade_idx"])

    # Walk events
    equity_log = []

    for _, ev in events_df.iterrows():
        ts = ev["timestamp"]
        trade_idx = ev["trade_idx"]
        trade = df.iloc[trade_idx]

        if ev["type"] == "exit":
            if trade_idx in open_positions:
                pos = open_positions.pop(trade_idx)
                # Realize P&L
                gross_pnl = (trade["exit_price"] - pos["entry_price"]) * pos["shares"]

                # Apply costs
                if apply_indian_costs:
                    trade_value_buy = pos["entry_price"] * pos["shares"]
                    trade_value_sell = trade["exit_price"] * pos["shares"]
                    is_intraday = trade["days_held"] == 0
                    costs_buy = compute_indian_costs(trade_value_buy, is_intraday, "buy")
                    costs_sell = compute_indian_costs(trade_value_sell, is_intraday, "sell")
                    total_costs = costs_buy["total"] + costs_sell["total"]
                    # Slippage
                    slippage = (trade_value_buy + trade_value_sell) * (SLIPPAGE_BPS_PER_SIDE / 10000)
                    total_costs += slippage
                else:
                    total_costs = 0.0

                net_pnl = gross_pnl - total_costs
                cash += pos["capital_used"] + net_pnl

                completed_trades.append({
                    "symbol": trade["symbol"],
                    "signal_date": trade["signal_date"],
                    "entry_time": pos["entry_time"],
                    "exit_time": trade["exit_time"],
                    "entry_price": pos["entry_price"],
                    "exit_price": trade["exit_price"],
                    "shares": pos["shares"],
                    "capital_deployed": pos["capital_used"],
                    "gross_pnl": gross_pnl,
                    "total_costs": total_costs,
                    "net_pnl": net_pnl,
                    "net_ret_pct": (net_pnl / pos["capital_used"]) * 100 if pos["capital_used"] > 0 else 0,
                    "gross_ret_pct": trade["gross_ret_pct"],
                    "days_held": trade["days_held"],
                    "trigger_reason": trade["trigger_reason"],
                    "probability": trade["probability"],
                    "regime": trade["regime"],
                    "mae_pct": trade.get("mae_pct", 0),
                    "mfe_pct": trade.get("mfe_pct", 0),
                })

                equity_log.append({
                    "timestamp": ts,
                    "event": "exit",
                    "symbol": trade["symbol"],
                    "cash": cash,
                    "open_positions": len(open_positions),
                    "total_equity": cash + sum(p["capital_used"] for p in open_positions.values()),
                })

        elif ev["type"] == "entry":
            # Check if this is the FIRST entry at this timestamp (group resolution)
            if ts in pending_entries_by_ts:
                # Resolve all entries at this timestamp at once
                trade_indices = pending_entries_by_ts.pop(ts)

                # Available slots
                slots_available = max_concurrent - len(open_positions)

                if len(trade_indices) > slots_available and slots_available > 0:
                    # Conflict resolution
                    if conflict_rule == "top_n_prob":
                        # Sort by probability descending, take top N
                        candidates = [(idx, df.iloc[idx]["probability"]) for idx in trade_indices]
                        candidates.sort(key=lambda x: -x[1])
                        accepted = [c[0] for c in candidates[:slots_available]]
                        rejected = [c[0] for c in candidates[slots_available:]]
                    elif conflict_rule == "first_come":
                        accepted = trade_indices[:slots_available]
                        rejected = trade_indices[slots_available:]
                    elif conflict_rule == "all_or_skip":
                        # Either take all or skip all
                        if len(trade_indices) <= slots_available:
                            accepted = trade_indices
                            rejected = []
                        else:
                            accepted = []
                            rejected = trade_indices
                    elif conflict_rule == "scale_down":
                        # Take all but with smaller position size
                        accepted = trade_indices
                        rejected = []
                    else:
                        accepted = trade_indices[:slots_available]
                        rejected = trade_indices[slots_available:]
                elif slots_available <= 0:
                    accepted = []
                    rejected = trade_indices
                else:
                    accepted = trade_indices
                    rejected = []

                for r_idx in rejected:
                    r_trade = df.iloc[r_idx]
                    rejected_trades.append({
                        "symbol": r_trade["symbol"],
                        "entry_time": r_trade["entry_time"],
                        "reason": "max_concurrent_reached",
                        "probability": r_trade["probability"],
                    })

                # Compute capital per accepted trade
                if conflict_rule == "scale_down" and len(accepted) > slots_available and slots_available > 0:
                    per_trade_capital = capital_per_trade * (slots_available / len(accepted))
                else:
                    per_trade_capital = capital_per_trade

                for a_idx in accepted:
                    a_trade = df.iloc[a_idx]

                    # Determine effective capital (cap at available cash)
                    needed_capital = min(per_trade_capital, cash)
                    if needed_capital < a_trade["entry_price"]:
                        rejected_trades.append({
                            "symbol": a_trade["symbol"],
                            "entry_time": a_trade["entry_time"],
                            "reason": "insufficient_cash",
                            "probability": a_trade["probability"],
                        })
                        continue

                    shares = int(needed_capital / a_trade["entry_price"])
                    if shares <= 0:
                        rejected_trades.append({
                            "symbol": a_trade["symbol"],
                            "entry_time": a_trade["entry_time"],
                            "reason": "share_size_zero",
                            "probability": a_trade["probability"],
                        })
                        continue

                    actual_capital = shares * a_trade["entry_price"]

                    cash -= actual_capital
                    open_positions[a_idx] = {
                        "entry_time": a_trade["entry_time"],
                        "entry_price": a_trade["entry_price"],
                        "shares": shares,
                        "capital_used": actual_capital,
                    }

                    equity_log.append({
                        "timestamp": ts,
                        "event": "entry",
                        "symbol": a_trade["symbol"],
                        "cash": cash,
                        "open_positions": len(open_positions),
                        "total_equity": cash + sum(p["capital_used"] for p in open_positions.values()),
                    })

    # Final stats
    completed_df = pd.DataFrame(completed_trades)
    rejected_df = pd.DataFrame(rejected_trades)
    equity_df = pd.DataFrame(equity_log)

    if len(completed_df) == 0:
        return {"error": "No trades completed"}

    # Build daily equity curve
    if len(equity_df) > 0:
        equity_df["date"] = pd.to_datetime(equity_df["timestamp"]).dt.date
        daily_equity = equity_df.groupby("date")["total_equity"].last().reset_index()
        daily_equity["date"] = pd.to_datetime(daily_equity["date"])
        daily_equity = daily_equity.sort_values("date").reset_index(drop=True)
        daily_equity["returns_pct"] = daily_equity["total_equity"].pct_change() * 100

        # Drawdown
        daily_equity["running_max"] = daily_equity["total_equity"].cummax()
        daily_equity["drawdown_pct"] = ((daily_equity["total_equity"] - daily_equity["running_max"])
                                        / daily_equity["running_max"]) * 100
    else:
        daily_equity = pd.DataFrame()

    # Compute portfolio stats
    total_pnl = completed_df["net_pnl"].sum()
    total_cost = completed_df["total_costs"].sum()
    end_equity = starting_capital + total_pnl

    win_trades = completed_df[completed_df["net_pnl"] > 0]
    loss_trades = completed_df[completed_df["net_pnl"] < 0]

    # Time-based stats
    first_trade = completed_df["entry_time"].min()
    last_trade = completed_df["exit_time"].max()
    duration_years = (last_trade - first_trade).days / 365.25

    if duration_years > 0:
        cagr = ((end_equity / starting_capital) ** (1 / duration_years) - 1) * 100
    else:
        cagr = 0.0

    if len(daily_equity) > 1:
        max_dd_pct = daily_equity["drawdown_pct"].min()
        # Drawdown duration
        in_dd = daily_equity["drawdown_pct"] < 0
        if in_dd.any():
            # Longest consecutive drawdown stretch
            dd_groups = (in_dd != in_dd.shift()).cumsum()
            dd_durations = in_dd.groupby(dd_groups).sum()
            max_dd_days = int(dd_durations.max())
        else:
            max_dd_days = 0

        # Sharpe (daily)
        daily_returns = daily_equity["returns_pct"].dropna()
        if len(daily_returns) > 1 and daily_returns.std() > 0:
            sharpe_daily = daily_returns.mean() / daily_returns.std() * np.sqrt(252)
        else:
            sharpe_daily = 0.0

        # Sortino (downside only)
        downside = daily_returns[daily_returns < 0]
        if len(downside) > 0 and downside.std() > 0:
            sortino = daily_returns.mean() / downside.std() * np.sqrt(252)
        else:
            sortino = 0.0

        # Calmar
        calmar = cagr / abs(max_dd_pct) if max_dd_pct != 0 else 0
    else:
        max_dd_pct = 0
        max_dd_days = 0
        sharpe_daily = 0
        sortino = 0
        calmar = 0

    # Profit factor
    gross_profit = win_trades["net_pnl"].sum() if len(win_trades) > 0 else 0
    gross_loss = abs(loss_trades["net_pnl"].sum()) if len(loss_trades) > 0 else 0
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')

    stats = {
        "starting_capital": starting_capital,
        "ending_capital": end_equity,
        "total_pnl": total_pnl,
        "total_costs": total_cost,
        "total_return_pct": ((end_equity / starting_capital) - 1) * 100,
        "cagr_pct": cagr,
        "duration_years": duration_years,
        "n_trades_taken": len(completed_df),
        "n_trades_rejected": len(rejected_df),
        "rejection_rate_pct": 100 * len(rejected_df) / (len(completed_df) + len(rejected_df)) if (
                                                                                                             len(completed_df) + len(
                                                                                                         rejected_df)) > 0 else 0,
        "win_rate_pct": 100 * len(win_trades) / len(completed_df) if len(completed_df) > 0 else 0,
        "avg_win_inr": win_trades["net_pnl"].mean() if len(win_trades) > 0 else 0,
        "avg_loss_inr": loss_trades["net_pnl"].mean() if len(loss_trades) > 0 else 0,
        "largest_win_inr": completed_df["net_pnl"].max(),
        "largest_loss_inr": completed_df["net_pnl"].min(),
        "avg_pnl_per_trade": completed_df["net_pnl"].mean(),
        "profit_factor": profit_factor,
        "max_drawdown_pct": max_dd_pct,
        "max_drawdown_days": max_dd_days,
        "sharpe_daily_annual": sharpe_daily,
        "sortino_annual": sortino,
        "calmar_ratio": calmar,
        "avg_days_held": completed_df["days_held"].mean(),
        "max_concurrent_actual": equity_df["open_positions"].max() if len(equity_df) > 0 else 0,
    }

    return {
        "stats": stats,
        "completed_trades": completed_df,
        "rejected_trades": rejected_df,
        "equity_log": equity_df,
        "daily_equity": daily_equity,
    }


# =============================================================================
# RUNNER + VALIDATION
# =============================================================================

def run_variant(paths_df: pd.DataFrame, variant_id: str, variant: Dict) -> Tuple[Dict, pd.DataFrame]:
    trades = simulate_variant(paths_df, variant)
    n_signals = len(paths_df)
    n_trades = len(trades)
    filter_rate = round(100 * (1 - n_trades / max(n_signals, 1)), 2)

    if n_trades < MIN_TRADES_FOR_VARIANT:
        return {
            "variant_id": variant_id, "family": variant["family"], "label": variant["label"],
            "n_signals": n_signals, "n_trades": n_trades, "filter_rate_pct": filter_rate,
            "INSUFFICIENT_DATA": True,
        }, trades

    net = trades["net_ret_pct"].values
    metrics = compute_metrics(net, label=variant["label"])

    stop_hits = (trades["trigger_reason"] == "stop").sum()
    target_hits = (trades["trigger_reason"] == "target").sum()
    time_exits = (trades["trigger_reason"] == "time").sum()

    return {
        "variant_id": variant_id, "family": variant["family"], "label": variant["label"],
        "n_signals": n_signals, "n_trades": n_trades, "filter_rate_pct": filter_rate,
        **{k: metrics[k] for k in ["win_rate_pct", "avg_ret_pct", "median_ret_pct",
                                   "avg_win_pct", "avg_loss_pct", "std_pct",
                                   "sharpe_annual", "min_ret", "max_ret", "p10", "p90"]},
        "stop_hits": stop_hits, "target_hits": target_hits, "time_exits": time_exits,
        "avg_days_held": round(trades["days_held"].mean(), 2),
        "avg_mae_pct": round(trades["mae_pct"].mean(), 2),
        "avg_mfe_pct": round(trades["mfe_pct"].mean(), 2),
        "INSUFFICIENT_DATA": False,
    }, trades


def run_validation_check(paths_df: pd.DataFrame, top_variants: List[Tuple[str, Dict]]) -> pd.DataFrame:
    paths_df = paths_df.copy()
    paths_df["signal_date"] = pd.to_datetime(paths_df["signal_date"])
    paths_df = paths_df.sort_values("signal_date").reset_index(drop=True)
    cutoff_idx = int(len(paths_df) * (1 - VALIDATION_FRACTION))
    discovery = paths_df.iloc[:cutoff_idx]
    validation = paths_df.iloc[cutoff_idx:]

    print(f"\n  Discovery: {len(discovery)}  Validation: {len(validation)}")

    rows = []
    for vid, variant in top_variants:
        ds, _ = run_variant(discovery, vid, variant)
        vs, _ = run_variant(validation, vid, variant)
        if ds.get("INSUFFICIENT_DATA") or vs.get("INSUFFICIENT_DATA"):
            continue
        retention = (vs["sharpe_annual"] / ds["sharpe_annual"] * 100) if ds["sharpe_annual"] != 0 else 0
        rows.append({
            "variant_id": vid, "label": variant["label"],
            "discovery_sharpe": ds["sharpe_annual"], "validation_sharpe": vs["sharpe_annual"],
            "discovery_n": ds["n_trades"], "validation_n": vs["n_trades"],
            "retention_pct": round(retention, 1),
            "passes": "YES" if retention >= 80 else "NO",
        })
    return pd.DataFrame(rows)


# =============================================================================
# INTERACTIVE PROMPTS
# =============================================================================

def prompt_universe() -> Tuple[str, Optional[str]]:
    """Returns (mode, custom_filepath)."""
    print("\n" + "=" * 70)
    print("STEP 1: CHOOSE UNIVERSE")
    print("=" * 70)
    print("  [1] Default: model signals (prob >= 0.75, trend regimes)")
    print("  [2] Custom: upload CSV/Excel with symbol+date pairs")

    choice = input("\nYour choice [1/2]: ").strip()
    if choice == "2":
        path = input("Path to your file: ").strip().strip('"').strip("'")
        return "custom", path
    return "default", None


def prompt_variant() -> List[str]:
    """Returns list of variant IDs to run."""
    print("\n" + "=" * 70)
    print("STEP 2: CHOOSE VARIANT(S)")
    print("=" * 70)
    print("  [1] Single variant")
    print("  [2] Specific family")
    print("  [3] All 30 variants")

    choice = input("\nYour choice [1/2/3]: ").strip()

    if choice == "1":
        print("\nAvailable variants:")
        for vid, v in VARIANT_PRESETS.items():
            print(f"  {vid:<32} {v['label']}")
        vid = input("\nEnter variant ID: ").strip()
        if vid not in VARIANT_PRESETS:
            print(f"Unknown variant: {vid}. Defaulting to F7.")
            vid = "F7_t1_heldEOD_5pct"
        return [vid]

    elif choice == "2":
        families = sorted({v["family"] for v in VARIANT_PRESETS.values()})
        print("\nFamilies:")
        for i, fam in enumerate(families, 1):
            print(f"  [{i}] {fam}")
        fam_choice = input("\nFamily number: ").strip()
        try:
            fam = families[int(fam_choice) - 1]
            return [vid for vid, v in VARIANT_PRESETS.items() if v["family"] == fam]
        except (ValueError, IndexError):
            print("Invalid choice. Running all.")
            return list(VARIANT_PRESETS.keys())

    return list(VARIANT_PRESETS.keys())


def prompt_portfolio() -> Optional[Dict]:
    """Returns portfolio config dict or None if skipped."""
    print("\n" + "=" * 70)
    print("STEP 3: PORTFOLIO SIMULATOR")
    print("=" * 70)
    enable = input("\nRun portfolio simulator? [y/n]: ").strip().lower()
    if enable != "y":
        return None

    def get_int(prompt, default):
        val = input(f"{prompt} [{default}]: ").strip()
        if not val:
            return default
        try:
            return int(val.replace(",", "").replace("_", ""))
        except ValueError:
            return default

    starting = get_int("Starting capital (INR)", DEFAULT_STARTING_CAPITAL)
    per_trade = get_int("Capital per trade (INR)", DEFAULT_CAPITAL_PER_TRADE)
    max_conc = get_int("Max concurrent positions", DEFAULT_MAX_CONCURRENT)

    print("\nConflict resolution (when more signals than slots available):")
    print("  [1] Take top-N by probability (recommended)")
    print("  [2] First-come, first-served")
    print("  [3] All-or-skip (take all signals or none)")
    print("  [4] Scale-down (take all, smaller positions)")

    conflict_choice = input("\nYour choice [1]: ").strip()
    conflict_map = {"1": "top_n_prob", "2": "first_come", "3": "all_or_skip", "4": "scale_down"}
    conflict = conflict_map.get(conflict_choice, "top_n_prob")

    indian_costs = input("\nApply Indian brokerage costs (Zerodha)? [y/n]: ").strip().lower()
    apply_costs = indian_costs != "n"

    return {
        "starting_capital": starting,
        "capital_per_trade": per_trade,
        "max_concurrent": max_conc,
        "conflict_rule": conflict,
        "apply_indian_costs": apply_costs,
    }


# =============================================================================
# MAIN
# =============================================================================

def main():
    import argparse
    p = argparse.ArgumentParser(description="ORB Workshop")
    p.add_argument("--rebuild", action="store_true")
    p.add_argument("--batch", action="store_true", help="Skip prompts, use defaults")
    args = p.parse_args()

    print("=" * 80)
    print("ORB WORKSHOP - Backtester + Portfolio Simulator")
    print("=" * 80)

    # === STEP 1: Universe ===
    if args.batch:
        universe_mode = "default"
        custom_path = None
    else:
        universe_mode, custom_path = prompt_universe()

    # === STEP 2: Variant(s) ===
    if args.batch:
        variant_ids = list(VARIANT_PRESETS.keys())
    else:
        variant_ids = prompt_variant()

    # === STEP 3: Portfolio simulator ===
    if args.batch:
        portfolio_config = None
    else:
        portfolio_config = prompt_portfolio()

    # === Load or extract paths ===
    if universe_mode == "default":
        paths_file = DEFAULT_PATHS_FILE
        if paths_file.exists() and not args.rebuild:
            print(f"\nLoading existing paths: {paths_file}")
            paths_df = pd.read_parquet(paths_file)
            print(f"  {len(paths_df):,} signal paths")
        else:
            signals = generate_default_signals()
            paths_df = run_extraction(signals, paths_file)
    else:
        paths_file = CUSTOM_PATHS_FILE
        signals = load_custom_signals(custom_path)
        paths_df = run_extraction(signals, paths_file)

    if len(paths_df) == 0:
        raise SystemExit("FATAL: No paths extracted")

    # === Run variants ===
    print("\n" + "=" * 80)
    print(f"RUNNING {len(variant_ids)} VARIANT(S)")
    print("=" * 80)

    all_summaries = []
    all_trades = {}

    for i, vid in enumerate(variant_ids):
        variant = VARIANT_PRESETS[vid]
        t0 = time.time()
        summary, trades = run_variant(paths_df, vid, variant)
        elapsed = time.time() - t0

        all_summaries.append(summary)
        all_trades[vid] = trades

        if summary.get("INSUFFICIENT_DATA"):
            print(f"  [{i + 1}/{len(variant_ids)}] {vid:<32} INSUFFICIENT ({summary['n_trades']} trades)")
        else:
            print(f"  [{i + 1}/{len(variant_ids)}] {vid:<32} "
                  f"n={summary['n_trades']:>5,}  filter={summary['filter_rate_pct']:>5.1f}%  "
                  f"avg={summary['avg_ret_pct']:>+6.3f}%  Sharpe={summary['sharpe_annual']:>5.2f}  "
                  f"MAE={summary['avg_mae_pct']:>+5.2f}  MFE={summary['avg_mfe_pct']:>+5.2f}  "
                  f"({elapsed:.1f}s)")

    summary_df = pd.DataFrame(all_summaries)
    summary_df = summary_df.sort_values("sharpe_annual", ascending=False, na_position="last").reset_index(drop=True)

    # === Validation (only if multiple variants) ===
    val_df = pd.DataFrame()
    if len(variant_ids) > 1:
        print("\n" + "=" * 80)
        print("VALIDATION CHECK")
        print("=" * 80)
        valid = summary_df[~summary_df.get("INSUFFICIENT_DATA", False)]
        top_for_val = [(row["variant_id"], VARIANT_PRESETS[row["variant_id"]])
                       for _, row in valid.head(10).iterrows()]
        val_df = run_validation_check(paths_df, top_for_val)
        if len(val_df) > 0:
            for _, row in val_df.iterrows():
                print(f"  {row['variant_id']:<32} Disc={row['discovery_sharpe']:>5.2f}  "
                      f"Val={row['validation_sharpe']:>5.2f}  Retention={row['retention_pct']:>5.1f}%  "
                      f"{row['passes']:>3}")

    # === Portfolio simulator ===
    portfolio_results = {}
    if portfolio_config is not None:
        print("\n" + "=" * 80)
        print("PORTFOLIO SIMULATOR")
        print("=" * 80)
        print(f"  Starting capital:  Rs {portfolio_config['starting_capital']:>15,}")
        print(f"  Capital per trade: Rs {portfolio_config['capital_per_trade']:>15,}")
        print(f"  Max concurrent:    {portfolio_config['max_concurrent']}")
        print(f"  Conflict rule:     {portfolio_config['conflict_rule']}")
        print(f"  Indian costs:      {portfolio_config['apply_indian_costs']}")

        for vid in variant_ids:
            if vid in all_trades and len(all_trades[vid]) > 0:
                print(f"\n  Running portfolio sim for {vid}...")
                pf_result = run_portfolio_simulator(all_trades[vid], portfolio_config)
                portfolio_results[vid] = pf_result

                if "stats" in pf_result:
                    s = pf_result["stats"]
                    print(f"\n  RESULTS for {vid}:")
                    print(f"    Trades taken: {s['n_trades_taken']:>6,}  Rejected: {s['n_trades_rejected']:>5,}")
                    print(f"    Win rate:     {s['win_rate_pct']:>6.2f}%")
                    print(f"    Total P&L:    Rs {s['total_pnl']:>15,.0f}")
                    print(f"    Total return: {s['total_return_pct']:>6.2f}%")
                    print(f"    CAGR:         {s['cagr_pct']:>6.2f}%")
                    print(f"    Max DD:       {s['max_drawdown_pct']:>6.2f}%  ({s['max_drawdown_days']} days)")
                    print(
                        f"    Sharpe:       {s['sharpe_daily_annual']:>6.2f}  Sortino: {s['sortino_annual']:.2f}  Calmar: {s['calmar_ratio']:.2f}")
                    print(f"    Profit factor: {s['profit_factor']:>6.2f}")
                    print(f"    Total costs:  Rs {s['total_costs']:>15,.0f}")
                    print(f"    Max concurrent (actual): {s['max_concurrent_actual']}")

    # === Save outputs ===
    print("\n" + "=" * 80)
    print("SAVING OUTPUTS")
    print("=" * 80)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = OUT_DIR / f"run_{timestamp}"
    run_dir.mkdir(exist_ok=True)

    summary_df.to_csv(run_dir / "variant_results.csv", index=False)
    if len(val_df) > 0:
        val_df.to_csv(run_dir / "validation.csv", index=False)

    # Trade-level for each variant
    for vid in variant_ids:
        if vid in all_trades and len(all_trades[vid]) > 0:
            trades_copy = all_trades[vid].copy()
            for c in trades_copy.columns:
                if pd.api.types.is_datetime64_any_dtype(trades_copy[c]):
                    try:
                        if trades_copy[c].dt.tz is not None:
                            trades_copy[c] = trades_copy[c].dt.tz_localize(None)
                    except Exception:
                        pass
            trades_copy.to_csv(run_dir / f"trades_{vid}.csv", index=False)

    # Portfolio results
    for vid, pf_result in portfolio_results.items():
        if "completed_trades" in pf_result:
            ct = pf_result["completed_trades"].copy()
            for c in ct.columns:
                if pd.api.types.is_datetime64_any_dtype(ct[c]):
                    try:
                        if ct[c].dt.tz is not None:
                            ct[c] = ct[c].dt.tz_localize(None)
                    except Exception:
                        pass
            ct.to_csv(run_dir / f"portfolio_trades_{vid}.csv", index=False)

        if "daily_equity" in pf_result and len(pf_result["daily_equity"]) > 0:
            de = pf_result["daily_equity"].copy()
            for c in de.columns:
                if pd.api.types.is_datetime64_any_dtype(de[c]):
                    try:
                        if de[c].dt.tz is not None:
                            de[c] = de[c].dt.tz_localize(None)
                    except Exception:
                        pass
            de.to_csv(run_dir / f"portfolio_equity_{vid}.csv", index=False)

    # Master Excel
    excel_path = run_dir / "orb_workshop.xlsx"
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        summary_df.to_excel(writer, sheet_name="Variants", index=False)
        for family in summary_df["family"].dropna().unique():
            fam_df = summary_df[summary_df["family"] == family]

            safe_name = get_safe_sheet_name(family)
            fam_df.to_excel(writer, sheet_name=safe_name, index=False)

        if len(val_df) > 0:
            val_df.to_excel(writer, sheet_name="Validation", index=False)

        # Portfolio stats
        if portfolio_results:
            stats_rows = []
            for vid, pf in portfolio_results.items():
                if "stats" in pf:
                    s = dict(pf["stats"])
                    s["variant_id"] = vid
                    stats_rows.append(s)
            if stats_rows:
                pd.DataFrame(stats_rows).to_excel(writer, sheet_name="Portfolio Stats", index=False)

            # Equity curve for best variant
            best_vid = max(portfolio_results.keys(),
                           key=lambda v: portfolio_results[v].get("stats", {}).get("cagr_pct", 0)
                           if "stats" in portfolio_results[v] else 0)
            if "daily_equity" in portfolio_results[best_vid] and len(portfolio_results[best_vid]["daily_equity"]) > 0:
                portfolio_results[best_vid]["daily_equity"].to_excel(
                    writer, sheet_name=f"Equity {best_vid[:25]}", index=False)

    print(f"\n  Output dir: {run_dir}")
    print(f"  Excel: {excel_path}")

    # === Try equity chart ===
    if portfolio_results:
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt

            fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
            for vid, pf in portfolio_results.items():
                if "daily_equity" in pf and len(pf["daily_equity"]) > 0:
                    de = pf["daily_equity"]
                    axes[0].plot(de["date"], de["total_equity"], label=vid, linewidth=1.5)
                    axes[1].fill_between(de["date"], de["drawdown_pct"], 0, alpha=0.3, label=vid)

            axes[0].set_title("Portfolio Equity Curves")
            axes[0].set_ylabel("Total Equity (INR)")
            axes[0].grid(True, alpha=0.3)
            axes[0].legend(loc="best", fontsize=8)

            axes[1].set_title("Drawdown")
            axes[1].set_ylabel("Drawdown %")
            axes[1].set_xlabel("Date")
            axes[1].grid(True, alpha=0.3)
            axes[1].legend(loc="best", fontsize=8)

            plt.tight_layout()
            chart_path = run_dir / "equity_drawdown_chart.png"
            plt.savefig(chart_path, dpi=120, bbox_inches="tight")
            print(f"  Chart: {chart_path}")
        except Exception as e:
            print(f"  Chart skipped: {e}")

    print("\n" + "=" * 80)
    print("DONE")
    print("=" * 80)


if __name__ == "__main__":
    main()