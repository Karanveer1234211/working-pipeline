#!/usr/bin/env python3
"""
=============================================================================
FILTERED BACKTEST v2 — reality check for the v3.5 model
=============================================================================

Rebuilt from filtered_backtest_updated.py (which was written for the OLD model).
Key corrections vs the old version:

  FIX 1 (HONEST OOS) — The old script defined OOS as the last 20% of panel
     dates. But the model trains on the first 70% of dates, calibrates on
     70-90%, and only the LAST 10% is truly held out. So the old "OOS" overlapped
     the model's training+calibration window => in-sample leakage, inflated stats.
     v2 aligns OOS to the model's real cutoff: OOS_FRACTION_OF_DATES = 0.10
     (configurable). A confirmation flag prints the cutoff so you can verify it
     matches the model's test window.

  FIX 2 (BOTH MODELS) — You asked for prob buckets from BOTH the global pooled
     model and the regime-routed model. v2 scores both (m5_ensemble = global
     pooled; m5_regime_router = regime) and reports buckets side-by-side, so you
     can see which model's probabilities are better-calibrated and more monotonic.

  FIX 3 (ROUND-TRIP COSTS) — Old code subtracted cost ONCE (one side). A real
     trade pays entry AND exit. v2 applies cost as a round-trip: net = gross -
     2 * per_side_bps/100. Also adds an India-style preset (STT+fees+slippage).

  FIX 4 (OVERLAP-AWARE SHARPE) — Old code annualized per-trade Sharpe by
     sqrt(50), assuming ~50 independent trades/year. But 5-day-hold trades
     entered daily OVERLAP heavily and are NOT independent, which overstates
     annualized Sharpe. v2 reports (a) per-trade stats AND (b) a DE-OVERLAPPED
     daily-portfolio equity curve (one basket per day, mean of that day's
     qualifying trades), whose Sharpe is annualized by sqrt(252) on daily
     portfolio returns — the honest number.

  FIX 5 (LONG-ONLY, no phantom shorts) — This model is long-only: the target is
     "top 20% of forward 5d returns", so high prob = BUY for every regime. The
     stock_regime label is informational (which regime the long sits in), NOT a
     short signal. bear_trend long = "this downtrending name is likely to
     outperform". All realized returns are long returns; no sign flipping.

This is a SIGNAL-QUALITY + bucket reality check, not a full portfolio backtest
with position limits/capital. It answers: are the probabilities predictive, do
buckets rise monotonically, does edge survive costs, and where (regime) is it.

Run:  python filtered_backtest_v2.py
=============================================================================
"""

import json
import time
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
from joblib import load

warnings.filterwarnings("ignore")

# =============================================================================
# CONFIG
# =============================================================================
BASE_DIR = Path(r"C:\Users\karanvsi\Desktop\Kite Connect\v3_2_output_full")
PANEL_PATH = BASE_DIR / "panel_cache.parquet"
FEATURES_PATH = BASE_DIR / "features_train.json"
MODELS_DIR = BASE_DIR / "models"
ROUTER_PATH = MODELS_DIR / "m5_regime_router.joblib"
GLOBAL_PATH = MODELS_DIR / "m5_ensemble.joblib"  # pooled (fallback) ensemble

OUT_DIR = BASE_DIR / "backtest_results_filtered_v2"
OUT_DIR.mkdir(exist_ok=True)

IST = "Asia/Kolkata"

# Universe filter (match training)
MIN_CLOSE = 2.0
MIN_AVG20_VOL = 200_000

# Return convention: T+1 open -> T+6 close (realistic; matches model label)
RET_COL = "ret_5d_oc_pct"

# HONEST OOS: model's true held-out window starts at the 90% date cutoff.
# (Model: train 0-70%, calibrate 70-90%, test 90-100%.) Set to 0.10 to match.
OOS_FRACTION_OF_DATES = 0.10

# Filters
# All FOUR regimes scored, so you can SEE range-regime economics and decide
# trend-only on evidence, not assumption. (Was ["bull_trend","bear_trend"] only,
# which silently hid bull_range/bear_range from every report.)
ALLOWED_REGIMES = ["bull_trend", "bear_trend", "bull_range", "bear_range"]

PROB_BUCKETS = [(0.50, 0.55), (0.55, 0.60), (0.60, 0.65), (0.65, 0.70),
                (0.70, 0.75), (0.75, 0.80), (0.80, 0.85), (0.85, 0.90),
                (0.90, 0.95), (0.95, 1.001)]

# Costs: per-SIDE basis points. Round-trip = 2x. India preset ~ delivery:
#   brokerage+exchange+GST ~ 5 bps/side, STT 0.1% on sell side (~10 bps amortized
#   across round trip), slippage 5-15 bps/side for liquid names.
COST_BPS_PER_SIDE_LIST = [0, 10, 20, 30]  # per side; net subtracts 2x

TRADING_DAYS_PER_YEAR = 252

# =============================================================================
# LOAD
# =============================================================================
print("=" * 72)
print("FILTERED BACKTEST v2 — honest OOS, global+regime buckets, round-trip costs")
print("=" * 72)

print("\n[1/6] Loading panel and models...")
panel = pd.read_parquet(PANEL_PATH)
panel["timestamp"] = pd.to_datetime(panel["timestamp"])
if panel["timestamp"].dt.tz is None:
    panel["timestamp"] = panel["timestamp"].dt.tz_localize(IST)
else:
    panel["timestamp"] = panel["timestamp"].dt.tz_convert(IST)
panel = panel.sort_values(["symbol", "timestamp"]).reset_index(drop=True)
print(f"  Panel: {len(panel):,} rows")

for need in ("stock_regime", RET_COL):
    if need not in panel.columns:
        raise SystemExit(f"FATAL: panel missing '{need}'. Re-run the model so the "
                         f"enriched panel (with stock_regime / M_* / returns) is persisted.")

# Universe filter
panel["avg20_vol"] = panel.groupby("symbol", observed=True)["volume"].transform(
    lambda s: s.rolling(20, min_periods=1).mean())
panel = panel[(panel["close"] >= MIN_CLOSE) & (panel["avg20_vol"] >= MIN_AVG20_VOL)].reset_index(drop=True)
print(f"  After universe filter: {len(panel):,} rows")

schema = json.loads(FEATURES_PATH.read_text())
FEATURES = schema["features"]
IMPUTE = {k: float(v) for k, v in schema["impute"].items()}
print(f"  Features: {len(FEATURES)}")

router = load(ROUTER_PATH) if ROUTER_PATH.exists() else None
global_model = load(GLOBAL_PATH) if GLOBAL_PATH.exists() else None
print(f"  Regime router: {'loaded' if router else 'MISSING'}")
print(f"  Global pooled model: {'loaded' if global_model else 'MISSING'}")
if router is None and global_model is None:
    raise SystemExit("FATAL: neither regime router nor global model found.")

# =============================================================================
# PREDICT — BOTH MODELS
# =============================================================================
print("\n[2/6] Scoring both models...")
t0 = time.perf_counter()
X = panel.reindex(columns=FEATURES).copy()
for c in FEATURES:
    X[c] = pd.to_numeric(X[c], errors="coerce").fillna(IMPUTE.get(c, 0.0))

prob_regime = None
prob_global = None
if router is not None and hasattr(router, "predict_proba_by_regime"):
    prob_regime = router.predict_proba_by_regime(X, panel["stock_regime"])
if global_model is not None and hasattr(global_model, "predict_proba"):
    prob_global = global_model.predict_proba(X)[:, 1]

panel["prob_regime"] = prob_regime if prob_regime is not None else np.nan
panel["prob_global"] = prob_global if prob_global is not None else np.nan
print(f"  Done in {time.perf_counter()-t0:.1f}s")
if prob_regime is not None:
    print(f"  Regime prob range: [{np.nanmin(prob_regime):.3f}, {np.nanmax(prob_regime):.3f}]")
if prob_global is not None:
    print(f"  Global prob range: [{np.nanmin(prob_global):.3f}, {np.nanmax(prob_global):.3f}]")

# Forward return. LONG-ONLY: realized return is just the forward return, for
# every regime. (No short logic — the model never shorts.)
panel["fwd_ret_pct"] = pd.to_numeric(panel[RET_COL], errors="coerce")
panel["dir_ret_pct"] = panel["fwd_ret_pct"]

# =============================================================================
# HONEST OOS SPLIT (aligned to model's 90% cutoff)
# =============================================================================
print("\n[3/6] Defining honest OOS window...")
all_dates = panel["timestamp"].dt.normalize().drop_duplicates().sort_values()
oos_cutoff = all_dates.iloc[int(len(all_dates) * (1 - OOS_FRACTION_OF_DATES))]
panel["is_oos"] = panel["timestamp"] >= oos_cutoff
print(f"  OOS cutoff date: {oos_cutoff.date()}  (last {OOS_FRACTION_OF_DATES*100:.0f}% of dates)")
print(f"  >>> This should match the model's TEST window start. If the model used")
print(f"  >>> train 70/cal 20/test 10, set OOS_FRACTION_OF_DATES=0.10 (current: {OOS_FRACTION_OF_DATES}).")

# =============================================================================
# STATS HELPERS
# =============================================================================
def per_trade_stats(sub: pd.DataFrame, prob_col: str) -> dict:
    if len(sub) == 0:
        return {"n": 0}
    r = sub["dir_ret_pct"].values
    wins = r > 0
    return {
        "n": int(len(sub)),
        "win_rate_pct": round(100 * wins.mean(), 2),
        "predicted_avg_prob": round(sub[prob_col].mean(), 4),
        "calib_gap": round(sub[prob_col].mean() - wins.mean(), 4),
        "avg_ret_pct": round(r.mean(), 3),
        "median_ret_pct": round(float(np.median(r)), 3),
        "std_pct": round(r.std(), 3),
        "min_ret": round(r.min(), 2),
        "max_ret": round(r.max(), 2),
    }

def deoverlapped_portfolio_sharpe(sub: pd.DataFrame) -> dict:
    """Honest Sharpe: build a daily portfolio return = equal-weight mean of that
    day's qualifying trades, then annualize daily returns by sqrt(252). This
    removes the overlapping-trade inflation of per-trade Sharpe."""
    if len(sub) == 0:
        return {"port_days": 0, "port_ann_ret_pct": np.nan, "port_ann_sharpe": np.nan}
    daily = sub.groupby(sub["timestamp"].dt.normalize())["dir_ret_pct"].mean()
    # daily here is a 5-day-hold return realized per signal day; treat each signal
    # day's basket as one observation. Mean daily basket return / std, annualized.
    mu = daily.mean()
    sd = daily.std()
    ann_sharpe = (mu / (sd + 1e-9)) * np.sqrt(TRADING_DAYS_PER_YEAR / 5.0)  # /5: 5-day holds
    return {
        "port_days": int(len(daily)),
        "port_avg_basket_ret_pct": round(mu, 3),
        "port_ann_sharpe": round(ann_sharpe, 2),
    }

def bucket_label(low, high):
    return f"[{low:.2f}, {high:.2f})"

def assign_bucket(p):
    if not np.isfinite(p):
        return None
    for low, high in PROB_BUCKETS:
        if low <= p < high:
            return bucket_label(low, high)
    return None

# =============================================================================
# BUILD REPORTS FOR EACH MODEL
# =============================================================================
def run_model_report(prob_col: str, model_name: str):
    print(f"\n[4/6] Reports for {model_name} model ('{prob_col}')...")
    df = panel[panel["fwd_ret_pct"].notna() & panel[prob_col].notna()].copy()
    df = df[df["stock_regime"].isin(ALLOWED_REGIMES)].copy()
    df["prob_bucket"] = df[prob_col].apply(assign_bucket)

    rows = []
    for low, high in PROB_BUCKETS:
        lbl = bucket_label(low, high)
        for scope, d in [("Full", df), ("OOS", df[df["is_oos"]])]:
            sub = d[d["prob_bucket"] == lbl]
            s = per_trade_stats(sub, prob_col)
            s.update(deoverlapped_portfolio_sharpe(sub))
            s["prob_bucket"] = lbl
            s["scope"] = scope
            s["model"] = model_name
            rows.append(s)
    bucket_df = pd.DataFrame(rows)

    # cost sensitivity on OOS (round-trip = 2 x per-side)
    cost_rows = []
    for low, high in PROB_BUCKETS:
        lbl = bucket_label(low, high)
        sub = df[(df["prob_bucket"] == lbl) & df["is_oos"]]
        if len(sub) == 0:
            continue
        gross = sub["dir_ret_pct"].mean()
        std = sub["dir_ret_pct"].std()
        for bps in COST_BPS_PER_SIDE_LIST:
            rt_cost = 2 * bps / 100.0  # round-trip, in pct
            net = gross - rt_cost
            cost_rows.append({
                "model": model_name, "prob_bucket": lbl, "n_oos": int(len(sub)),
                "bps_per_side": bps, "roundtrip_cost_pct": round(rt_cost, 3),
                "gross_pct": round(gross, 3), "net_pct": round(net, 3),
                "net_win_rate_pct": round(100 * ((sub["dir_ret_pct"] - rt_cost) > 0).mean(), 2),
            })
    cost_df = pd.DataFrame(cost_rows)

    # cumulative by threshold (OOS)
    thr_rows = []
    for thr in [0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95]:
        sub = df[(df[prob_col] >= thr) & df["is_oos"]]
        s = per_trade_stats(sub, prob_col)
        s.update(deoverlapped_portfolio_sharpe(sub))
        s["threshold"] = f">= {thr:.2f}"
        s["model"] = model_name
        thr_rows.append(s)
    thr_df = pd.DataFrame(thr_rows)

    return bucket_df, cost_df, thr_df, df

reports = {}
for prob_col, name in [("prob_global", "GLOBAL"), ("prob_regime", "REGIME")]:
    if panel[prob_col].notna().any():
        reports[name] = run_model_report(prob_col, name)

# Combine
bucket_all = pd.concat([r[0] for r in reports.values()], ignore_index=True) if reports else pd.DataFrame()
cost_all = pd.concat([r[1] for r in reports.values()], ignore_index=True) if reports else pd.DataFrame()
thr_all = pd.concat([r[2] for r in reports.values()], ignore_index=True) if reports else pd.DataFrame()

# Per-regime split (regime model, OOS)
print("\n[5/6] Per-regime bucket split...")
regime_rows = []
if "REGIME" in reports:
    dfR = reports["REGIME"][3]
    for low, high in PROB_BUCKETS:
        lbl = bucket_label(low, high)
        for regime in ALLOWED_REGIMES:
            sub = dfR[(dfR["prob_bucket"] == lbl) & (dfR["stock_regime"] == regime) & dfR["is_oos"]]
            s = per_trade_stats(sub, "prob_regime")
            s.update(deoverlapped_portfolio_sharpe(sub))
            s["prob_bucket"] = lbl; s["regime"] = regime
            regime_rows.append(s)
regime_df = pd.DataFrame(regime_rows)

# =============================================================================
# SAVE
# =============================================================================
print("\n[6/6] Saving...")
def strip_tz(df):
    if df is None or len(df) == 0:
        return df
    out = df.copy()
    for c in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[c]):
            try:
                out[c] = out[c].dt.tz_localize(None)
            except Exception:
                pass
    return out

outputs = {
    "01_buckets_both_models.csv": bucket_all,
    "02_cost_sensitivity_roundtrip.csv": cost_all,
    "03_threshold_cumulative.csv": thr_all,
    "04_per_regime_buckets.csv": regime_df,
}
for fname, d in outputs.items():
    if d is not None and len(d):
        d.to_csv(OUT_DIR / fname, index=False)
print(f"  Saved {len([d for d in outputs.values() if d is not None and len(d)])} CSVs to {OUT_DIR}")

try:
    xlsx = OUT_DIR / "filtered_backtest_v2.xlsx"
    with pd.ExcelWriter(xlsx, engine="openpyxl") as w:
        if len(bucket_all): strip_tz(bucket_all).to_excel(w, sheet_name="Buckets (both models)", index=False)
        if len(cost_all): strip_tz(cost_all).to_excel(w, sheet_name="Cost Sensitivity", index=False)
        if len(thr_all): strip_tz(thr_all).to_excel(w, sheet_name="Threshold Cumulative", index=False)
        if len(regime_df): strip_tz(regime_df).to_excel(w, sheet_name="Per-Regime", index=False)
    print(f"  Saved Excel: {xlsx}")
except Exception as e:
    print(f"  Excel save skipped: {e}")

# =============================================================================
# CONSOLE SUMMARY — the reality check
# =============================================================================
def print_buckets(model_name):
    sub = bucket_all[(bucket_all["model"] == model_name) & (bucket_all["scope"] == "OOS")]
    if len(sub) == 0:
        return
    print(f"\n{'='*92}\n{model_name} MODEL — OOS buckets (trend regimes)\n{'='*92}")
    print(f"  {'Bucket':<16}{'N':>7}{'Win%':>7}{'Pred':>7}{'Gap':>8}{'AvgRet%':>9}{'Med%':>8}{'PortSharpe':>11}")
    for _, r in sub.iterrows():
        if r.get("n", 0) == 0:
            continue
        print(f"  {r['prob_bucket']:<16}{int(r['n']):>7,}{r['win_rate_pct']:>7.1f}"
              f"{r['predicted_avg_prob']:>7.3f}{r['calib_gap']:>+8.3f}{r['avg_ret_pct']:>+9.3f}"
              f"{r['median_ret_pct']:>+8.3f}{r.get('port_ann_sharpe', float('nan')):>11.2f}")

for name in ("GLOBAL", "REGIME"):
    if name in reports:
        print_buckets(name)

if len(regime_df):
    print(f"\n{'='*92}\nPER-REGIME (REGIME model, OOS)\n{'='*92}")
    print(f"  {'Bucket':<16}{'Regime':<12}{'N':>7}{'Win%':>7}{'AvgRet%':>9}{'PortSharpe':>11}")
    for _, r in regime_df.iterrows():
        if r.get("n", 0) == 0:
            continue
        print(f"  {r['prob_bucket']:<16}{r['regime']:<12}{int(r['n']):>7,}"
              f"{r['win_rate_pct']:>7.1f}{r['avg_ret_pct']:>+9.3f}{r.get('port_ann_sharpe', float('nan')):>11.2f}")

print(f"\n{'='*92}\nREALITY-CHECK QUESTIONS\n{'='*92}")
print("  1. MONOTONIC? Does avg_ret_pct rise as prob_bucket rises, in OOS? (the core test)")
print("  2. CALIBRATED? Is calib_gap near 0? Large positive gap = model overconfident.")
print("  3. GLOBAL vs REGIME: which model's buckets are more monotonic + better calibrated?")
print("  4. SURVIVES COSTS? In 02_cost_sensitivity, is net_pct still positive at 20-30 bps/side?")
print("  5. TREND SPLIT: is bull_trend or bear_trend carrying the edge? (04_per_regime)")
print("  6. Use PortSharpe (de-overlapped), NOT per-trade Sharpe, for realism.")
print(f"\n  OOS window started {oos_cutoff.date()} — confirm it matches the model's test cutoff.")
print("=" * 92)